# Discussion set contents

This archive collects the Issue and the current implementation/design sources that are useful when refining its scope.

## Root

- `ISSUE_BODY.md` — Issue text copied from `docs/active/issues/20261001-010118-ui-loading-screen/ISSUE_BODY.md`.
- `CONTENTS.md` — this file; source map and selection notes.

## Reviewed loading design master

- `design-master/README.md` — source-of-truth roles, constraints, and design notes.
- `design-master/index.html` — canonical loading-screen reference implementation.
- `design-master/assets/emblem.webp` — canonical emblem asset.
- `design-master/css/component.css` — layout, shapes, breakpoints, and motion rules.
- `design-master/css/tokens.css` — generated CSS token output.
- `design-master/tokens/design-tokens.json` — editable design token source.
- `design-master/package.json` and `design-master/scripts/` — token build and read-only master checks.

The Issue names the reviewed design-master ZIP as its design source. Its canonical files are unpacked here under `design-master/`. The source ZIP's `reference/` directory is omitted because its README identifies that directory as comparison-only and non-canonical.

## Current UI implementation

Files below are copies of the current working-tree versions, kept under `implementation/` with their repository paths:

- `implementation/package/index.html` and `implementation/package/src/main.jsx` — HTML entry point, React mount, and global stylesheet import.
- `implementation/package/src/ui/App.jsx` — loading state, release initialization, per-screen loading state, and app shell.
- `implementation/package/src/ui/release-client.js` — release-root and artifact loading behavior.
- `implementation/package/src/ui/index.css`, `implementation/package/tailwind.config.js`, `implementation/package/postcss.config.js`, and `implementation/package/vite.config.js` — active styling and build configuration.
- `implementation/package/src/ui/components/Icon.jsx`, `clipboard.js`, `data-model.js`, `local-state.js`, and `images/` — direct App/entry-point dependencies included for source context.
- `implementation/package/package.json` — UI package metadata and dependency context.

Unreferenced stylesheet files are omitted. No documents sourced from outside `docs/active` and no non-canonical design reference files are included.
