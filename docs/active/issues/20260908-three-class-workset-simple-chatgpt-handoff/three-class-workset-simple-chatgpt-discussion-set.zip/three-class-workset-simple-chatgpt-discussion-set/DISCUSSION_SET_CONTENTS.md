# 3-class ChatGPT 簡素 handoff 議論セット

## 目的

`ISSUE_BODY.md` の議論に必要な、現在の 3-class 作業セット生成・single-roundtrip 判定・返却確定の実装と、ChatGPT が参照する判定材料の現行ソースを、一つの ZIP に集約する。

## 収録範囲

- `ISSUE_BODY.md`
  - 議論対象の issue 本文。discussion set root に配置する。
- `sources/package/scripts/adapters/three-class-workset.js`、`sources/package/scripts/pack-three-class-workset.py`、`sources/package/templates/three-class-workset/README_FIRST.md`
  - 現行の DB 選択から workspace／ZIP 作成までと、transport に含める範囲を決める実装。
- `sources/package/scripts/comment-database.mjs`、`sources/package/src/database/`、`sources/package/src/processing/analysis-input/`
  - CLI、対象 snapshot の選択、5-field 分析入力と provenance の投影境界。
- `sources/package/tests/three-class-workset.test.js`
  - 現行の ZIP 構成、request binding、zero-handoff、response finalize 互換性、失敗時の回帰条件。
- `sources/docs/active/operations/Integrated_Labeling_Handoff_v1.5.0/`
  - 現行 single-roundtrip の実装、入力／返却契約、prompt、判定規則、設定、テスト、および Stage13 の過去判定結果。
- `sources/docs/active/operations/integrated-labeling-state/`
  - 現行運用で参照する exact-case の 3-class 過去判定レジストリ。

## 除外範囲

- `docs/archive`、`docs/active` 外の `docs` 配下文書、パス上で legacy と明示された資産、旧 handoff／過去の議論セット。
- 既存の ZIP、workspace、snapshot、manifest、receipt、finalize 成果物などの生成物。
- UI、候補生成・公開処理、DB 実データ、private／`var` 配下のデータ。
- v1.5.0 の baseline reference にある 3-class レジストリ複製。現行運用で実際に参照される `integrated-labeling-state` を正本として収録する。

## 配置規則

discussion set root には `ISSUE_BODY.md` と本目録を置く。収録ソースは `sources/` 以下に repository root からの相対パスを保って配置する。`sources/docs/` に収録する文書はすべて `docs/active` 配下の現行資産に限定する。
