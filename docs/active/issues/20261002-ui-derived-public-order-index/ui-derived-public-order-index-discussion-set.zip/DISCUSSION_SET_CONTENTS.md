# 議論セット収録一覧

## 目的

「UI上の派生値として治安指数を表示する」の議論で、現行の分析概要 UI、期間集計、公開データの生成・検証境界を参照できる状態にする。

## 収録ファイル

- `ISSUE_BODY.md` — 指定された Issue 本文の作成時点の内容。
- `sources/package/src/main.jsx` — 現行 UI のエントリーポイント。
- `sources/package/src/ui/App.jsx` — 分析概要画面、期間選択、期間集計の表示、部分観測表示。
- `sources/package/src/ui/data-model.js` — 3分類の公開ラベルと UI 表示名。
- `sources/package/src/ui/release-client.js` — 公開リリースと overview artifact の読み込み・形状検証。
- `sources/package/src/ui/index.css` — 現行 UI の共通スタイル。
- `sources/package/src/processing/optimicom-ui-release/overview.js` — 既存の1日・7日・30日集計、分類件数、観測数、coverage の生成と検証。
- `sources/package/src/processing/optimicom-ui-release/source-dataset.js` — overview の入力となる公開観測データと分類値の検証。
- `sources/package/src/processing/optimicom-ui-release/release.js` — overview artifact を含む公開リリースの生成。

## 収録注記

ソースは作成時点の作業ツリーから原文のままコピーし、`sources/` 以下ではリポジトリ内の相対パスを保つ。Issue 本文以外の文書資料、過去の UI 案、`temp` 配下の複製物、観測データの実体は収録しない。
