import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const packageDir = fileURLToPath(new URL("..", import.meta.url));
const npm = process.platform === "win32" ? "npm.cmd" : "npm";

test("published package includes user documentation and built entry points", () => {
  const raw = execFileSync(npm, ["pack", "--dry-run", "--json"], {
    cwd: packageDir,
    encoding: "utf8",
    maxBuffer: 4 * 1024 * 1024,
  });
  const result = JSON.parse(raw);
  const files = new Set(result[0].files.map((entry) => entry.path));

  for (const required of [
    "README.md",
    "docs/README.md",
    "docs/API_REFERENCE.md",
    "dist/index.js",
    "dist/index.d.ts",
    "dist/cli-entry.js",
  ]) {
    assert.ok(files.has(required), `missing from package: ${required}`);
  }
});
