import { fileURLToPath } from "node:url";
import { Worker, type WorkerOptions } from "@temporalio/worker";
import { createTemporalActivities } from "./temporal-activities.js";
import type { TemporalWorkerRuntimeOptions } from "./temporal-contracts.js";

export interface WorkOrchestratorWorkerOptions extends Omit<WorkerOptions, "activities" | "workflowsPath"> {
  runtime?: TemporalWorkerRuntimeOptions;
  workflowsPath?: string;
}

/** WorkSession Workflow と v1 Activity を登録した実 Worker を生成する。 */
export async function createWorkOrchestratorWorker(options: WorkOrchestratorWorkerOptions): Promise<Worker> {
  const { runtime, workflowsPath = fileURLToPath(new URL("./temporal-workflow.js", import.meta.url)), ...workerOptions } = options;
  return Worker.create({
    ...workerOptions,
    workflowsPath,
    activities: createTemporalActivities(runtime),
  });
}

/** Worker の起動を一箇所に固定し、poller 不在を隠蔽しない。 */
export async function runWorkOrchestratorWorker(options: WorkOrchestratorWorkerOptions): Promise<void> {
  const worker = await createWorkOrchestratorWorker(options);
  await worker.run();
}
