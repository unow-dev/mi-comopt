# Work Orchestrator v1

Work Orchestrator は、`WorkDefinition` を実行可能な Task / Execution / Wait に展開し、Human Task、Agent Task、外部イベント、timer、成果物、監査履歴を一つの実行モデルで扱う Node.js パッケージです。

永続的に利用する通常の経路は Workspace-first です。まず Workspace を作成し、公開 API で開いてから、Workspace の `registry` と `artifactStore` を明示して `WorkOrchestrator` を構築します。

```bash
npx work-orchestrator init .
```

```js
import { openWorkspace, WorkOrchestrator } from "work-orchestrator";

const workspace = openWorkspace(".");
const orchestrator = new WorkOrchestrator({
  registry: workspace.registry,
  artifactStore: workspace.artifactStore,
  workspace,
});

orchestrator.registerDefinition(definition);
await orchestrator.startSession({
  sessionId: "session-1",
  workDefinitionId: definition.workDefinitionId,
  revision: definition.revision,
});
```

登録済み Definition を操作する対話 CLI は、明示的な Workspace 指定なら次で起動します。

```bash
npx work-orchestrator --workspace . --actor local-user
```

CLI の対話 `new` は Workspace Registry にすでに登録されている Definition を選択して Session を開始します。Definition の登録は `orchestrator.registerDefinition()` で行います。Workspace の詳細、Human Task の完了、Agent、Temporal 連携については [導入ガイド](./docs/README.md) を参照してください。

- [導入ガイド](./docs/README.md) — Workspace-backed Quickstart、永続化、Human Task、Agent、Temporal-backed execution
- [API Reference](./docs/API_REFERENCE.md) — 公開契約、メソッド、root export の完全索引
