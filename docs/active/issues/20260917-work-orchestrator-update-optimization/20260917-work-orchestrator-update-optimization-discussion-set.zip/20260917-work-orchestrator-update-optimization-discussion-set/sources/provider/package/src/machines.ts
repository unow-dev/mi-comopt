import { createActor, createMachine } from "xstate";
import type { ExecutionState, SessionState, TaskState } from "./contracts.js";

export const sessionMachine = createMachine({
  id: "work-session-v2",
  initial: "running",
  states: {
    running: { on: { ROOT_COMPLETED: "completed", CANCEL_REQUESTED: "cancelling" } },
    cancelling: { on: { CANCELLATION_DRAINED: "cancelled" } },
    completed: { type: "final" },
    cancelled: { type: "final" },
  },
});

export const taskMachine = createMachine({
  id: "task-v2",
  initial: "ready",
  states: {
    ready: { on: { CLAIM: "active", DISPATCH: "active", CANCEL: "cancelled" } },
    active: { on: { RELEASE: "ready", COMPLETE: "completed", BLOCK: "waiting", CANCEL: "cancelled" } },
    waiting: { on: { REDISPATCH: "active", CANCEL: "cancelled" } },
    completed: { type: "final" },
    cancelled: { type: "final" },
  },
});

export const executionMachine = createMachine({
  id: "execution-v2",
  initial: "running",
  states: {
    running: {
      on: {
        SUCCEED: "succeeded",
        FAIL: "failed",
        CANCEL_ACKNOWLEDGED: "cancelled",
        ABANDON: "abandoned",
      },
    },
    succeeded: { type: "final" },
    failed: { type: "final" },
    cancelled: { type: "final" },
    abandoned: { type: "final" },
  },
});

function transition(machine: any, current: string, event: string): string {
  const actor = createActor(machine, { snapshot: machine.resolveState({ value: current, context: {} }) }).start();
  try {
    actor.send({ type: event });
    const value = String(actor.getSnapshot().value);
    if (value === current) throw new Error(`illegal lifecycle transition ${current} -> ${event}`);
    return value;
  } finally {
    actor.stop();
  }
}

export function transitionSession(current: SessionState, event: "ROOT_COMPLETED" | "CANCEL_REQUESTED" | "CANCELLATION_DRAINED"): SessionState {
  return transition(sessionMachine, current, event) as SessionState;
}

export function transitionTask(current: TaskState, event: "CLAIM" | "DISPATCH" | "RELEASE" | "COMPLETE" | "BLOCK" | "CANCEL" | "REDISPATCH"): TaskState {
  return transition(taskMachine, current, event) as TaskState;
}

export function transitionExecution(
  current: ExecutionState,
  event: "SUCCEED" | "FAIL" | "CANCEL_ACKNOWLEDGED" | "ABANDON",
): ExecutionState {
  return transition(executionMachine, current, event) as ExecutionState;
}

export function canTransitionSession(current: SessionState, event: string): boolean {
  try {
    transitionSession(current, event as never);
    return true;
  } catch {
    return false;
  }
}

export function canTransitionTask(current: TaskState, event: string): boolean {
  try {
    transitionTask(current, event as never);
    return true;
  } catch {
    return false;
  }
}

export function canTransitionExecution(current: ExecutionState, event: string): boolean {
  try {
    transitionExecution(current, event as never);
    return true;
  } catch {
    return false;
  }
}
