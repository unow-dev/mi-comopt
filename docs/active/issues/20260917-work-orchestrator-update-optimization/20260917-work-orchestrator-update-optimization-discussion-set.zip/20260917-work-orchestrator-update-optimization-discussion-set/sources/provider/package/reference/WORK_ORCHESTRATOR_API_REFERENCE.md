# Work Orchestrator API Reference

この文書は、`work-orchestrator` の root entry point から利用できる公開 API と、現行実装の主要な契約を説明します。

- 通常の import はすべて `from "work-orchestrator"` から行います。
- `work-orchestrator/runtime` などの subpath import は現在提供していません。
- TypeScript の type/interface は JavaScript の runtime value ではありません。
- root export には高水準 facade、reducer、XState machine、Temporal primitive が含まれます。通常利用では高水準 facade を優先してください。

## 1. API の選び方

| 目的 | 第一候補 |
| --- | --- |
| Workspace を初期化・開く | `initWorkspace()`, `openWorkspace()` |
| ローカル / 単一 process で orchestration を実行 | `WorkOrchestrator` |
| Work graph を定義 | `WorkDefinition`, `Step`, `TaskContract` |
| Human Task を操作 | `claimTask()`, `releaseTask()`, `completeHumanTask()` |
| Session / Task / history を観測 | `WorkOrchestrator.getSessionView()` |
| SQLite 永続状態を管理 | `Registry` |
| Artifact bytes を管理 | `ArtifactStore` |
| Agent 実装を接続 | `AgentAdapter`, `WorkerProfile` |
| Codex CLI を Agent として接続 | `createCodexCliAdapter()` |
| Temporal Worker を起動 | `createWorkOrchestratorWorker()`, `runWorkOrchestratorWorker()` |
| Temporal Client から操作 | `connectWorkOrchestratorClient()`, `WorkOrchestratorTemporalClient` |
| Definition を単独検証 | `validateAndHashDefinition()` |
| reducer / machine を直接扱う | `reduceCommand()`, `sessionMachine` など low-level API |

## 2. Core orchestration

### `WorkOrchestrator`

**種別:** class / **用途:** Typical use

単一 Node.js process 内で Definition の登録、Session 開始、command serialisation、Human / Agent Task、Registry commit、Artifact materialisation をまとめる facade です。

```ts
new WorkOrchestrator(options?: OrchestratorOptions)
```

#### `OrchestratorOptions`

```ts
interface OrchestratorOptions {
  registry?: Registry;
  artifactStore?: ArtifactStore;
  workers?: WorkerProfile[];
  agentAdapter?: AgentAdapter;
  workspace?: OpenWorkspace;
}
```

省略時は in-memory の Registry、temporary の ArtifactStore、`FakeAgentAdapter` が使われます。`workspace` は file-producing task の Workspace を保持しますが、`workspace` から `registry` や `artifactStore` を自動的に推論・置換しません。Workspace-backed の通常利用では三つすべてを明示してください。

#### 公開 method

| method | 用途・注意 |
| --- | --- |
| `registerDefinition(definition)` | Definition を検証・hashing して Registry に登録し、`ValidatedDefinition` を返す。 |
| `addWorker(worker)` | `WorkerProfile` を runtime と Registry projection に追加・更新する。 |
| `startSession(input)` | 登録済み Definition または inline Definition から Session を開始し、自動 advance を drive する。 |
| `startSessionFromWorkspace(input)` | filesystem input を immutable Artifact と bootstrap manifest に snapshot してから Session を開始する。 |
| `dispatch(sessionId, command, actor?, commandId?)` | `DomainCommand` を直接送る low-level 入口。通常は専用 method を優先する。 |
| `claimTask(sessionId, taskId, actor, commandId?)` | ready Human Task を actor が claim する。 |
| `releaseTask(sessionId, taskId, actor, commandId?)` | claim 済み Human Task を release する。 |
| `completeHumanTask(sessionId, taskId, actor, outcome?, result?, commandId?)` | Human Task を完了する。 |
| `completeHumanTaskWithInput(sessionId, taskId, actor, input, commandId)` | outcome、result、comment、ArtifactVersion をまとめて Human Task に渡して完了する。 |
| `openHumanTaskWorkspace(sessionId, taskId, actor, commandId?)` | Human Task の input/work/output 用実行 Workspace を作成し、必要なら claim する。 |
| `completeHumanTaskFromWorkspace(sessionId, taskId, actor, input, commandId)` | output directory を snapshot し、ArtifactVersion とともに Human Task を完了する。 |
| `resumeAgentTask(sessionId, taskId, actor?, commandId?)` | manual retry が許可された blocked Agent Task を再開する。 |
| `cancelSession(sessionId, actor?, reason?, commandId?)` | Session cancellation を開始し、running Agent の cancellation intent も処理する。 |
| `receiveExternalEvent(sessionId, event, actor?, commandId?)` | event wait に外部 event を投入する。 |
| `fireTimer(sessionId, waitId, actor?, commandId?)` | in-process runtime で timer wait を発火する。 |
| `state(sessionId)` | raw `RuntimeState` を返す。低レベル inspection / test 向け。 |
| `pendingTimers(sessionId)` | waiting timer の `waitId` と `delayMs` を返す。 |
| `sessionRuntimeInfo(sessionId)` | SDK 非依存 runtime model 上の workflow/run ID を返す。実 Temporal handle の代替ではない。 |
| `getSessionView(sessionId)` | Session、scopes、tasks、executions、waits、artifacts、history、consistency をまとめて観測する。 |
| `deliverExternalEvent(sessionId, event)` | receipt-first の外部 event 配信を行い、terminal Session では安全に記録して無視する。 |
| `reconcile(sessionId, temporalState?)` | runtime state と Registry projection の revision / state hash を照合する。 |

`WorkOrchestrator` には `close()` はありません。呼び出し側が生成または所有する Registry を `close()` してください。

### `StartSessionInput`

現行の in-process Session 開始入力は次の形です。

```ts
interface StartSessionInput {
  sessionId: string;
  workDefinitionId?: string;
  revision?: number;
  input?: JsonValue;
  actor?: ActorRef;
  commandId?: string;
  definition?: WorkDefinition;
  inputArtifacts?: ArtifactVersionRuntime[];
  bootstrapManifest?: {
    artifactVersionId: string;
    blobHash: string;
  };
}
```

`workDefinitionId` を指定し、`revision` を省略した場合は、その ID に登録されている Definition の最大 revision を選択します。省略した `revision` を `0` とみなす契約ではありません。`definition` を渡した場合は inline Definition とその revision が使われます。inline Definition は有効な API モードですが、通常の onboarding は `registerDefinition()` で登録してから `startSession()` を呼ぶ経路です。

同じ Session の start command は idempotency receipt で扱われます。同じ command ID を異なる request 内容で再利用すると conflict になります。

### Session view

`getSessionView(sessionId)` は、次の情報を含む object または `undefined` を返します。

```ts
{
  session,
  scopes,
  tasks,
  executions,
  waits,
  artifacts,
  resultsByStepId,
  history,
  consistency,
}
```

通常の観測には Registry projection と history を含む `getSessionView()` を使い、raw state が必要な test / low-level integration にだけ `state()` を使います。

## 3. Workspace API

Workspace-first の通常 lifecycle は次です。

```bash
npx work-orchestrator init .
```

```js
import { openWorkspace, WorkOrchestrator } from "work-orchestrator";

const workspace = openWorkspace(".");
const orchestrator = new WorkOrchestrator({
  registry: workspace.registry,
  artifactStore: workspace.artifactStore,
  workspace,
});
```

`initWorkspace(root, options?)` は Workspace の設定、completion marker、Registry、ArtifactStore、inbox/work/outbox/sessions を初期化します。`openWorkspace(root)` は初期化済みの Workspace を開いて authority の identity を検証します。`openWorkspace()` は初期化や migration を行いません。

`findWorkspace(start?)` は親 directory をたどって completed Workspace の root を探索し、`resolveWorkspace(explicit?, start?)` は明示 path または discovery 結果を解決します。`workspacePaths(root)` は Workspace の各 path を返し、`safeWorkspaceKey(id)` は Session / Execution directory 用の安全なキーを作ります。

Workspace が公開する主な型は次のとおりです。

- `WorkspaceConfig`: Workspace format と Temporal 接続設定。
- `WorkspaceState`: format version と `workspaceId`。
- `WorkspacePaths`: config、state、Registry、ArtifactStore、inbox、work、outbox、sessions の path。
- `OpenWorkspace`: `WorkspacePaths`、config、state、open 済み `registry`、`artifactStore`。
- `InitWorkspaceResult`: `workspace`、`state`、`created`、`resumed`。
- `ExecutionWorkspace`: Human / Agent execution の input、work、output、metadata path。

`executionWorkspace(paths, sessionId, executionId)` は実行 Workspace の path を計算し、`prepareExecutionWorkspace(paths, state, taskId, executionId, store)` は input Artifact を materialize して実行用 directory を準備します。

主要な format/path constant は `WORKSPACE_FORMAT_VERSION`、`WORKSPACE_STATE_PATH`、`WORKSPACE_REGISTRY_PATH`、`WORKSPACE_ARTIFACTS_PATH` です。

## 4. WorkDefinition と Step

```ts
interface WorkDefinition {
  workDefinitionId: string;
  revision: number;
  schemaVersion: number;
  root: Step;
  definitionHash?: string;
  limits?: {
    maxBufferedExternalEvents?: number;
    maxDynamicTasksPerSession?: number;
  };
}
```

| `kind` | 型 | 説明 |
| --- | --- | --- |
| `task` | `TaskStep` | Human または Agent が処理する Task。 |
| `sequence` | `SequenceStep` | child Step を順番に実行する。 |
| `choice` | `ChoiceStep` | decision Task または v2 input binding に応じて branch を選ぶ。 |
| `parallelAll` | `ParallelAllStep` | 全 branch を実行して全完了を待つ。 |
| `waitEvent` | `WaitEventStep` | `eventType` / `correlationKey` に一致する event を待つ。 |
| `waitTimer` | `WaitTimerStep` | `delayMs` の timer を待つ。 |
| `dynamicExpand` | `DynamicExpandStep` | planner の proposal から実行時 Task を生成する。 |
| `noop` | `NoopStep` | schema v2 の no-op。 |

`TaskContract` は `workerKind`、capability / permission 要件、`retryPolicy`、Agent の budget、`outputSchema`、`resultSchema`、`allowedOutcomes` を持ちます。schema v2 では Human Task の budget は必須ではありませんが、Agent Task には必要です。

`registerDefinition()` または `validateAndHashDefinition()` を通すと canonical `definitionHash` が設定されます。同じ `(workDefinitionId, revision)` に異なる hash の Definition を登録することはできません。

## 5. Human Task lifecycle

基本の lifecycle は次のとおりです。

```text
ready -> claimTask -> active -> completeHumanTask -> completed
                    \-> releaseTask -> ready
```

`claimTask()` は Human Execution を作ります。`releaseTask()` は現在の Human Execution を cancel して Task を ready に戻し、再 claim 時は新しい Execution を作ります。`allowedOutcomes` を指定した Task では許可された outcome を渡す必要があります。

ファイルを扱う Human Task では `openHumanTaskWorkspace()` で input/work/output directory を準備し、output に保存した後 `completeHumanTaskFromWorkspace()` を呼びます。JSON の結果や comment、既存の ArtifactVersion を直接渡す場合は `completeHumanTaskWithInput()` を使います。

## 6. Agent integration

### `AgentAdapter`

```ts
interface AgentAdapter {
  run(request: AgentRunRequest): Promise<AgentRunResult>;
  cancel(executionId: string): Promise<{ confirmed: boolean }>;
  forceKill?(executionId: string): Promise<void>;
}
```

`AgentRunRequest` には Session、Task、Execution、`ExecutionGrant`、任意の execution Workspace が含まれます。`AgentRunResult.status` は `succeeded | blocked | failed | cancelled | abandoned` です。`artifacts` に `ProducedArtifact[]` を返すと ArtifactStore に保存され、ArtifactVersion と provenance が Registry に記録されます。

### `WorkerProfile`

runtime は `enabled`、capability、permission、budget の順で候補を絞り、`routingPriority` と `workerId` で deterministic に選択します。`physicalAvailable: false` の Worker は Agent Execution を失敗させます。

### `FakeAgentAdapter`、`CodexAdapter`、`createCodexCliAdapter()`

`FakeAgentAdapter` は `plan(taskId, ...plans)` で deterministic な結果を設定する受入試験用 adapter です。設定がない場合も成功するため、実運用には使いません。

`CodexAdapter` は任意の cancellable runner を `AgentAdapter` に包みます。Codex CLI を起動する場合は `createCodexCliAdapter(options?: CodexCliAdapterOptions)` を使います。主な option は `executable`、`cwd`、`model`、`sandbox`、`extraArgs`、`env`、`maxOutputBytes`、`killGraceMs`、`promptBuilder` です。

## 7. Persistence

### `Registry` / `RegistryReader`

Registry は SQLite に Definition、Session state、Domain commit、command receipt、Task / Execution projection を保持します。

```ts
Registry.initialize(path: string): Registry
Registry.open(path: string): Registry
Registry.openReadOnly(path: string): RegistryReader
Registry.inMemory(): Registry
```

`Registry.initialize()` は保存領域を作成して schema を適用します。`Registry.open()` はすでに初期化された保存領域を開いて schema を検証します。`open()` は初期化や migration を行いません。低水準の `migrate()` は schema migration を適用しますが、通常は `initialize()` を利用してください。互換性 convenience として `new Registry(path)` も利用できます。

主要 method は `registerDefinition()`、`getDefinition()`、`listDefinitions()`、`setWorkspaceId()`、`getWorkspaceId()`、`listWorkers()`、`listSessions()`、`listSessionPage()`、`getRuntimeState()`、`getSessionProjection()`、`getDomainCommits()`、`getReceipt()`、`recordReceipt()`、`commit()`、`commitInitialSession()`、`listTables()`、`query()`、`close()` です。`commit()` と `commitInitialSession()` は receipt / revision / projection を原子的に保つ low-level writer API です。

`Registry.openReadOnly()` は書き込み capability を持たない `RegistryReader` を返します。Registry は single writer host 前提です。

### `ArtifactStore`

ArtifactStore は content-addressed immutable blob store です。ArtifactVersion の metadata と provenance は Registry が保持します。

```ts
ArtifactStore.initialize(root: string): ArtifactStore
ArtifactStore.open(root: string): ArtifactStore
ArtifactStore.temporary(): ArtifactStore
```

`initialize()` は marker と `blobs/` / `staging/` を作成します。`open()` は既存 marker と保存領域を検証します。主な method は `bindWorkspaceId()`、`getWorkspaceId()`、`stage()`、`finalize()`、`hasBlob()`、`read()`、`gcOrphans()`、`blobPath()`、`root` です。`ArtifactStore.open()` も初期化や migration を行いません。

Registry と ArtifactStore を個別に所有する場合、呼び出し側が Registry を `close()` します。Workspace を使う場合は `workspace.registry.close()` を実行します。

## 8. Artifact / outbox helpers

### Artifact snapshot

次の API はファイルを immutable ArtifactVersion に変換し、ArtifactStore と組み合わせて利用します。

- `DirectoryArtifactManifestV1`: directory manifest の型。
- `SnapshotOptions`: `logicalPath`、`sourceRef`、`artifactVersionId`。
- `SnapshotResult`: `artifact` と directory の場合の `manifest`。
- `mediaTypeForPath(path)`、`validateRelativeArtifactPath(path)`、`validateDirectoryManifest(manifest)`。
- `snapshotPath(store, sourcePath, options?)`: file または directory を snapshot。
- `snapshotOutputDirectory(store, outputRoot, executionId)`: output の各 top-level entry を snapshot。
- `readDirectoryManifest(store, artifact)`、`materializeArtifact(store, artifact, destination)`。

### Outbox

Workspace の completed Human Task 出力を managed outbox に反映する API です。ユーザーが作成した未管理ファイルは削除しません。

- `OUTBOX_MARKER_DIRECTORY`
- `OUTBOX_CONFLICT_DIRECTORY`
- `OutboxEntry`
- `OutboxReconcileResult`
- `getOutboxPlan(paths, state)`
- `reconcileOutbox(paths, state, store)`

`WorkOrchestrator` は Workspace がある場合、Domain commit 後に outbox の derived view を再調整します。

## 9. Validation / canonical helpers

`validateAndHashDefinition(input)` は Definition の構造、ID、binding、contract、schema、dynamic expansion 制約を検証し、`ValidatedDefinition` を返します。無効な入力では `DomainError` の `DEFINITION_INVALID` を投げます。`findStep(root, id)` は Step tree を探索します。`definitionWithoutHash()` と `definitionCanonicalJson()` は hash 対象を扱う low-level helper です。

canonical module の API は次のとおりです。

- `canonicalJson(value)`
- `sha256(value)`
- `hashJson(value)`
- `cloneJson(value)`
- `jsonPointer(value, pointer)`
- `isValidJsonPointer(pointer)`

## 10. Temporal integration

### 推奨 facade

`createWorkOrchestratorWorker(options)` は WorkSession Workflow と Registry / Agent Activity を登録した Temporal Worker を生成します。`runWorkOrchestratorWorker(options)` は生成後に `worker.run()` します。`connectWorkOrchestratorClient(options)` は Temporal Connection と Client facade を生成します。

`WorkOrchestratorTemporalClient` の主要 method は次のとおりです。

| method | 説明 |
| --- | --- |
| `start(input)` | `sessionId` を Workflow ID として Workflow を開始する。 |
| `claimTask(handle, input)` | claim Update を送る。 |
| `releaseTask(handle, input)` | release Update を送る。 |
| `completeHumanTask(handle, input)` | Human completion Update を送る。 |
| `resumeAgentTask(handle, input)` | Agent manual retry Update を送る。 |
| `cancelSession(handle, input)` | cancellation Update を送る。 |
| `receiveExternalEvent(handle, input)` | external event Update を送る。 |

`WorkOrchestratorWorkerOptions` は Temporal `WorkerOptions` に `runtime?: TemporalWorkerRuntimeOptions` と `workflowsPath?: string` を加えたものです。`ConnectWorkOrchestratorClientOptions` は `connection?`、`connectionOptions?`、`namespace?`、必須の `taskQueue` を持ちます。

### Temporal contract

`TemporalWorkflowInput` は `sessionId`、`workDefinitionId`、任意の `revision`、`input`、`actor`、task queue、`agentScheduleToStartTimeoutMs`、Continue-As-New 用 state、`inputArtifacts`、`bootstrapManifest` を持ちます。`TemporalStartSessionInput`、`TemporalCommitInput`、`TemporalAgentResultInput` はそれぞれ Session 初期化、command commit、Agent result commit の Activity 入力です。

`TemporalWorkerRuntimeOptions` の主な項目は `registryPath`、`artifactRoot`、`registry`、`artifactStore`、`workers`、`agentAdapter`、`cancellationGraceMs`、`heartbeatIntervalMs` です。`registryPath` / `artifactRoot` を渡す場合、Activity factory はそれらを初期化せず、既存 authority として `Registry.open()` / `ArtifactStore.open()` します。Worker path 設定が persistence の初期化や migration を自動的に行うわけではありません。

### Raw Temporal primitive

root からは次の primitive も export されています。

- `workSessionWorkflow`
- `claimTaskUpdate`、`releaseTaskUpdate`、`completeHumanTaskUpdate`
- `resumeAgentTaskUpdate`、`cancelSessionUpdate`、`receiveExternalEventUpdate`
- `runtimeStateQuery`
- `createTemporalActivities()`
- `TEMPORAL_ACTIVITY_DEFAULTS`

`TEMPORAL_ACTIVITY_DEFAULTS` は Registry / Agent Activity の timeout、heartbeat、retry、cancellation grace の既定値を含みます。

`TemporalSessionRuntime` は Temporal SDK に依存しない Workflow ID / run chain / safe-point の契約模型です。`continueAsNew()` は command、commit、Agent Activity、mutation handler、timer transition が safe な場合だけ run number を進めます。

## 11. CLI API と利用モデル

公開 CLI の operator 経路は次のとおりです。

```bash
npx work-orchestrator init .
npx work-orchestrator --workspace . --actor local-user
npx work-orchestrator --actor local-user
npx work-orchestrator worker ./my-workspace
```

対話 mode の `new` は Workspace Registry に登録済みの Definition を選択し、選択した revision から `startSessionFromWorkspace()` を呼びます。CLI は Definition を作成・登録しません。Definition の登録は `WorkOrchestrator.registerDefinition()` で行います。最初の positional token は command として解釈されるため、対話 mode の Workspace 選択に positional path は使いません。

CLI module の export は次のとおりです。

- `CliIO`
- `createReadlineIO()`
- `InteractiveCliOptions`
- `CliOrchestrator`
- `TemporalCliOrchestrator`
- `runInteractiveCli()`
- `runCli()`

## 12. Low-level Domain / state machine API

`createInitialRuntimeState(definition, sessionId, input, artifacts?)` は初期 `RuntimeState` を生成し、`reduceCommand(state, envelope, context)` は pure Domain reducer です。`ReducerContext` は現在 `workers` を提供します。reducer を直接使う場合、Registry の receipt / commit、Artifact materialisation、Agent Activity の実行は呼び出し側の責務です。

`sessionMachine`、`taskMachine`、`executionMachine` は XState v5 machine です。`transitionSession()`、`transitionTask()`、`transitionExecution()` は state と event から次 state を得て、`canTransitionSession()`、`canTransitionTask()`、`canTransitionExecution()` は遷移可否を確認します。

`DomainError` は `code: DomainErrorCode`、message、optional `details: JsonValue` を持ちます。`ReconciliationResult` の status は `consistent | temporarily_lagging | invariant_violation | unknown` です。

## 13. Complete root export index

`src/index.ts` は次の全モジュールを root から再 export しています。以下はその module ごとの named export 完全索引です。source module 名は分類用であり、subpath import を示しません。

### Contracts (`contracts.ts`)

```text
JsonPrimitive, JsonValue, WorkerKind, SessionState, TaskState,
ExecutionState, ScopeState, WaitKind, RetryPolicy, TaskBudgets,
TaskContract, InputBinding, TaskStep, SequenceStep, ChoiceStep,
ParallelAllStep, WaitEventStep, NoopStep, WaitTimerStep,
DynamicProposalPolicy, DynamicExpandStep, Step, WorkDefinition, ActorRef,
CommandEnvelope, ExternalEvent, WorkerProfile, ExecutionGrant,
ScopeRuntime, TaskRuntime, ExecutionRuntime, WaitRuntime, BufferedEvent,
ArtifactVersionRuntime, RuntimeState, TaskProposal, ProducedArtifact,
AgentRunRequest, AgentRunResult, DomainCommand, DomainErrorCode,
DomainError, DomainFact, DomainCommit, RuntimeIntent, ReductionAccepted,
ReductionRejected, Reduction, ReconciliationResult
```

### Canonical (`canonical.ts`)

```text
canonicalJson, sha256, hashJson, cloneJson, jsonPointer,
isValidJsonPointer
```

### Validation (`validation.ts`)

```text
ValidatedDefinition, validateAndHashDefinition, findStep,
definitionWithoutHash, definitionCanonicalJson
```

### Machines (`machines.ts`)

```text
sessionMachine, taskMachine, executionMachine, transitionSession,
transitionTask, transitionExecution, canTransitionSession,
canTransitionTask, canTransitionExecution
```

### Artifact store (`artifact-store.ts`)

```text
ARTIFACT_STORE_FORMAT_VERSION, ARTIFACT_STORE_MARKER, StagedBlob,
ArtifactStoreMarker, ArtifactStore
```

### Artifact (`artifact.ts`)

```text
DirectoryArtifactManifestV1, SnapshotOptions, SnapshotResult,
mediaTypeForPath, validateRelativeArtifactPath, validateDirectoryManifest,
snapshotPath, snapshotOutputDirectory, readDirectoryManifest,
materializeArtifact
```

### Workspace (`workspace.ts`)

```text
WORKSPACE_FORMAT_VERSION, WORKSPACE_STATE_PATH, WORKSPACE_REGISTRY_PATH,
WORKSPACE_ARTIFACTS_PATH, WorkspaceConfig, WorkspaceState, WorkspacePaths,
OpenWorkspace, InitWorkspaceResult, workspacePaths, initWorkspace,
openWorkspace, findWorkspace, resolveWorkspace, safeWorkspaceKey,
ExecutionWorkspace, executionWorkspace, prepareExecutionWorkspace
```

### Registry (`registry.ts`)

```text
CommitResult, InitialSessionOptions, RegistryPage, RegistryOptions,
REGISTRY_APPLICATION_ID, REGISTRY_SCHEMA_VERSION, Registry, RegistryReader
```

### Domain (`domain.ts`)

```text
ReducerContext, createInitialRuntimeState, reduceCommand
```

### Runtime (`runtime.ts`)

```text
AgentAdapter, FakeAgentPlan, FakeAgentAdapter, CodexAdapter,
CodexCliAdapterOptions, createCodexCliAdapter, StartSessionInput,
OrchestratorOptions, TemporalSafePoint, TemporalSessionRuntime,
WorkOrchestrator, deliverExternalEvent
```

### Temporal contracts (`temporal-contracts.ts`)

```text
TemporalWorkflowInput, TemporalWorkflowResult, TemporalCommitInput,
TemporalStartSessionInput, TemporalAgentResultInput, TemporalCommitResult,
TemporalActivities, TemporalWorkerRuntimeOptions, TemporalCommandUpdateInput,
ClaimTaskUpdateInput, ReleaseTaskUpdateInput, CompleteHumanTaskUpdateInput,
ResumeAgentTaskUpdateInput, CancelSessionUpdateInput,
ReceiveExternalEventUpdateInput, TemporalPublicUpdateInput
```

### Temporal Workflow (`temporal-workflow.ts`)

```text
claimTaskUpdate, releaseTaskUpdate, completeHumanTaskUpdate,
resumeAgentTaskUpdate, cancelSessionUpdate, receiveExternalEventUpdate,
runtimeStateQuery, workSessionWorkflow
```

### Temporal Activities (`temporal-activities.ts`)

```text
TEMPORAL_ACTIVITY_DEFAULTS, createTemporalActivities
```

### Temporal Worker (`temporal-worker.ts`)

```text
WorkOrchestratorWorkerOptions, createWorkOrchestratorWorker,
runWorkOrchestratorWorker
```

### Temporal Client (`temporal-client.ts`)

```text
WorkOrchestratorClientOptions, ConnectWorkOrchestratorClientOptions,
WorkOrchestratorTemporalClient, connectWorkOrchestratorClient
```

### Outbox (`outbox.ts`)

```text
OUTBOX_MARKER_DIRECTORY, OUTBOX_CONFLICT_DIRECTORY, OutboxEntry,
OutboxReconcileResult, getOutboxPlan, reconcileOutbox
```

### CLI (`cli.ts`)

```text
CliIO, createReadlineIO, InteractiveCliOptions, CliOrchestrator,
TemporalCliOrchestrator, runInteractiveCli, runCli
```

### Compatibility (`index.ts`)

```ts
hello(name: string): string
```

`hello()` は旧スケルトン API の後方互換用で、orchestration の入口ではありません。
