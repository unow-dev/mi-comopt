# Work Task Sequence: Work Orchestrator 利用者向けドキュメント更新

## Purpose

Work Orchestrator の利用者が、Workspace の初期化から WorkDefinition の登録、Session の開始、Human Task の完了までを公開 API とパッケージ配布物だけで理解・実行でき、API リファレンスと配布内容が現行実装に一致した状態になる。

## Task Sequence

- [x] 1. 要求整理の範囲で、AIエージェントが、決定済み事項、対象範囲、非対象範囲および仕様レビューが必要となる条件を確認する。
- [x] 2. 仕様整理の範囲で、AIエージェントが、Workspace-firstの利用モデル、公開APIの契約、ドキュメント更新順序、配布要件および受入条件を整理する。
- [x] 3. 公開API契約の範囲で、AIエージェントが、Workspace API、OrchestratorOptions、StartSessionInput、公開メソッド、永続化ライフサイクルおよびroot export indexを現行実装に合わせて更新する。
- [x] 4. 正規利用ガイドの範囲で、AIエージェントが、Workspace-backed Quickstart、Human Taskの一連の処理、startSessionFromWorkspace()、対話CLIおよび補助的なin-memory利用を整合した内容へ更新する。
- [x] 5. パッケージ入口ドキュメントの範囲で、AIエージェントが、Workspace-firstの通常利用、公開パッケージ向けCLI例、登録済みDefinitionを使う対話CLIおよび詳細資料への導線を整理する。
- [x] 6. パッケージ配布境界の範囲で、AIエージェントが、利用者向けdocsの同梱設定と、README・docs・主要distファイルの配布を確認する回帰テストを整備する。
- [x] 7. 自動検証の範囲で、AIエージェントまたはCIが、build、既存テスト、npm pack dry-runおよび配布一覧の受入条件を検証する。
- [x] 8. パッケージ利用者フローの範囲で、AIエージェントまたはCIが、生成したtarballを空のconsumerへ導入し、Workspace初期化、Definition登録、Session開始、Human Task完了およびSessionのcompleted遷移を検証する。
- [x] 9. スコープ適合性の範囲で、AIエージェントが、runtime・CLI・Workspace behaviorを変更していないこと、追加CLIや自動配線を導入していないこと、および関連変更が同一の作業単位に含まれることを確認する。
- [ ] 10. リリース判断の範囲で、人間が、未解決の仕様不整合、未達の受入条件、既知の制約およびリリース可否を判断する。
- [x] 11. 作業結果の範囲で、AIエージェントが、実施内容、検証結果、既知の制約および仕様レビュー事項を記録する。

## Work Notes

- 実装順序は、公開API契約の更新、正規利用ガイドの更新、パッケージ入口ドキュメントの更新、配布設定・回帰テスト、プロジェクトテスト、packed-consumer検証の順とする。
- 正規利用モデルはWorkspace-firstとし、基本導線は `npx work-orchestrator init .`、`openWorkspace()`、明示的な `registry`・`artifactStore`・`workspace` を渡した `WorkOrchestrator` 構築、`registerDefinition()`、`startSession()` とする。
- 対話CLIの明示的なWorkspace指定は `npx work-orchestrator --workspace . --actor local-user` とし、`work-orchestrator [workspace]` 形式は記載しない。CLIの `new` はRegistryに登録済みのDefinitionを利用する。
- Workspaceを指定しても `registry` と `artifactStore` が自動的に接続されるとは記載しない。永続化の通常ライフサイクルは `initialize()` / `open()` とし、`open()` は初期化やmigrationを行うものとして扱わない。
- 基本Quickstartは `schemaVersion: 2` の単一Human Task、`randomUUID()` による一意なSession ID、`finally` での `workspace.registry.close()` を含める。`startSessionFromWorkspace()` はfilesystem inputのsnapshot用途として別途説明する。
- `StartSessionInput` の省略された `revision` を `0` と説明せず、登録済みDefinitionでは同一IDの最大revisionを選択する現行挙動を記載する。
- `docs/archive` 配下は参照しない。作業対象・検証条件の詳細は同ディレクトリの `IMPLEMENTATION_SPEC.md`、`IMPLEMENTATION_PLAN.md`、`ACCEPTANCE_CHECKLIST.md` および `SOURCE_AUDIT.md` を正とする。
- 作業の進行に応じて完了したタスクを `[x]` に更新し、検証結果や判断事項はこの Work Notes に追記する。
- ベースラインコミットは `e591d5f`（`chore: baseline documentation update work`）。
- `package/docs/API_REFERENCE.md`、`package/docs/README.md`、`package/README.md` を現行公開契約とWorkspace-first利用モデルに合わせて更新した。
- `package/package.json` の配布対象に `docs` を追加し、`package/tests/package-distribution.test.js` でREADME・docs・主要distファイルの `npm pack --dry-run --json` 同梱を検証するようにした。
- `npm run build`、`npm test`（38 tests pass）、`npm pack --dry-run --json` および公開名のAPIリファレンス照合に成功した。
- 生成tarballを空のconsumerへ導入し、インストール済みdocs、`npx work-orchestrator init .`、Definition登録、Session開始、Human Task完了、`completed` 遷移、Quickstart再実行を確認した。
- `package/src` のruntime・CLI・Workspace behaviorは変更していない。新規CLI command、Definition登録CLI、positional interactive Workspace、自動Registry/ArtifactStore配線、migration変更は導入していない。
- タスク10のリリース可否は、人間による仕様レビュー・判断事項として未完了。
