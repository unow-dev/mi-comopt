# Implementation plan

Use this order so later documentation layers depend on an already corrected contract reference rather than the reverse.

## Step 1 — Correct the API contract reference

Edit `package/docs/API_REFERENCE.md` first.

- Add Workspace API coverage.
- Correct `OrchestratorOptions`.
- Correct `StartSessionInput` and revision semantics.
- Add missing public WorkOrchestrator methods.
- Correct persistent-storage lifecycle language.
- Correct Temporal path/open semantics.
- Complete the root export index against `src/index.ts` and each re-exported module.

Do not change implementation code to make the reference simpler.

## Step 2 — Rewrite the canonical usage guide

Edit `package/docs/README.md`.

- Promote Workspace-backed flow to main Quickstart.
- Use schema v2 single Human Task.
- Use a unique Session ID (`randomUUID()`).
- Use explicit `registry`, `artifactStore`, and `workspace` when constructing the orchestrator.
- Keep `startSession()` as the base Session-start API.
- Add `startSessionFromWorkspace()` as a separate filesystem-input path.
- Move in-memory flow later and label it secondary.
- Update persistence/Temporal sections to match Step 1.

## Step 3 — Simplify the package entry README

Edit `package/README.md`.

- Explain Workspace-first in a short form.
- Use `npx work-orchestrator init .`.
- Use `npx work-orchestrator --workspace . --actor local-user` for explicit interactive Workspace selection.
- Remove/replace repository-only `npm run cli -- ...` package-consumer examples.
- Avoid duplicating the full Quickstart; link to `docs/README.md`.

## Step 4 — Fix package contents

Edit `package/package.json` and add `docs` to `files`.

## Step 5 — Add the distribution regression test

Add `package/tests/package-distribution.test.js` (or an equivalently named `node:test` file).

Assert the tarball dry-run includes both docs and key `dist` entry points.

## Step 6 — Run project tests

From the package development environment, run the existing test command:

```bash
npm test
```

Resolve only failures caused by the intended changes. Behavioral test failures that require runtime changes should be treated as scope expansion and reported separately.

## Step 7 — Verify packed-consumer flow

Build/pack the package, install the generated tarball into an empty temporary consumer, then execute the canonical Workspace-backed Quickstart.

The verification must prove:

- CLI `init` creates/openable Workspace authority.
- the package docs are actually present in the installed package.
- Definition registration succeeds.
- a Session can be started.
- the generated Human Task can be claimed and completed.
- the final Session state is `completed`.

## PR structure

One PR. Do not split docs, package manifest, and distribution regression test into separately mergeable PRs.

Logical commits are optional. If used, a useful order is:

1. `docs: sync API reference with public surface`
2. `docs: make workspace flow canonical`
3. `packaging: ship docs and verify package contents`

The final merge unit must contain all changes together.
