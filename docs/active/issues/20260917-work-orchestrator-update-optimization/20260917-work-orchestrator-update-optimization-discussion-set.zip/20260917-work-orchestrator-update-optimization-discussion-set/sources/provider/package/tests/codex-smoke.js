import assert from "node:assert/strict";
import { createCodexCliAdapter } from "../dist/index.js";

const request = {
  task: {
    taskId: "codex-smoke-task",
    sessionId: "codex-smoke-session",
    scopeId: "codex-smoke-scope",
    stepId: "codex-smoke-step",
    workerKind: "agent",
    goal: "Return the requested smoke-test JSON response.",
    contract: {
      workerKind: "agent",
      requiredCapabilities: [],
      requestedPermissions: [],
      retryPolicy: { maxAttempts: 1 },
      budgets: { maxWallTimeMs: 120_000 },
    },
    inputs: {},
    inputArtifactVersionIds: [],
    state: "active",
    acceptedOutputArtifactVersionIds: [],
  },
  execution: {
    executionId: "codex-smoke-execution",
    taskId: "codex-smoke-task",
    attempt: 1,
    state: "running",
    producedArtifactVersionIds: [],
    startedAtOrder: 1,
  },
  grant: {
    workerId: "codex-smoke-worker",
    workerRevision: 1,
    capabilities: [],
    permissions: [],
    budgets: { maxWallTimeMs: 120_000 },
  },
};

const adapter = createCodexCliAdapter({
  cwd: process.cwd(),
  executable: process.env.CODEX_CLI_PATH ?? "codex",
  promptBuilder: () => 'Do not modify files or run commands. Reply with exactly this JSON object and no markdown: {"status":"succeeded","result":{"smoke":"ok"}}',
});

const smoke = async () => {
  const result = await adapter.run(request);
  assert.equal(result.status, "succeeded");
  assert.deepEqual(result.result, { smoke: "ok" });
};

await smoke();
