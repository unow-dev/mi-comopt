/** Work Orchestration v1 の実行時契約。 */

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export type WorkerKind = "human" | "agent";
export type SessionState = "running" | "cancelling" | "completed" | "cancelled";
export type TaskState = "ready" | "active" | "waiting" | "completed" | "cancelled";
export type ExecutionState = "running" | "succeeded" | "failed" | "cancelled" | "abandoned";
export type ScopeState = "active" | "completed" | "cancelled";
export type WaitKind = "event" | "timer";

export interface RetryPolicy {
  maxAttempts: number;
  manualRetryAllowed?: boolean;
  interventionOnExhaustion?: boolean;
}

export interface TaskBudgets {
  maxWallTimeMs: number;
  maxTokens?: number;
  maxCost?: number;
}

export interface TaskContract {
  workerKind: WorkerKind;
  requiredCapabilities: string[];
  requestedPermissions: string[];
  retryPolicy: RetryPolicy;
  /** Agent Tasks require this in schema v2; Human Tasks intentionally do not. */
  budgets?: TaskBudgets;
  outputSchema?: JsonValue;
  resultSchema?: JsonValue;
  allowedOutcomes?: string[];
}

export interface InputBinding {
  source: "session" | "step" | "task";
  path: string;
  stepId?: string;
}

export interface TaskStep {
  kind: "task";
  id: string;
  goal: string;
  contract: TaskContract;
  inputBindings?: Record<string, InputBinding>;
}

export interface SequenceStep {
  kind: "sequence";
  id: string;
  children: Step[];
}

export interface ChoiceStep {
  kind: "choice";
  id: string;
  decision: TaskStep | InputBinding;
  branches: Record<string, Step>;
}

export interface ParallelAllStep {
  kind: "parallelAll";
  id: string;
  branches: Record<string, Step>;
}

export interface WaitEventStep {
  kind: "waitEvent";
  id: string;
  eventType: string;
  correlationKey: string | InputBinding;
}

export interface NoopStep {
  kind: "noop";
  id: string;
  result?: JsonValue;
}

export interface WaitTimerStep {
  kind: "waitTimer";
  id: string;
  delayMs: number;
}

export interface DynamicProposalPolicy {
  workerKind: WorkerKind;
  requiredCapabilities: string[];
  requestedPermissions: string[];
  retryPolicy: RetryPolicy;
  budgets: TaskBudgets;
  goalPrefix?: string;
  allowedOutcomes?: string[];
}

export interface DynamicExpandStep {
  kind: "dynamicExpand";
  id: string;
  planner: TaskStep;
  strategy: "sequence" | "parallelAll";
  proposalPolicy: DynamicProposalPolicy;
  maxTasks: number;
}

export type Step =
  | TaskStep
  | SequenceStep
  | ChoiceStep
  | ParallelAllStep
  | WaitEventStep
  | NoopStep
  | WaitTimerStep
  | DynamicExpandStep;

export interface WorkDefinition {
  workDefinitionId: string;
  revision: number;
  schemaVersion: number;
  root: Step;
  definitionHash?: string;
  limits?: {
    maxBufferedExternalEvents?: number;
    maxDynamicTasksPerSession?: number;
  };
}

export interface ActorRef {
  actorId: string;
  actorType?: string;
}

export interface CommandEnvelope<C extends DomainCommand = DomainCommand> {
  schemaVersion: 1;
  sessionId: string;
  commandId: string;
  actor: ActorRef;
  command: C;
}

export interface ExternalEvent {
  eventId: string;
  eventType: string;
  correlationKey: string;
  payload: JsonValue;
  occurredAt?: string;
}

export interface WorkerProfile {
  workerId: string;
  revision: number;
  enabled: boolean;
  capabilities: string[];
  enforceablePermissions: string[];
  enforceableBudgets: string[];
  routingPriority: number;
  physicalAvailable?: boolean;
}

export interface ExecutionGrant {
  workerId: string;
  workerRevision: number;
  capabilities: string[];
  permissions: string[];
  budgets: TaskBudgets;
}

export interface ScopeRuntime {
  scopeId: string;
  stepId: string;
  kind: Step["kind"];
  state: ScopeState;
  result?: JsonValue;
  childIds: string[];
  cursor: number;
  taskId?: string;
  generatedTask?: TaskStep;
  generatedOrdinal?: number;
  inputArtifactVersionIds?: string[];
  generatedParameters?: JsonValue;
  decisionTaskId?: string;
  selectedBranch?: string;
  plannerScopeId?: string;
  generatedChildIds?: string[];
  proposals?: TaskProposal[];
  waitId?: string;
}

export interface TaskRuntime {
  taskId: string;
  sessionId: string;
  scopeId: string;
  stepId: string;
  workerKind: WorkerKind;
  goal: string;
  contract: TaskContract;
  inputs: Record<string, JsonValue>;
  inputArtifactVersionIds: string[];
  state: TaskState;
  currentExecutionId?: string;
  claimantActorId?: string;
  completedBy?: ActorRef;
  outcome?: string;
  result?: JsonValue;
  comment?: string;
  attention?: string;
  interventionForTaskId?: string;
  generatedOrdinal?: number;
  acceptedOutputArtifactVersionIds: string[];
}

export interface ExecutionRuntime {
  executionId: string;
  taskId: string;
  attempt: number;
  workerId?: string;
  workerRevision?: number;
  grant?: ExecutionGrant;
  state: ExecutionState;
  cancellationRequested?: boolean;
  failure?: JsonValue;
  result?: JsonValue;
  comment?: string;
  producedArtifactVersionIds: string[];
  startedAtOrder: number;
}

export interface WaitRuntime {
  waitId: string;
  scopeId: string;
  kind: WaitKind;
  state: "waiting" | "consumed" | "cancelled";
  eventType?: string;
  correlationKey?: string;
  delayMs?: number;
  createdAtOrder: number;
  consumedEventId?: string;
}

export interface BufferedEvent extends ExternalEvent {
  acceptedOrder: number;
  consumedByWaitId?: string;
}

export interface ArtifactVersionRuntime {
  artifactVersionId: string;
  artifactKind: "file" | "directory";
  blobHash: string;
  size: number;
  mediaType: string;
  logicalPath?: string;
  origin: { kind: "execution"; executionId: string } | { kind: "external"; sourceRef: string };
  immutable: true;
}

export interface RuntimeState {
  version: 1;
  revision: number;
  session: {
    sessionId: string;
    workDefinitionId: string;
    definitionRevision: number;
    definitionHash: string;
    state: SessionState;
    input: JsonValue;
    rootScopeId: string;
    attention?: string;
  };
  definition: WorkDefinition;
  scopes: Record<string, ScopeRuntime>;
  tasks: Record<string, TaskRuntime>;
  executions: Record<string, ExecutionRuntime>;
  waits: Record<string, WaitRuntime>;
  events: BufferedEvent[];
  resultsByStepId: Record<string, JsonValue>;
  artifacts: Record<string, ArtifactVersionRuntime>;
  order: number;
}

export interface TaskProposal {
  type: string;
  goal: string;
  inputArtifactVersionIds: string[];
  parameters: JsonValue;
}

export interface ProducedArtifact {
  content: string | Uint8Array;
  mediaType?: string;
  reliableRunReport?: boolean;
}

export interface AgentRunRequest {
  session: {
    sessionId: string;
    workDefinitionId: string;
    definitionRevision: number;
  };
  task: TaskRuntime;
  execution: ExecutionRuntime;
  grant: ExecutionGrant;
  /** Local workspace is a derived execution view, never the artifact authority. */
  workspace?: {
    root: string;
    inputPath: string;
    workPath: string;
    outputPath: string;
  };
}

export interface AgentRunResult {
  status: "succeeded" | "blocked" | "failed" | "cancelled" | "abandoned";
  /** v2 routing signal. It is deliberately not read from result. */
  outcome?: string;
  result?: JsonValue;
  failure?: JsonValue;
  artifacts?: ProducedArtifact[];
}

export type DomainCommand =
  | { type: "advance" }
  | { type: "claimTask"; taskId: string }
  | { type: "releaseTask"; taskId: string }
  | {
      type: "completeHumanTask";
      taskId: string;
      outcome?: string;
      result?: JsonValue;
      comment?: string;
      artifactVersions?: ArtifactVersionRuntime[];
    }
  | { type: "resumeAgentTask"; taskId: string }
  | { type: "cancelSession"; reason?: string }
  | { type: "receiveExternalEvent"; event: ExternalEvent }
  | { type: "timerFired"; waitId: string }
  | {
      type: "agentResult";
      executionId: string;
      status: AgentRunResult["status"];
      outcome?: string;
      result?: JsonValue;
      failure?: JsonValue;
      artifactVersions?: ArtifactVersionRuntime[];
    };

export type DomainErrorCode =
  | "INVALID_COMMAND"
  | "SESSION_NOT_FOUND"
  | "SESSION_TERMINAL"
  | "INVALID_STATE"
  | "TASK_NOT_FOUND"
  | "NOT_CLAIM_OWNER"
  | "OUTCOME_INVALID"
  | "NO_ELIGIBLE_WORKER"
  | "MANUAL_RETRY_NOT_ALLOWED"
  | "EVENT_BUFFER_FULL"
  | "DUPLICATE_EVENT"
  | "WAIT_NOT_FOUND"
  | "IDEMPOTENCY_KEY_CONFLICT"
  | "DEFINITION_INVALID"
  | "DEFINITION_IMMUTABLE"
  | "ARTIFACT_NOT_FOUND"
  | "WORKSPACE_REQUIRED"
  | "COMMENT_INVALID"
  | "RESULT_TOO_LARGE"
  | "WORKSPACE_METADATA_MISSING"
  | "WORKSPACE_CORRUPT"
  | "FUTURE_FORMAT"
  | "REGISTRY_SCHEMA_INVALID"
  | "ARTIFACT_STORE_CORRUPT"
  | "INVARIANT_VIOLATION";

export class DomainError extends Error {
  readonly code: DomainErrorCode;
  readonly details?: JsonValue;

  constructor(code: DomainErrorCode, message: string, details?: JsonValue) {
    super(message);
    this.name = "DomainError";
    this.code = code;
    this.details = details;
  }
}

export interface DomainFact {
  type: string;
  entityId: string;
  data?: JsonValue;
}

export interface DomainCommit {
  sessionId: string;
  revision: number;
  commandId: string;
  commandType: string;
  facts: DomainFact[];
  resultingStateHash: string;
}

export type RuntimeIntent =
  | { kind: "dispatchAgent"; executionId: string }
  | { kind: "cancelAgent"; executionId: string }
  | { kind: "scheduleTimer"; waitId: string; delayMs: number };

export interface ReductionAccepted {
  kind: "accepted";
  nextState: RuntimeState;
  facts: DomainFact[];
  intents: RuntimeIntent[];
  response: JsonValue;
  advanceRevision: boolean;
}

export interface ReductionRejected {
  kind: "rejected";
  error: DomainError;
  response: JsonValue;
}

export type Reduction = ReductionAccepted | ReductionRejected;

export interface ReconciliationResult {
  status: "consistent" | "temporarily_lagging" | "invariant_violation" | "unknown";
  temporalRevision?: number;
  registryRevision?: number;
  temporalStateHash?: string;
  registryStateHash?: string;
}
