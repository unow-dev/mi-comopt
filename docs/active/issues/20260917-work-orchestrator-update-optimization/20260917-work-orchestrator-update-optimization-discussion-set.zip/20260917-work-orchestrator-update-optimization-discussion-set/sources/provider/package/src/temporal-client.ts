import { Client, Connection, type ConnectionOptions, type WorkflowHandle } from "@temporalio/client";
import {
  cancelSessionUpdate,
  claimTaskUpdate,
  completeHumanTaskUpdate,
  receiveExternalEventUpdate,
  releaseTaskUpdate,
  resumeAgentTaskUpdate,
  workSessionWorkflow,
} from "./temporal-workflow.js";
import type {
  CancelSessionUpdateInput,
  ClaimTaskUpdateInput,
  CompleteHumanTaskUpdateInput,
  ReceiveExternalEventUpdateInput,
  ReleaseTaskUpdateInput,
  ResumeAgentTaskUpdateInput,
  TemporalWorkflowInput,
} from "./temporal-contracts.js";

export interface WorkOrchestratorClientOptions {
  client: Client;
  taskQueue: string;
}

export interface ConnectWorkOrchestratorClientOptions {
  connection?: Connection;
  connectionOptions?: ConnectionOptions;
  namespace?: string;
  taskQueue: string;
}

export class WorkOrchestratorTemporalClient {
  readonly client: Client;
  readonly taskQueue: string;

  constructor(options: WorkOrchestratorClientOptions) {
    this.client = options.client;
    this.taskQueue = options.taskQueue;
  }

  async start(input: TemporalWorkflowInput): Promise<WorkflowHandle<typeof workSessionWorkflow>> {
    return this.client.workflow.start(workSessionWorkflow, {
      workflowId: input.sessionId,
      taskQueue: this.taskQueue,
      args: [{ ...input, registryTaskQueue: input.registryTaskQueue ?? this.taskQueue, agentTaskQueue: input.agentTaskQueue ?? this.taskQueue }],
    });
  }

  claimTask(handle: WorkflowHandle<typeof workSessionWorkflow>, input: ClaimTaskUpdateInput): Promise<unknown> {
    return handle.executeUpdate(claimTaskUpdate, { args: [input] });
  }

  releaseTask(handle: WorkflowHandle<typeof workSessionWorkflow>, input: ReleaseTaskUpdateInput): Promise<unknown> {
    return handle.executeUpdate(releaseTaskUpdate, { args: [input] });
  }

  completeHumanTask(handle: WorkflowHandle<typeof workSessionWorkflow>, input: CompleteHumanTaskUpdateInput): Promise<unknown> {
    return handle.executeUpdate(completeHumanTaskUpdate, { args: [input] });
  }

  resumeAgentTask(handle: WorkflowHandle<typeof workSessionWorkflow>, input: ResumeAgentTaskUpdateInput): Promise<unknown> {
    return handle.executeUpdate(resumeAgentTaskUpdate, { args: [input] });
  }

  cancelSession(handle: WorkflowHandle<typeof workSessionWorkflow>, input: CancelSessionUpdateInput): Promise<unknown> {
    return handle.executeUpdate(cancelSessionUpdate, { args: [input] });
  }

  receiveExternalEvent(handle: WorkflowHandle<typeof workSessionWorkflow>, input: ReceiveExternalEventUpdateInput): Promise<unknown> {
    return handle.executeUpdate(receiveExternalEventUpdate, { args: [input] });
  }
}

export async function connectWorkOrchestratorClient(options: ConnectWorkOrchestratorClientOptions): Promise<WorkOrchestratorTemporalClient> {
  const connection = options.connection ?? await Connection.connect(options.connectionOptions);
  return new WorkOrchestratorTemporalClient({ client: new Client({ connection, namespace: options.namespace }), taskQueue: options.taskQueue });
}
