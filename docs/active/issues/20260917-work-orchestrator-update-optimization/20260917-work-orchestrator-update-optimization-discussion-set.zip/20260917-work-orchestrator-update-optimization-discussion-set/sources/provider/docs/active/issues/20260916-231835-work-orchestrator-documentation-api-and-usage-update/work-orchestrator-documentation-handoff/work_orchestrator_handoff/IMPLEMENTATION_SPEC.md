# Implementation specification

## 1. Scope

Update the package-facing documentation so a new consumer can follow the supported lifecycle from Workspace initialization through WorkDefinition registration and Session execution without relying on undocumented repository-only commands or inaccurate API signatures.

In the same PR, make the package distribution actually contain the documentation linked from its package README and add a regression test for that distribution boundary.

## 2. Adopted usage model

### Normal path: Workspace-first

The normal path is:

```text
npx work-orchestrator init .
  -> openWorkspace(".")
  -> new WorkOrchestrator({
       registry: workspace.registry,
       artifactStore: workspace.artifactStore,
       workspace,
     })
  -> registerDefinition(...)
  -> startSession(...)
  -> getSessionView(...)
  -> claimTask(...)
  -> completeHumanTask(...)
```

`new WorkOrchestrator()` without persistent storage remains valid but is secondary: use it for conceptual/minimal/in-memory examples, not as the main production-oriented Quickstart.

### Workspace initialization

CLI is the primary operator-facing initialization example:

```bash
npx work-orchestrator init .
```

The programmatic equivalent, `initWorkspace()`, must also be documented.

### Interactive CLI

Document interactive mode as:

```bash
npx work-orchestrator --workspace . --actor local-user
```

If the process runs from within a Workspace tree and relies on Workspace discovery, this is also valid:

```bash
npx work-orchestrator --actor local-user
```

Do not write:

```text
work-orchestrator [workspace] --actor ...
```

The current parser treats the first non-option token as `command`, so that positional form does not select the interactive Workspace.

`init` and `worker` are real commands and may take a positional Workspace path, e.g.:

```bash
npx work-orchestrator init ./my-workspace
npx work-orchestrator worker ./my-workspace
```

### Definition registration

Do not add or imply a Definition-registration CLI command.

The documented registration path is the existing public API:

```js
orchestrator.registerDefinition(definition);
```

The interactive CLI is an operator UI over **already registered** definitions. Its `new` flow lists registered definitions and starts from the selected revision.

## 3. `package/README.md`

Purpose: npm/package entry point, not the full manual.

Required changes:

- State that the normal persistent usage path is Workspace-first.
- Show the short lifecycle: init -> open -> register -> start.
- Link to `./docs/README.md` for the full executable walkthrough.
- Link to `./docs/API_REFERENCE.md` for the contract reference.
- Replace repository-only `npm run cli -- ...` consumer examples with package CLI examples (`npx work-orchestrator ...`).
- Use `--workspace` for interactive explicit Workspace selection.
- Explain that the interactive CLI uses definitions already stored in the Workspace Registry.
- Keep in-memory usage, if retained, clearly secondary.
- Avoid duplicating the entire canonical Quickstart code from `docs/README.md`.

## 4. `package/docs/README.md`

Purpose: canonical usage guide.

### Canonical Quickstart

Make the main Quickstart Workspace-backed and use a schema v2 single Human Task.

The flow must demonstrate:

1. `npx work-orchestrator init .`
2. `openWorkspace(".")`
3. construction of `WorkOrchestrator` with **all three** Workspace-related values:
   - `registry: workspace.registry`
   - `artifactStore: workspace.artifactStore`
   - `workspace`
4. `registerDefinition()`
5. `startSession()`
6. `getSessionView()` and locating the generated Human Task
7. `claimTask()`
8. `completeHumanTask()`
9. assertion/check that Session state is `completed`
10. `workspace.registry.close()` in `finally`

Use a unique Session ID so rerunning the Quickstart against the same persistent Workspace does not collide with an existing Session:

```js
import { randomUUID } from "node:crypto";
const sessionId = `quickstart-${randomUUID()}`;
```

Use `schemaVersion: 2` for the new-user example.

### `startSession()` vs `startSessionFromWorkspace()`

Keep the base Quickstart on `startSession()`.

Document `startSessionFromWorkspace()` immediately after or in a dedicated Workspace-input section as the higher-level path when filesystem input should be snapshotted to immutable artifacts/bootstrap metadata at Session start.

Do not make filesystem snapshotting a prerequisite for understanding the base Session lifecycle.

### In-memory usage

If an in-memory example remains, place it after the Workspace-backed path and label it as a minimal/test/conceptual setup.

### Persistence lifecycle

Prefer:

- `initWorkspace()` / `openWorkspace()` for Workspace-oriented use
- `Registry.initialize()` / `Registry.open()` / `Registry.openReadOnly()` when managing Registry separately
- `ArtifactStore.initialize()` / `ArtifactStore.open()` when managing ArtifactStore separately

Do not present direct constructors as the normal persistent lifecycle.

Make clear that `open()` opens an already initialized authority; it is not the initialization/migration command.

### Temporal section

Align path-based Temporal storage descriptions with implementation: paths are opened as already initialized Registry/ArtifactStore authorities.

Do not imply that the worker path configuration initializes persistence automatically.

## 5. `package/docs/API_REFERENCE.md`

Purpose: factual contract reference matching current root exports and current runtime signatures.

### `OrchestratorOptions`

Document the implementation field:

```ts
interface OrchestratorOptions {
  registry?: Registry;
  artifactStore?: ArtifactStore;
  workers?: WorkerProfile[];
  agentAdapter?: AgentAdapter;
  workspace?: OpenWorkspace;
}
```

Important: current implementation does **not** infer `registry` and `artifactStore` from `workspace`. Workspace-backed examples must therefore pass all three explicitly.

### `StartSessionInput`

Replace the stale reference with the implementation shape:

```ts
interface StartSessionInput {
  sessionId: string;
  workDefinitionId?: string;
  revision?: number;
  input?: JsonValue;
  actor?: ActorRef;
  commandId?: string;
  definition?: WorkDefinition;
  inputArtifacts?: ArtifactVersionRuntime[];
  bootstrapManifest?: {
    artifactVersionId: string;
    blobHash: string;
  };
}
```

Do not state that omitted `revision` means revision `0`.

Document the actual selection behavior:

- inline `definition`: use that definition/revision
- registered Definition identified by `workDefinitionId`, no explicit revision: select the highest registered revision for that ID

Inline-definition Session creation is a valid API mode, but it is not the primary onboarding flow; onboarding remains explicit `registerDefinition()` -> `startSession()`.

### Workspace APIs

Add/document the public Workspace exports needed for normal use, including at minimum:

- `initWorkspace()`
- `openWorkspace()`
- `findWorkspace()`
- `resolveWorkspace()`
- relevant public Workspace types

### Public WorkOrchestrator methods

Bring the reference in sync with currently public methods. In particular, do not omit:

- `startSessionFromWorkspace()`
- `completeHumanTaskWithInput()`
- `openHumanTaskWorkspace()`
- `completeHumanTaskFromWorkspace()`
- `deliverExternalEvent()`

Also preserve/document the top-level exported `deliverExternalEvent()` function where applicable.

### Complete root export index

Keep the section genuinely complete.

`src/index.ts` re-exports all of these modules:

- contracts
- canonical
- validation
- machines
- artifact-store
- artifact
- workspace
- registry
- domain
- runtime
- temporal-contracts
- temporal-workflow
- temporal-activities
- temporal-worker
- temporal-client
- outbox
- cli

It also exports compatibility helper `hello()`.

Audit each module's exported declarations against the reference rather than only adding the four obvious missing module groups.

Known missing names in the current reference are listed in `SOURCE_AUDIT.md`.

## 6. `package/package.json`

Change:

```json
"files": [
  "dist",
  "README.md"
]
```

to:

```json
"files": [
  "dist",
  "README.md",
  "docs"
]
```

Reason: package `README.md` links to package-relative documentation, so those exact versioned docs must ship in the tarball.

## 7. Package-distribution regression test

Add a test under `package/tests/`, recommended filename:

`package-distribution.test.js`

The repository already uses `node:test`; do not add a new test framework.

The test should execute `npm pack --dry-run --json` in `package/` after the normal build performed by `npm test`, parse the returned file list, and assert that the package contains at least:

- `README.md`
- `docs/README.md`
- `docs/API_REFERENCE.md`
- built `dist/index.js`
- built `dist/index.d.ts`
- built `dist/cli-entry.js`

A robust implementation should use `npm.cmd` on Windows and `npm` elsewhere and should derive the package directory from `import.meta.url` rather than assuming process cwd.

Illustrative shape (adapt as needed to local test conventions):

```js
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const packageDir = fileURLToPath(new URL("..", import.meta.url));
const npm = process.platform === "win32" ? "npm.cmd" : "npm";

test("published package includes user documentation", () => {
  const raw = execFileSync(npm, ["pack", "--dry-run", "--json"], {
    cwd: packageDir,
    encoding: "utf8",
  });
  const result = JSON.parse(raw);
  const files = new Set(result[0].files.map((entry) => entry.path));

  for (const required of [
    "README.md",
    "docs/README.md",
    "docs/API_REFERENCE.md",
    "dist/index.js",
    "dist/index.d.ts",
    "dist/cli-entry.js",
  ]) {
    assert.ok(files.has(required), `missing from package: ${required}`);
  }
});
```

Do not add AST/documentation-generation infrastructure in this issue.

## 8. Non-goals / change prohibition

Do not implement any of the following as part of this issue:

- new CLI commands
- Definition-registration CLI
- positional Workspace support for interactive mode
- automatic `registry`/`artifactStore` adoption from `OrchestratorOptions.workspace`
- Registry or ArtifactStore runtime semantic changes
- migrations
- new public runtime APIs
- API Reference generator
- export-index generator/test infrastructure beyond the package-distribution regression test
- committed product/example file solely to mirror the Quickstart

If documentation cannot truthfully describe current behavior without one of these changes, stop and surface that as a separate issue rather than silently expanding this PR.
