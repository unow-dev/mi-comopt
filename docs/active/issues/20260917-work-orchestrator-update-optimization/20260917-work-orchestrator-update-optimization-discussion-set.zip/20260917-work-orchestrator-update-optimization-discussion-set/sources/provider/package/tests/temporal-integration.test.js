import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { TestWorkflowEnvironment } from "@temporalio/testing";
import { Worker } from "@temporalio/worker";
import { bundleWorkflowCode } from "@temporalio/worker";
import {
  ArtifactStore,
  FakeAgentAdapter,
  Registry,
  cancelSessionUpdate,
  claimTaskUpdate,
  completeHumanTaskUpdate,
  createTemporalActivities,
  receiveExternalEventUpdate,
  runtimeStateQuery,
  validateAndHashDefinition,
  workSessionWorkflow,
} from "../dist/index.js";

const humanDefinition = validateAndHashDefinition({
  workDefinitionId: "temporal-activity-definition",
  revision: 0,
  schemaVersion: 1,
  root: {
    kind: "task",
    id: "human",
    goal: "human task",
    contract: {
      workerKind: "human",
      requiredCapabilities: [],
      requestedPermissions: [],
      retryPolicy: { maxAttempts: 1 },
      budgets: { maxWallTimeMs: 1000 },
    },
  },
});

test("Temporal Workflow bundle は SDK の Workflow isolate でビルドできる", async () => {
  const bundle = await bundleWorkflowCode({
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
  });
  assert.match(bundle.code, /workSessionWorkflow/);
});

test("Temporal Registry Activity は commit 後の state と intent を返す", async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-test-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const artifactStore = new ArtifactStore(join(directory, "artifacts"));
  try {
    registry.registerDefinition(humanDefinition);
    const activities = createTemporalActivities({ registry, artifactStore });
    const initial = await activities.initializeSession({
      sessionId: "temporal-activity-session",
      workDefinitionId: humanDefinition.workDefinitionId,
      revision: 0,
      input: null,
      actor: { actorId: "system", actorType: "system" },
    });
    const advanced = await activities.commitCommand({
      state: initial.state,
      envelope: {
        schemaVersion: 1,
        sessionId: "temporal-activity-session",
        commandId: "internal:advance:2",
        actor: { actorId: "runtime", actorType: "runtime" },
        command: { type: "advance" },
      },
    });
    assert.equal(advanced.state.revision, 2);
    assert.equal(Object.values(advanced.state.tasks).length, 1);
    assert.equal(Object.values(advanced.state.tasks)[0].state, "ready");
    assert.equal(advanced.duplicate, false);
  } finally {
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test("Temporal Test Environment: Registry Activity が commit 後に落ちても retry は一度だけ反映する", { timeout: 120_000 }, async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-retry-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const { definitionHash: _definitionHash, ...definitionWithoutHash } = humanDefinition;
  const definition = validateAndHashDefinition({ ...definitionWithoutHash, workDefinitionId: "temporal-retry-definition" });
  registry.registerDefinition(definition);
  const activities = createTemporalActivities({ registry, artifactStore: new ArtifactStore(join(directory, "artifacts")) });
  const originalCommitCommand = activities.commitCommand;
  let injectedFailure = false;
  activities.commitCommand = async (input) => {
    const result = await originalCommitCommand(input);
    if (!injectedFailure && input.envelope.commandId === "internal:advance:2") {
      injectedFailure = true;
      throw new Error("simulated crash after Registry commit");
    }
    return result;
  };
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue: "work-orchestrator-temporal-retry",
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities,
  });
  const workerRun = worker.run();
  try {
    const handle = await environment.client.workflow.start(workSessionWorkflow, {
      workflowId: "temporal-retry-session",
      taskQueue: "work-orchestrator-temporal-retry",
      args: [{ sessionId: "temporal-retry-session", workDefinitionId: definition.workDefinitionId, revision: 0, input: null }],
    });
    const ready = await waitForState(handle, (state) => Object.values(state.tasks).some((task) => task.state === "ready"));
    const task = Object.values(ready.tasks)[0];
    const actor = { actorId: "human-retry", actorType: "human" };
    await handle.executeUpdate(claimTaskUpdate, { args: [{ taskId: task.taskId, actor, commandId: "temporal-retry-claim" }] });
    await handle.executeUpdate(completeHumanTaskUpdate, { args: [{ taskId: task.taskId, actor, result: { retried: true }, commandId: "temporal-retry-complete" }] });
    assert.equal(injectedFailure, true);
    assert.equal(registry.query("SELECT COUNT(*) AS count FROM domain_commits WHERE session_id = ? AND revision = 2", "temporal-retry-session")[0].count, 1);
    assert.equal((await handle.result()).state, "completed");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

async function waitForState(handle, predicate, attempts = 40) {
  for (let index = 0; index < attempts; index += 1) {
    const state = await handle.query(runtimeStateQuery);
    if (state && predicate(state)) return state;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  return handle.query(runtimeStateQuery);
}

test("Temporal Test Environment: Update は一つの Workflow command processor を通って完了する", { timeout: 120_000 }, async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-update-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const { definitionHash: _definitionHash, ...humanDefinitionWithoutHash } = humanDefinition;
  const definition = validateAndHashDefinition({ ...humanDefinitionWithoutHash, workDefinitionId: "temporal-update-definition" });
  registry.registerDefinition(definition);
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue: "work-orchestrator-temporal-update",
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities: createTemporalActivities({ registry, artifactStore: new ArtifactStore(join(directory, "artifacts")) }),
  });
  const workerRun = worker.run();
  try {
    const handle = await environment.client.workflow.start(workSessionWorkflow, {
      workflowId: "temporal-update-session",
      taskQueue: "work-orchestrator-temporal-update",
      args: [{ sessionId: "temporal-update-session", workDefinitionId: definition.workDefinitionId, revision: 0, input: null }],
    });
    const ready = await waitForState(handle, (state) => Object.values(state.tasks).some((task) => task.state === "ready"));
    const task = Object.values(ready.tasks)[0];
    const actor = { actorId: "human-1", actorType: "human" };
    const claimInput = { taskId: task.taskId, actor, commandId: "temporal-claim-1" };
    const claimed = await handle.executeUpdate(claimTaskUpdate, { args: [claimInput] });
    assert.equal(claimed.taskId, task.taskId);
    const duplicateClaim = await handle.executeUpdate(claimTaskUpdate, { args: [claimInput] });
    assert.deepEqual(duplicateClaim, claimed);
    const completed = await handle.executeUpdate(completeHumanTaskUpdate, { args: [{ taskId: task.taskId, actor, result: { approved: true }, commandId: "temporal-complete-1" }] });
    assert.equal(completed.state, "completed");
    const result = await handle.result();
    assert.equal(result.state, "completed");
    assert.equal(registry.getRuntimeState("temporal-update-session").session.state, "completed");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test("Temporal Test Environment: Agent cancellation は TRY_CANCEL と Adapter confirmation を反映する", { timeout: 120_000 }, async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-cancel-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const definition = validateAndHashDefinition({
    workDefinitionId: "temporal-cancel-definition",
    revision: 0,
    schemaVersion: 1,
    root: {
      kind: "task",
      id: "agent",
      goal: "deferred agent",
      contract: {
        workerKind: "agent",
        requiredCapabilities: [],
        requestedPermissions: [],
        retryPolicy: { maxAttempts: 1 },
        budgets: { maxWallTimeMs: 30_000 },
      },
    },
  });
  registry.registerDefinition(definition);
  const adapter = new FakeAgentAdapter();
  adapter.plan("temporal-cancel-session:task:temporal-cancel-session:scope:root", { defer: true, result: { status: "succeeded", result: { late: true } } });
  const workerProfile = {
    workerId: "temporal-worker",
    revision: 1,
    enabled: true,
    capabilities: [],
    enforceablePermissions: [],
    enforceableBudgets: ["maxWallTimeMs"],
    routingPriority: 1,
    physicalAvailable: true,
  };
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue: "work-orchestrator-temporal-cancel",
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities: createTemporalActivities({
      registry,
      artifactStore: new ArtifactStore(join(directory, "artifacts")),
      workers: [workerProfile],
      agentAdapter: adapter,
      cancellationGraceMs: 0,
    }),
  });
  const workerRun = worker.run();
  try {
    const handle = await environment.client.workflow.start(workSessionWorkflow, {
      workflowId: "temporal-cancel-session",
      taskQueue: "work-orchestrator-temporal-cancel",
      args: [{ sessionId: "temporal-cancel-session", workDefinitionId: definition.workDefinitionId, revision: 0, input: null }],
    });
    const running = await waitForState(handle, (state) => Object.values(state.executions).some((execution) => execution.state === "running"));
    const execution = Object.values(running.executions)[0];
    assert.equal(adapter.isPending(execution.executionId), true);
    await handle.executeUpdate(cancelSessionUpdate, { args: [{ actor: { actorId: "operator", actorType: "operator" }, reason: "operator requested", commandId: "temporal-cancel-1" }] });
    const result = await handle.result();
    assert.equal(result.state, "cancelled");
    assert.equal(registry.getRuntimeState("temporal-cancel-session").executions[execution.executionId].state, "cancelled");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test("Temporal Test Environment: 物理 Agent Worker 不在は schedule-to-start timeout として Execution を再試行する", { timeout: 120_000 }, async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-worker-absence-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const definition = validateAndHashDefinition({
    workDefinitionId: "temporal-worker-absence-definition",
    revision: 0,
    schemaVersion: 1,
    root: {
      kind: "task",
      id: "agent",
      goal: "worker absence",
      contract: {
        workerKind: "agent",
        requiredCapabilities: [],
        requestedPermissions: [],
        retryPolicy: { maxAttempts: 2 },
        budgets: { maxWallTimeMs: 30_000 },
      },
    },
  });
  registry.registerDefinition(definition);
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const registryQueue = "work-orchestrator-temporal-worker-absence-registry";
  const absentAgentQueue = "work-orchestrator-temporal-worker-absence-agent";
  const workerProfile = {
    workerId: "temporal-worker-absence-logical-worker",
    revision: 1,
    enabled: true,
    capabilities: [],
    enforceablePermissions: [],
    enforceableBudgets: ["maxWallTimeMs"],
    routingPriority: 1,
    physicalAvailable: true,
  };
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue: registryQueue,
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities: createTemporalActivities({
      registry,
      artifactStore: new ArtifactStore(join(directory, "artifacts")),
      workers: [workerProfile],
    }),
  });
  const workerRun = worker.run();
  try {
    const handle = await environment.client.workflow.start(workSessionWorkflow, {
      workflowId: "temporal-worker-absence-session",
      taskQueue: registryQueue,
      args: [{
        sessionId: "temporal-worker-absence-session",
        workDefinitionId: definition.workDefinitionId,
        revision: 0,
        input: null,
        registryTaskQueue: registryQueue,
        agentTaskQueue: absentAgentQueue,
        agentScheduleToStartTimeoutMs: 200,
      }],
    });
    await waitForState(handle, (state) => Object.values(state.executions).some((execution) => execution.state === "running"));
    await environment.sleep(500);
    const state = await handle.query(runtimeStateQuery);
    const executions = Object.values(state.executions).sort((left, right) => left.attempt - right.attempt);
    assert.equal(executions.length, 2);
    assert.equal(executions[0].state, "failed");
    assert.equal(executions[0].attempt, 1);
    assert.equal(executions[1].attempt, 2);
    assert.ok(["running", "failed"].includes(executions[1].state));
    assert.equal(state.tasks[executions[0].taskId].state, "waiting");
    assert.equal(registry.getRuntimeState("temporal-worker-absence-session").executions[executions[0].executionId].state, "failed");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test("Temporal Test Environment: Continue-As-New は active Human Task を引き継ぎ Workflow ID を維持する", { timeout: 180_000 }, async () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-temporal-continue-"));
  const registry = new Registry(join(directory, "registry.sqlite"));
  const { definitionHash: _definitionHash, ...definitionWithoutHash } = humanDefinition;
  const definition = validateAndHashDefinition({ ...definitionWithoutHash, workDefinitionId: "temporal-continue-definition" });
  registry.registerDefinition(definition);
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const taskQueue = "work-orchestrator-temporal-continue";
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue,
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities: createTemporalActivities({ registry, artifactStore: new ArtifactStore(join(directory, "artifacts")) }),
  });
  const workerRun = worker.run();
  let handle;
  try {
    handle = await environment.client.workflow.start(workSessionWorkflow, {
      workflowId: "temporal-continue-session",
      taskQueue,
      args: [{ sessionId: "temporal-continue-session", workDefinitionId: definition.workDefinitionId, revision: 0, input: null }],
    });
    const ready = await waitForState(handle, (state) => Object.values(state.tasks).some((task) => task.state === "ready"));
    const task = Object.values(ready.tasks)[0];
    const actor = { actorId: "human-continue", actorType: "human" };
    await handle.executeUpdate(claimTaskUpdate, { args: [{ taskId: task.taskId, actor, commandId: "temporal-continue-claim" }] });
    const claimed = await handle.query(runtimeStateQuery);
    assert.equal(claimed.tasks[task.taskId].state, "active");
    const firstRunId = (await handle.describe()).runId;
    let continued = false;
    let observedHistoryLength = 0;
    for (let index = 0; index < 3_000; index += 1) {
      await handle.executeUpdate(receiveExternalEventUpdate, {
        args: [{
          actor: { actorId: "history-generator", actorType: "system" },
          commandId: `temporal-continue-history-${index}`,
          event: { eventId: "temporal-continue-buffered-event", eventType: "history", correlationKey: "continue", payload: { index } },
        }],
      });
      if (index % 25 === 0) {
        const description = await handle.describe();
        observedHistoryLength = description.historyLength;
        if (description.runId !== firstRunId) {
          continued = true;
          break;
        }
      }
    }
    assert.equal(continued, true, `Continue-As-New was not observed; historyLength=${observedHistoryLength}`);
    const afterContinuation = await handle.query(runtimeStateQuery);
    assert.equal(afterContinuation.session.sessionId, "temporal-continue-session");
    assert.equal(afterContinuation.tasks[task.taskId].state, "active");
    assert.equal(afterContinuation.tasks[task.taskId].claimantActorId, actor.actorId);
    assert.equal((await handle.describe()).workflowId, "temporal-continue-session");
    await handle.executeUpdate(completeHumanTaskUpdate, { args: [{ taskId: task.taskId, actor, result: { continued: true }, commandId: "temporal-continue-complete" }] });
    const result = await handle.result();
    assert.equal(result.state, "completed");
    assert.equal(registry.getRuntimeState("temporal-continue-session").session.state, "completed");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    registry.close();
    rmSync(directory, { recursive: true, force: true });
  }
});
