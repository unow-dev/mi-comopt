# Work Orchestrator documentation update — implementation handoff

This handoff freezes the implementation decisions for the documentation/API-usage update issue contained in the source discussion set.

## Status

- Design closure: **100%**
- Remaining work: implementation, review, and acceptance verification only
- Behavioral source-code changes: **out of scope**
- Merge unit: **one PR**

## Source snapshot

Source archive:

`20260916-231835-work-orchestrator-documentation-api-and-usage-update-discussion-set.zip`

SHA-256:

`267433bd750d06e89e93f389f9c9843e4f3cf832712590055b054628f26e9e23`

The handoff was prepared against that exact snapshot. The original archive is bundled unchanged under `source_snapshot/` so this handoff can be passed on by itself.

## Start here

1. Read `IMPLEMENTATION_SPEC.md`.
2. Apply the changes in the order in `IMPLEMENTATION_PLAN.md`.
3. Use `SOURCE_AUDIT.md` when checking implementation facts and known documentation drift.
4. Run every applicable item in `ACCEPTANCE_CHECKLIST.md`.
5. `PROPOSED_ISSUE_BODY.md` is a drop-in replacement/expansion for the current issue body if the issue itself should be updated before implementation.

## Frozen decisions

The normal user journey is **Workspace-first**:

```text
initialize Workspace
  -> open Workspace
  -> construct WorkOrchestrator with workspace registry/artifact store/workspace
  -> register WorkDefinition
  -> start Session
  -> process Human Task
```

The canonical CLI initialization path is:

```bash
npx work-orchestrator init .
```

The canonical interactive CLI invocation with an explicit Workspace is:

```bash
npx work-orchestrator --workspace . --actor local-user
```

Do **not** document interactive mode as `work-orchestrator [workspace] ...`; the current parser consumes the first positional token as a command.

The primary programmatic Session-start example uses `startSession()`. `startSessionFromWorkspace()` is documented separately for filesystem-input snapshotting.

The main Quickstart uses `schemaVersion: 2` and a single Human Task. It uses a unique Session ID such as `quickstart-${randomUUID()}` so it can be rerun against a persistent Workspace.

Persistent Registry/ArtifactStore documentation should prefer explicit `initialize()` / `open()` lifecycle APIs, or Workspace APIs, rather than constructors as the normal persistence path.

The npm package must include `docs/`, because `README.md` links to those files by relative path.

The “Complete root export index” remains complete; do not redefine it as a selected/representative API list.

## Target files

Required edits:

- `package/README.md`
- `package/docs/README.md`
- `package/docs/API_REFERENCE.md`
- `package/package.json`
- one package-distribution regression test under `package/tests/` (recommended name: `package-distribution.test.js`)

Do not change runtime/CLI/Workspace behavior to make the docs easier to write. Document the current behavior accurately.
