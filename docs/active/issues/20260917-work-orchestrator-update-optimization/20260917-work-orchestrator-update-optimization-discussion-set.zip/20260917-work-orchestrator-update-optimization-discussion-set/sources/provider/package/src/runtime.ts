import { spawn, type ChildProcess } from "node:child_process";
import { canonicalJson, hashJson } from "./canonical.js";
import { ArtifactStore } from "./artifact-store.js";
import { snapshotOutputDirectory, snapshotPath } from "./artifact.js";
import { reconcileOutbox } from "./outbox.js";
import { createInitialRuntimeState, reduceCommand, type ReducerContext } from "./domain.js";
import {
  DomainError,
  type AgentRunRequest,
  type AgentRunResult,
  type ActorRef,
  type CommandEnvelope,
  type DomainCommand,
  type JsonValue,
  type ReconciliationResult,
  type ReductionAccepted,
  type RuntimeState,
  type WorkerProfile,
  type WorkDefinition,
  type TaskRuntime,
  type ExecutionRuntime,
} from "./contracts.js";
import { Registry } from "./registry.js";
import { validateAndHashDefinition, type ValidatedDefinition } from "./validation.js";
import { prepareExecutionWorkspace } from "./workspace.js";
import type { OpenWorkspace } from "./workspace.js";

export interface AgentAdapter {
  run(request: AgentRunRequest): Promise<AgentRunResult>;
  cancel(executionId: string): Promise<{ confirmed: boolean }>;
  /** Graceful cancellation が確認できない場合に限って呼び出す強制終了フック。 */
  forceKill?(executionId: string): Promise<void>;
}

export interface FakeAgentPlan {
  result: AgentRunResult;
  defer?: boolean;
}

/** 意味論受入試験用の決定的 Adapter。Activity 自動 retry は行わない。 */
export class FakeAgentAdapter implements AgentAdapter {
  private readonly plans = new Map<string, FakeAgentPlan[]>();
  private readonly pending = new Map<string, (result: AgentRunResult) => void>();

  plan(taskId: string, ...plans: FakeAgentPlan[]): void {
    this.plans.set(taskId, [...plans]);
  }

  resolve(executionId: string, result: AgentRunResult): boolean {
    const resolver = this.pending.get(executionId);
    if (!resolver) return false;
    this.pending.delete(executionId);
    resolver(result);
    return true;
  }

  isPending(executionId: string): boolean {
    return this.pending.has(executionId);
  }

  async run(request: AgentRunRequest): Promise<AgentRunResult> {
    const queue = this.plans.get(request.task.taskId) ?? [];
    const plan: FakeAgentPlan = queue.shift() ?? { result: { status: "succeeded", result: { ok: true, goal: request.task.goal } } };
    this.plans.set(request.task.taskId, queue);
    if (!plan.defer) return plan.result;
    return new Promise<AgentRunResult>((resolve) => this.pending.set(request.execution.executionId, resolve));
  }

  async cancel(executionId: string): Promise<{ confirmed: boolean }> {
    if (!this.pending.has(executionId)) return { confirmed: true };
    this.resolve(executionId, { status: "cancelled" });
    return { confirmed: true };
  }

  async forceKill(executionId: string): Promise<void> {
    this.resolve(executionId, { status: "abandoned", failure: "force-killed" });
  }
}

export class CodexAdapter implements AgentAdapter {
  private readonly controllers = new Map<string, AbortController>();

  constructor(
    private readonly runner: (request: AgentRunRequest, signal: AbortSignal) => Promise<AgentRunResult>,
    private readonly killer?: (executionId: string) => Promise<void> | void,
  ) {}

  async run(request: AgentRunRequest): Promise<AgentRunResult> {
    const controller = new AbortController();
    this.controllers.set(request.execution.executionId, controller);
    try {
      return await this.runner(request, controller.signal);
    } finally {
      this.controllers.delete(request.execution.executionId);
    }
  }

  async cancel(executionId: string): Promise<{ confirmed: boolean }> {
    const controller = this.controllers.get(executionId);
    if (!controller) return { confirmed: false };
    controller.abort();
    return { confirmed: true };
  }

  async forceKill(executionId: string): Promise<void> {
    if (this.killer) await this.killer(executionId);
    // killer 未指定時も実行を再利用せず、少なくとも AbortSignal を再通知する。
    this.controllers.get(executionId)?.abort();
  }

  translateContract(task: TaskRuntime, grant: ExecutionRuntime["grant"]): Record<string, unknown> {
    return {
      goal: task.goal,
      inputs: task.inputs,
      permissions: grant?.permissions ?? [],
      capabilities: grant?.capabilities ?? [],
      budgets: grant?.budgets ?? task.contract.budgets,
    };
  }
}

export interface CodexCliAdapterOptions {
  /** 未指定時は PATH 上の `codex` を使う。 */
  executable?: string;
  cwd?: string;
  model?: string;
  sandbox?: "read-only" | "workspace-write" | "danger-full-access";
  extraArgs?: string[];
  env?: NodeJS.ProcessEnv;
  maxOutputBytes?: number;
  killGraceMs?: number;
  promptBuilder?: (request: AgentRunRequest, translatedContract: Record<string, unknown>) => string;
}

function parseCodexResult(stdout: string, stderr: string): AgentRunResult {
  const messages: string[] = [];
  for (const line of stdout.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const event = JSON.parse(line) as { type?: string; item?: { type?: string; text?: unknown } };
      if (event.type === "item.completed" && event.item?.type === "agent_message" && typeof event.item.text === "string") messages.push(event.item.text);
    } catch {
      // Codex の診断行は JSONL の一部でない場合があるため無視する。
    }
  }
  const text = messages.at(-1)?.trim();
  if (!text) return { status: "failed", failure: `Codex CLI returned no agent message${stderr.trim() ? `: ${stderr.trim().slice(-500)}` : ""}` };
  const candidates = [text, text.replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, "$1")];
  for (const candidate of candidates) {
    try {
      const parsed = JSON.parse(candidate) as Partial<AgentRunResult>;
      if (parsed.status === "succeeded" || parsed.status === "blocked" || parsed.status === "failed" || parsed.status === "cancelled" || parsed.status === "abandoned") {
        return { status: parsed.status, outcome: parsed.outcome, result: parsed.result, failure: parsed.failure };
      }
    } catch {
      // 次の抽出候補を試す。
    }
  }
  return { status: "failed", failure: "Codex CLI agent message was not a valid AgentRunResult JSON" };
}

/**
 * Codex CLI を実行する Adapter。
 * CLI の出力は AgentRunResult JSON に限定し、Domain reducer には渡さない。
 */
export function createCodexCliAdapter(options: CodexCliAdapterOptions = {}): CodexAdapter {
  const children = new Map<string, ChildProcess>();
  const maxOutputBytes = options.maxOutputBytes ?? 1_000_000;
  const killGraceMs = options.killGraceMs ?? 5_000;
  const promptBuilder = options.promptBuilder ?? ((_request, translatedContract) => [
    "Execute the following agent contract.",
    "Do not modify files unless the contract explicitly requires it.",
    "Reply with exactly one JSON object and no markdown using this shape:",
    '{"status":"succeeded","result":null}',
    "On an operational block use status=blocked; on failure use status=failed and include a string failure.",
    `contract=${canonicalJson(translatedContract as JsonValue)}`,
  ].join("\n"));

  const runner = (request: AgentRunRequest, signal: AbortSignal): Promise<AgentRunResult> => new Promise((resolve) => {
    const translatedContract = {
      goal: request.task.goal,
      inputs: request.task.inputs,
      permissions: request.grant.permissions,
      capabilities: request.grant.capabilities,
      budgets: request.grant.budgets,
      workspace: request.workspace ? {
        root: request.workspace.root,
        input: request.workspace.inputPath,
        work: request.workspace.workPath,
        output: request.workspace.outputPath,
      } : undefined,
    };
    const args = ["exec", "--ephemeral", "--sandbox", options.sandbox ?? "read-only", "--json"];
    if (options.model) args.push("--model", options.model);
    if (options.extraArgs) args.push(...options.extraArgs);
    args.push(promptBuilder(request, translatedContract));
    let child: ChildProcess;
    try {
      child = spawn(options.executable ?? "codex", args, {
        cwd: request.workspace?.root ?? options.cwd,
        env: { ...process.env, ...options.env },
        stdio: ["ignore", "pipe", "pipe"],
      });
    } catch (error) {
      resolve({ status: "failed", failure: error instanceof Error ? error.message : "Codex CLI could not be started" });
      return;
    }
    children.set(request.execution.executionId, child);
    let stdout = "";
    let stderr = "";
    let aborted = signal.aborted;
    let settled = false;
    let killTimer: ReturnType<typeof setTimeout> | undefined;
    const finish = (result: AgentRunResult): void => {
      if (settled) return;
      settled = true;
      if (killTimer) clearTimeout(killTimer);
      signal.removeEventListener("abort", onAbort);
      children.delete(request.execution.executionId);
      resolve(result);
    };
    const onAbort = (): void => {
      aborted = true;
      child.kill("SIGTERM");
      killTimer = setTimeout(() => {
        if (!settled) child.kill("SIGKILL");
      }, killGraceMs);
    };
    const append = (current: string, chunk: Buffer): string => {
      const next = current + chunk.toString("utf8");
      return Buffer.byteLength(next, "utf8") > maxOutputBytes ? next.slice(-maxOutputBytes) : next;
    };
    child.stdout?.on("data", (chunk: Buffer) => { stdout = append(stdout, chunk); });
    child.stderr?.on("data", (chunk: Buffer) => { stderr = append(stderr, chunk); });
    child.once("error", (error) => finish({ status: aborted ? "abandoned" : "failed", failure: error.message }));
    child.once("close", (code, signalName) => {
      if (aborted) {
        finish({ status: "abandoned", failure: signalName ? `Codex CLI terminated by ${signalName}` : "Codex CLI cancelled" });
      } else if (code !== 0) {
        finish({ status: "failed", failure: `Codex CLI exited with code ${code}${stderr.trim() ? `: ${stderr.trim().slice(-500)}` : ""}` });
      } else {
        finish(parseCodexResult(stdout, stderr));
      }
    });
    signal.addEventListener("abort", onAbort, { once: true });
    if (aborted) onAbort();
  });

  return new CodexAdapter(runner, async (executionId) => {
    children.get(executionId)?.kill("SIGKILL");
  });
}

export interface StartSessionInput {
  sessionId: string;
  workDefinitionId?: string;
  revision?: number;
  input?: JsonValue;
  actor?: ActorRef;
  commandId?: string;
  definition?: WorkDefinition;
  inputArtifacts?: import("./contracts.js").ArtifactVersionRuntime[];
  bootstrapManifest?: { artifactVersionId: string; blobHash: string };
}

export interface OrchestratorOptions {
  registry?: Registry;
  artifactStore?: ArtifactStore;
  workers?: WorkerProfile[];
  agentAdapter?: AgentAdapter;
  workspace?: OpenWorkspace;
}

export interface TemporalSafePoint {
  commandQueueEmpty: boolean;
  registryCommitInFlight: boolean;
  agentActivityInFlight: boolean;
  mutationHandlerInProgress: boolean;
  timerTransitionInProgress: boolean;
}

/** Temporal SDK に依存しない、Workflow ID/Execution Chain と Continue-As-New の契約模型。 */
export class TemporalSessionRuntime {
  readonly workflowId: string;
  private runNumber = 0;
  private readonly carriedState: RuntimeState;

  constructor(sessionId: string, state: RuntimeState) {
    this.workflowId = sessionId;
    this.carriedState = state;
  }

  get runId(): string {
    return `${this.workflowId}:run:${this.runNumber}`;
  }

  get state(): RuntimeState {
    return this.carriedState;
  }

  continueAsNew(safePoint: TemporalSafePoint): { workflowId: string; previousRunId: string; runId: string; state: RuntimeState } {
    if (!safePoint.commandQueueEmpty || safePoint.registryCommitInFlight || safePoint.agentActivityInFlight || safePoint.mutationHandlerInProgress || safePoint.timerTransitionInProgress) {
      throw new DomainError("INVALID_STATE", "Continue-As-New is allowed only at a safe point");
    }
    const previousRunId = this.runId;
    this.runNumber += 1;
    return { workflowId: this.workflowId, previousRunId, runId: this.runId, state: this.carriedState };
  }
}

export class WorkOrchestrator {
  readonly registry: Registry;
  readonly artifactStore: ArtifactStore;
  readonly agentAdapter: AgentAdapter;
  private workers: WorkerProfile[];
  private commandCounter = 0;
  private readonly temporalStates = new Map<string, RuntimeState>();
  private readonly temporalRuntimes = new Map<string, TemporalSessionRuntime>();
  private readonly driveLocks = new Map<string, Promise<void>>();
  private readonly commandQueues = new Map<string, Promise<JsonValue>>();
  readonly workspace?: OpenWorkspace;

  constructor(options: OrchestratorOptions = {}) {
    this.registry = options.registry ?? new Registry();
    this.artifactStore = options.artifactStore ?? new ArtifactStore();
    this.agentAdapter = options.agentAdapter ?? new FakeAgentAdapter();
    this.workspace = options.workspace;
    this.workers = [...(options.workers ?? this.registry.listWorkers())];
    for (const worker of this.workers) this.registry.db.prepare("INSERT OR REPLACE INTO workers(worker_id, revision, profile_json) VALUES (?, ?, ?)").run(worker.workerId, worker.revision, canonicalJson(worker as unknown as JsonValue));
  }

  registerDefinition(definition: WorkDefinition): ValidatedDefinition {
    const validated = validateAndHashDefinition(definition);
    this.registry.registerDefinition(validated);
    return validated;
  }

  addWorker(worker: WorkerProfile): void {
    this.workers = [...this.workers.filter((candidate) => candidate.workerId !== worker.workerId), worker];
    this.registry.db.prepare("INSERT OR REPLACE INTO workers(worker_id, revision, profile_json) VALUES (?, ?, ?)").run(worker.workerId, worker.revision, canonicalJson(worker as unknown as JsonValue));
  }

  async startSession(input: StartSessionInput): Promise<JsonValue> {
    const requestedDefinition = input.definition ? validateAndHashDefinition(input.definition) : undefined;
    const definitions = input.workDefinitionId ? this.registry.listDefinitions().filter((definition) => definition.workDefinitionId === input.workDefinitionId) : [];
    const workDefinitionId = input.workDefinitionId ?? requestedDefinition?.workDefinitionId;
    if (!workDefinitionId) throw new DomainError("DEFINITION_INVALID", "workDefinitionId or inline definition is required");
    const revision = input.revision ?? (requestedDefinition?.revision ?? Math.max(...definitions.map((definition) => definition.revision), -1));
    const actor = input.actor ?? { actorId: "system", actorType: "system" };
    const commandId = input.commandId ?? `start:${input.sessionId}`;
    const envelope: CommandEnvelope = { schemaVersion: 1, sessionId: input.sessionId, commandId, actor, command: { type: "advance" } };
    const artifacts = input.inputArtifacts ?? [];
    const requestHash = hashJson({ envelope, workDefinitionId, revision, input: input.input ?? null, definition: requestedDefinition ?? null, artifacts, bootstrapManifest: input.bootstrapManifest ?? null } as unknown as JsonValue);
    const existingState = this.registry.getRuntimeState(input.sessionId);
    if (existingState) {
      const receipt = this.registry.getReceipt(input.sessionId, commandId);
      if (receipt && receipt.requestHash === requestHash) return receipt.response;
      if (receipt) return { ok: false, error: { code: "IDEMPOTENCY_KEY_CONFLICT", message: "start command was already used with a different request" } };
      throw new DomainError("INVARIANT_VIOLATION", `Session ${input.sessionId} exists without a start receipt`);
    }
    const definition = requestedDefinition ?? this.registry.getDefinition(workDefinitionId, revision);
    if (!definition) throw new DomainError("DEFINITION_INVALID", `definition ${input.workDefinitionId}@${revision} is not registered`);
    const artifactState = Object.fromEntries(artifacts.map((artifact) => [artifact.artifactVersionId, artifact]));
    const state = createInitialRuntimeState(definition, input.sessionId, input.input ?? null, artifactState);
    state.revision = 1;
    const reduction: ReductionAccepted = {
      kind: "accepted",
      nextState: state,
      facts: [{ type: "SessionStarted", entityId: input.sessionId, data: { workDefinitionId: definition.workDefinitionId, revision: definition.revision } }],
      intents: [],
      response: { sessionId: input.sessionId, state: state.session.state, revision: state.revision },
      advanceRevision: true,
    };
    const result = this.registry.commitInitialSession(envelope, reduction, requestHash, { definition, artifactVersions: artifacts, bootstrapManifest: input.bootstrapManifest });
    const saved = this.registry.getRuntimeState(input.sessionId)!;
    this.temporalStates.set(input.sessionId, saved);
    this.temporalRuntimes.set(input.sessionId, new TemporalSessionRuntime(input.sessionId, saved));
    await this.drive(input.sessionId);
    this.reconcileDerivedViews(input.sessionId);
    return result.response;
  }

  /** Snapshot selected filesystem inputs before the Session depends on them. */
  async startSessionFromWorkspace(input: Omit<StartSessionInput, "inputArtifacts" | "bootstrapManifest"> & { inputPaths: string[]; workspace?: OpenWorkspace }): Promise<JsonValue> {
    const workspace = input.workspace ?? this.workspace;
    if (!workspace) throw new DomainError("WORKSPACE_REQUIRED", "a Workspace is required to snapshot Session inputs");
    const artifacts = input.inputPaths.map((path, ordinal) => snapshotPath(this.artifactStore, path, {
      sourceRef: path,
      artifactVersionId: `${input.sessionId}:input:${ordinal}`,
    }).artifact);
    const manifestBytes = Buffer.from(canonicalJson({ formatVersion: 1, sessionId: input.sessionId, inputs: artifacts.map((artifact) => ({ artifactVersionId: artifact.artifactVersionId, logicalPath: artifact.logicalPath ?? null })) } as unknown as JsonValue));
    const staged = this.artifactStore.stage(manifestBytes, "application/vnd.work-orchestrator.session-bootstrap+json");
    this.artifactStore.finalize(staged);
    return this.startSession({ ...input, inputArtifacts: artifacts, bootstrapManifest: { artifactVersionId: `${input.sessionId}:bootstrap-manifest`, blobHash: staged.blobHash } });
  }

  async dispatch(sessionId: string, command: DomainCommand, actor: ActorRef = { actorId: "system", actorType: "system" }, commandId = `${command.type}:${sessionId}:${++this.commandCounter}`): Promise<JsonValue> {
    return this.apply(sessionId, { schemaVersion: 1, sessionId, commandId, actor, command });
  }

  async claimTask(sessionId: string, taskId: string, actor: ActorRef, commandId?: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "claimTask", taskId }, actor, commandId ?? `claim:${taskId}:${actor.actorId}`);
  }

  async releaseTask(sessionId: string, taskId: string, actor: ActorRef, commandId?: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "releaseTask", taskId }, actor, commandId ?? `release:${taskId}:${actor.actorId}`);
  }

  async completeHumanTask(sessionId: string, taskId: string, actor: ActorRef, outcome?: string, result?: JsonValue, commandId?: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "completeHumanTask", taskId, outcome, result }, actor, commandId ?? `complete-human:${taskId}:${actor.actorId}`);
  }

  async completeHumanTaskWithInput(sessionId: string, taskId: string, actor: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string; artifactVersions?: import("./contracts.js").ArtifactVersionRuntime[] }, commandId: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "completeHumanTask", taskId, ...input }, actor, commandId);
  }

  async openHumanTaskWorkspace(sessionId: string, taskId: string, actor: ActorRef, commandId = `claim:${taskId}:${actor.actorId}`): Promise<{ executionId: string; root: string; inputPath: string; workPath: string; outputPath: string }> {
    if (!this.workspace) throw new DomainError("WORKSPACE_REQUIRED", "a Workspace is required for file-producing Human work");
    const state = this.state(sessionId);
    const task = state?.tasks[taskId];
    if (!state || !task) throw new DomainError("TASK_NOT_FOUND", `Task ${taskId} not found`);
    if (task.state === "ready") await this.claimTask(sessionId, taskId, actor, commandId);
    const current = this.state(sessionId)?.tasks[taskId];
    if (!current?.currentExecutionId || current.claimantActorId !== actor.actorId) throw new DomainError("NOT_CLAIM_OWNER", "Human Task is claimed by another actor");
    const execution = this.state(sessionId)?.executions[current.currentExecutionId];
    if (!execution) throw new DomainError("INVALID_STATE", "Human Execution is missing");
    const prepared = prepareExecutionWorkspace(this.workspace, this.state(sessionId)!, taskId, execution.executionId, this.artifactStore);
    return prepared;
  }

  async completeHumanTaskFromWorkspace(sessionId: string, taskId: string, actor: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string }, commandId: string): Promise<JsonValue> {
    if (!this.workspace) throw new DomainError("WORKSPACE_REQUIRED", "a Workspace is required for file-producing Human work");
    const state = this.state(sessionId);
    const task = state?.tasks[taskId];
    const executionId = task?.currentExecutionId;
    if (!state || !task || !executionId) throw new DomainError("WORKSPACE_REQUIRED", "Human Task must be opened before output completion");
    const executionWorkspace = prepareExecutionWorkspace(this.workspace, state, taskId, executionId, this.artifactStore);
    const artifacts = snapshotOutputDirectory(this.artifactStore, executionWorkspace.outputPath, executionId);
    return this.completeHumanTaskWithInput(sessionId, taskId, actor, { ...input, artifactVersions: artifacts }, commandId);
  }

  async resumeAgentTask(sessionId: string, taskId: string, actor: ActorRef = { actorId: "operator", actorType: "operator" }, commandId?: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "resumeAgentTask", taskId }, actor, commandId ?? `resume-agent:${taskId}:${actor.actorId}`);
  }

  async cancelSession(sessionId: string, actor: ActorRef = { actorId: "operator", actorType: "operator" }, reason?: string, commandId?: string): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "cancelSession", reason }, actor, commandId ?? `cancel-session:${sessionId}`);
  }

  async receiveExternalEvent(sessionId: string, event: Extract<DomainCommand, { type: "receiveExternalEvent" }>["event"], actor: ActorRef = { actorId: "external", actorType: "external" }, commandId = `event:${event.eventId}`): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "receiveExternalEvent", event }, actor, commandId);
  }

  async fireTimer(sessionId: string, waitId: string, actor: ActorRef = { actorId: "temporal", actorType: "temporal" }, commandId = `timer:${waitId}`): Promise<JsonValue> {
    return this.dispatch(sessionId, { type: "timerFired", waitId }, actor, commandId);
  }

  state(sessionId: string): RuntimeState | undefined {
    return this.temporalStates.get(sessionId) ?? this.registry.getRuntimeState(sessionId);
  }

  pendingTimers(sessionId: string): Array<{ waitId: string; delayMs: number }> {
    const state = this.state(sessionId);
    if (!state) return [];
    return Object.values(state.waits).filter((wait) => wait.kind === "timer" && wait.state === "waiting").map((wait) => ({ waitId: wait.waitId, delayMs: wait.delayMs! }));
  }

  sessionRuntimeInfo(sessionId: string): { workflowId: string; runId: string; hasChildWorkflow: false } | undefined {
    const runtime = this.temporalRuntimes.get(sessionId);
    return runtime ? { workflowId: runtime.workflowId, runId: runtime.runId, hasChildWorkflow: false } : undefined;
  }

  getSessionView(sessionId: string): {
    session: RuntimeState["session"];
    scopes: RuntimeState["scopes"];
    tasks: RuntimeState["tasks"];
    executions: RuntimeState["executions"];
    waits: RuntimeState["waits"];
    artifacts: RuntimeState["artifacts"];
    resultsByStepId: RuntimeState["resultsByStepId"];
    history: Array<Record<string, unknown>>;
    consistency: ReconciliationResult;
  } | undefined {
    const state = this.registry.getRuntimeState(sessionId);
    if (!state) return undefined;
    return {
      session: state.session,
      scopes: state.scopes,
      tasks: state.tasks,
      executions: state.executions,
      waits: state.waits,
      artifacts: state.artifacts,
      resultsByStepId: state.resultsByStepId,
      history: this.registry.getDomainCommits(sessionId),
      consistency: this.reconcile(sessionId, state),
    };
  }

  /** Receipt-first external event facade. Terminal Sessions are safely ignored and recorded. */
  async deliverExternalEvent(sessionId: string, event: Extract<DomainCommand, { type: "receiveExternalEvent" }>["event"]): Promise<JsonValue> {
    const envelope: CommandEnvelope = {
      schemaVersion: 1,
      sessionId,
      commandId: `event:${event.eventId}`,
      actor: { actorId: "external", actorType: "external" },
      command: { type: "receiveExternalEvent", event },
    };
    const requestHash = hashJson(envelope as unknown as JsonValue);
    const receipt = this.registry.getReceipt(sessionId, envelope.commandId);
    if (receipt) {
      if (receipt.requestHash !== requestHash) return { ok: false, error: { code: "IDEMPOTENCY_KEY_CONFLICT", message: "event ID was already used with a different payload" } };
      return receipt.response;
    }
    const state = this.state(sessionId);
    if (!state) throw new DomainError("SESSION_NOT_FOUND", `Session ${sessionId} not found`);
    if (state.session.state === "completed" || state.session.state === "cancelled") {
      const ignored = { status: "terminal_ignored", eventId: event.eventId } as unknown as JsonValue;
      return this.registry.recordReceipt(sessionId, envelope.commandId, requestHash, ignored).response;
    }
    return this.apply(sessionId, envelope);
  }

  reconcile(sessionId: string, temporalState = this.state(sessionId)): ReconciliationResult {
    const registryProjection = this.registry.getSessionProjection(sessionId);
    if (!registryProjection || !temporalState) return { status: "unknown" };
    const registryRevision = Number(registryProjection.revision);
    const registryStateHash = String(registryProjection.state_hash);
    const temporalRevision = temporalState.revision;
    const temporalStateHash = hashJson(temporalState as unknown as JsonValue);
    if (temporalRevision === registryRevision && temporalStateHash === registryStateHash) return { status: "consistent", temporalRevision, registryRevision, temporalStateHash, registryStateHash };
    if (temporalRevision !== registryRevision) return { status: "temporarily_lagging", temporalRevision, registryRevision, temporalStateHash, registryStateHash };
    return { status: "invariant_violation", temporalRevision, registryRevision, temporalStateHash, registryStateHash };
  }

  private async apply(sessionId: string, envelope: CommandEnvelope): Promise<JsonValue> {
    const previous = this.commandQueues.get(sessionId) ?? Promise.resolve<JsonValue>(null);
    const current = previous.catch(() => null).then(() => this.applyNow(sessionId, envelope));
    this.commandQueues.set(sessionId, current);
    try {
      return await current;
    } finally {
      if (this.commandQueues.get(sessionId) === current) this.commandQueues.delete(sessionId);
    }
  }

  private async applyNow(sessionId: string, envelope: CommandEnvelope): Promise<JsonValue> {
    const previous = this.temporalStates.get(sessionId) ?? this.registry.getRuntimeState(sessionId);
    if (!previous) throw new DomainError("SESSION_NOT_FOUND", `Session ${sessionId} not found`);
    const existing = this.registry.getReceipt(sessionId, envelope.commandId);
    const requestHash = hashJson(envelope as unknown as JsonValue);
    if (existing && existing.requestHash !== requestHash) {
      return { ok: false, error: { code: "IDEMPOTENCY_KEY_CONFLICT", message: "command ID was already used with a different request" } };
    }
    if (existing) return existing.response;
    const reduction = reduceCommand(previous, envelope, { workers: this.workers });
    let result;
    try {
      result = this.registry.commit(envelope, reduction, requestHash);
    } catch (error) {
      if (error instanceof Error && error.message === "IDEMPOTENCY_KEY_CONFLICT") return { ok: false, error: { code: "IDEMPOTENCY_KEY_CONFLICT", message: error.message } };
      throw error;
    }
    if (!result.duplicate && reduction.kind === "accepted" && reduction.advanceRevision) {
      this.temporalStates.set(sessionId, reduction.nextState);
      await this.executeIntents(reduction.intents);
    }
    if (!result.duplicate && reduction.kind === "accepted" && !reduction.advanceRevision) await this.executeIntents(reduction.intents);
    await this.drive(sessionId);
    this.reconcileDerivedViews(sessionId);
    return result.response;
  }

  private reconcileDerivedViews(sessionId: string): void {
    if (!this.workspace) return;
    const state = this.state(sessionId);
    if (!state) return;
    try {
      reconcileOutbox(this.workspace, state, this.artifactStore);
    } catch {
      // Derived-view failure must not rewrite a successful Domain commit. The
      // next screen refresh or explicit reconciliation can retry it.
    }
  }

  private async executeIntents(intents: ReductionAccepted["intents"]): Promise<void> {
    for (const intent of intents.filter((candidate) => candidate.kind === "cancelAgent")) {
      const state = this.stateForIntent(intent);
      if (!state) continue;
      let cancellation: { confirmed: boolean };
      try {
        cancellation = await this.agentAdapter.cancel(intent.executionId);
      } catch {
        cancellation = { confirmed: false };
      }
      if (!cancellation.confirmed && this.agentAdapter.forceKill) await this.agentAdapter.forceKill(intent.executionId).catch(() => undefined);
      await this.applyInternal(state.session.sessionId, {
        type: "agentResult",
        executionId: intent.executionId,
        status: cancellation.confirmed ? "cancelled" : "abandoned",
        failure: cancellation.confirmed ? undefined : "cancellation could not be confirmed",
      });
    }

    // Workflow は Activity を並行スケジュールできる。完了報告だけは applyInternal
    // で一つずつ reducer に渡すため、Domain mutation は常に直列のまま保つ。
    const dispatches = intents.filter((candidate) => candidate.kind === "dispatchAgent");
    const completed = await Promise.all(dispatches.map(async (intent) => {
      const state = this.stateForIntent(intent);
      if (!state || intent.kind !== "dispatchAgent") return undefined;
      const execution = state.executions[intent.executionId];
      if (!execution || execution.state !== "running" || !execution.grant) return undefined;
      const task = state.tasks[execution.taskId];
      if (!task) return undefined;
      const worker = this.workers.find((candidate) => candidate.workerId === execution.workerId && candidate.revision === execution.workerRevision);
      const workspace = this.workspace ? prepareExecutionWorkspace(this.workspace, state, task.taskId, execution.executionId, this.artifactStore) : undefined;
      const activity = worker?.physicalAvailable === false
        ? { status: "failed", failure: "PHYSICAL_WORKER_UNAVAILABLE" } as AgentRunResult
        : this.agentAdapter.run({ session: { sessionId: state.session.sessionId, workDefinitionId: state.session.workDefinitionId, definitionRevision: state.session.definitionRevision }, task, execution, grant: execution.grant, workspace });
      const isPending = typeof (this.agentAdapter as Partial<FakeAgentAdapter>).isPending === "function" && (this.agentAdapter as FakeAgentAdapter).isPending(intent.executionId);
      if (isPending) {
        void Promise.resolve(activity).then(
          (result) => this.completeAgentActivity(state.session.sessionId, intent.executionId, result, true),
          (error) => this.completeAgentActivity(state.session.sessionId, intent.executionId, { status: "failed", failure: error instanceof Error ? error.message : "Agent Activity failed" }, true),
        );
        return undefined;
      }
      try {
        return { sessionId: state.session.sessionId, executionId: intent.executionId, result: await this.withAgentTimeout(activity, task.contract.budgets?.maxWallTimeMs ?? 30_000, intent.executionId) };
      } catch (error) {
        return { sessionId: state.session.sessionId, executionId: intent.executionId, result: { status: "failed", failure: error instanceof Error ? error.message : "Agent Activity failed" } as AgentRunResult };
      }
    }));
    for (const item of completed) if (item) await this.completeAgentActivity(item.sessionId, item.executionId, item.result);
  }

  private async completeAgentActivity(sessionId: string, executionId: string, result: AgentRunResult, background = false): Promise<void> {
      const state = this.state(sessionId);
      if (!state) return;
      let artifactVersions;
      try {
        const executionWorkspace = this.workspace ? prepareExecutionWorkspace(this.workspace, state, state.executions[executionId]?.taskId ?? "", executionId, this.artifactStore) : undefined;
        if (executionWorkspace && result.artifacts && result.artifacts.length > 0) throw new DomainError("INVARIANT_VIOLATION", "local-workspace Agents must use output/ as their sole artifact source");
        artifactVersions = executionWorkspace && result.status !== "abandoned" && result.status !== "cancelled"
          ? snapshotOutputDirectory(this.artifactStore, executionWorkspace.outputPath, executionId)
          : result.artifacts
            ?.filter((artifact) => result.status !== "abandoned" || artifact.reliableRunReport === true)
            .map((artifact, ordinal) => {
            const staged = this.artifactStore.stage(artifact.content, artifact.mediaType ?? "application/octet-stream");
            this.artifactStore.finalize(staged);
            return {
              artifactVersionId: `${executionId}:artifact:${ordinal}`,
              artifactKind: "file" as const,
              blobHash: staged.blobHash,
              size: staged.size,
              mediaType: staged.mediaType,
              origin: { kind: "execution", executionId } as const,
              immutable: true as const,
            };
          });
      } catch (error) {
        result = { status: "failed", failure: error instanceof Error ? error.message : "ArtifactStore failed" };
        artifactVersions = undefined;
      }
      await this.applyInternal(sessionId, {
        type: "agentResult",
        executionId,
        status: result.status,
        outcome: result.outcome,
        result: result.result,
        failure: result.failure,
        artifactVersions,
      }, background);
  }

  private async withAgentTimeout(activity: AgentRunResult | Promise<AgentRunResult>, timeoutMs: number, executionId: string): Promise<AgentRunResult> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        Promise.resolve(activity),
        new Promise<AgentRunResult>((resolve) => {
          timer = setTimeout(() => {
            void this.agentAdapter.cancel(executionId).catch(() => undefined);
            resolve({ status: "failed", failure: "AGENT_ACTIVITY_TIMEOUT" });
          }, timeoutMs);
        }),
      ]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  private async applyInternal(sessionId: string, command: DomainCommand, background = false): Promise<void> {
    const state = this.temporalStates.get(sessionId) ?? this.registry.getRuntimeState(sessionId);
    if (!state) return;
    const envelope: CommandEnvelope = { schemaVersion: 1, sessionId, commandId: `internal:${command.type}:${command.type === "agentResult" ? command.executionId : hashJson(command as unknown as JsonValue)}`, actor: { actorId: "runtime", actorType: "runtime" }, command };
    if (background) {
      await this.apply(sessionId, envelope);
      return;
    }
    const reduction = reduceCommand(state, envelope, { workers: this.workers });
    const result = this.registry.commit(envelope, reduction, hashJson(envelope as unknown as JsonValue));
    if (!result.duplicate && reduction.kind === "accepted" && reduction.advanceRevision) {
      this.temporalStates.set(sessionId, reduction.nextState);
      await this.executeIntents(reduction.intents);
      this.reconcileDerivedViews(sessionId);
    }
  }

  private stateForIntent(intent: ReductionAccepted["intents"][number]): RuntimeState | undefined {
    if (intent.kind === "scheduleTimer") {
      for (const state of this.temporalStates.values()) if (state.waits[intent.waitId]) return state;
      return undefined;
    }
    for (const state of this.temporalStates.values()) if (state.executions[intent.executionId]) return state;
    return undefined;
  }

  private async drive(sessionId: string): Promise<void> {
    const prior = this.driveLocks.get(sessionId);
    if (prior) return prior;
    const run = this.driveLoop(sessionId);
    this.driveLocks.set(sessionId, run);
    try {
      await run;
    } finally {
      if (this.driveLocks.get(sessionId) === run) this.driveLocks.delete(sessionId);
    }
  }

  private async driveLoop(sessionId: string): Promise<void> {
    for (let count = 0; count < 10_000; count += 1) {
      const state = this.state(sessionId);
      if (!state || state.session.state === "completed" || state.session.state === "cancelled") return;
      const envelope: CommandEnvelope = { schemaVersion: 1, sessionId, commandId: `internal:advance:${state.revision + 1}`, actor: { actorId: "runtime", actorType: "runtime" }, command: { type: "advance" } };
      const reduction = reduceCommand(state, envelope, { workers: this.workers });
      if (reduction.kind !== "accepted") return;
      const result = this.registry.commit(envelope, reduction, hashJson(envelope as unknown as JsonValue));
      if (!result.duplicate && reduction.advanceRevision) {
        this.temporalStates.set(sessionId, reduction.nextState);
        await this.executeIntents(reduction.intents);
      }
      const advanced = result.response && typeof result.response === "object" && !Array.isArray(result.response) && result.response.advanced === true;
      if (!advanced) return;
    }
    throw new DomainError("INVARIANT_VIOLATION", "workflow drive exceeded its progress limit");
  }
}

/** Consumer outbox が利用する、receipt-first の外部イベント配信 facade。 */
export async function deliverExternalEvent(orchestrator: Pick<WorkOrchestrator, "deliverExternalEvent">, sessionId: string, event: Extract<DomainCommand, { type: "receiveExternalEvent" }>['event']): Promise<JsonValue> {
  if (!orchestrator || typeof orchestrator.deliverExternalEvent !== "function") throw new DomainError("INVALID_COMMAND", "a WorkOrchestrator external-event facade is required");
  return orchestrator.deliverExternalEvent(sessionId, event);
}
