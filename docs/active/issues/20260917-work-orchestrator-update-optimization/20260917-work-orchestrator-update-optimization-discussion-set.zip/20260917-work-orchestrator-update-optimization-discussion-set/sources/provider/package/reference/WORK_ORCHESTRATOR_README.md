# Work Orchestrator v1

Work Orchestrator は、`WorkDefinition` を実行可能な Task / Execution / Wait に展開し、Human Task、Agent Task、外部イベント、timer、成果物、監査履歴を一つの実行モデルで扱う Node.js パッケージです。このガイドは、公開パッケージを Workspace とともに利用する基本経路から、Agent・Temporal 連携までを説明します。個々の契約は [API_REFERENCE.md](./API_REFERENCE.md) を参照してください。

## 1. 前提

パッケージは ESM です。Quickstart は `.mjs` を使うため、consumer 側の `package.json` に追加の `"type": "module"` は必要ありません。

このリポジトリの build/test 検証環境は Node.js `>=24 <25` です。これはリポジトリの検証条件であり、パッケージ単体の互換性保証を追加するものではありません。

## 2. インストールと Workspace 初期化

consumer directory でパッケージを導入します。

```bash
npm install work-orchestrator
npx work-orchestrator init .
```

ローカル package を試す場合は、build 済み package directory を指定できます。

```bash
npm install /absolute/path/to/repository/package --install-links
```

`init` は Workspace の設定、Registry、ArtifactStore および作業用ディレクトリを初期化します。プログラムからは `initWorkspace(".")` が同等の公開 API です。作成済み Workspace を利用するコードでは `openWorkspace(".")` を呼び出します。

## 3. Quickstart: Workspace-backed Human Task

`quickstart.mjs` を作成し、次のコードを保存します。

```js
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import {
  openWorkspace,
  WorkOrchestrator,
} from "work-orchestrator";

const workspace = openWorkspace(".");

try {
  const orchestrator = new WorkOrchestrator({
    registry: workspace.registry,
    artifactStore: workspace.artifactStore,
    workspace,
  });

  orchestrator.registerDefinition({
    workDefinitionId: "quickstart",
    revision: 0,
    schemaVersion: 2,
    root: {
      kind: "task",
      id: "review",
      goal: "Review the work",
      contract: {
        workerKind: "human",
        requiredCapabilities: [],
        requestedPermissions: [],
        retryPolicy: { maxAttempts: 1 },
      },
    },
  });

  const sessionId = `quickstart-${randomUUID()}`;
  const actor = {
    actorId: "local-user",
    actorType: "human",
  };

  await orchestrator.startSession({
    sessionId,
    workDefinitionId: "quickstart",
    actor,
  });

  const view = orchestrator.getSessionView(sessionId);
  if (!view) throw new Error("session not found");

  const task = Object.values(view.tasks)
    .find((candidate) => candidate.stepId === "review");
  if (!task) throw new Error("review task not found");

  await orchestrator.claimTask(sessionId, task.taskId, actor);
  await orchestrator.completeHumanTask(
    sessionId,
    task.taskId,
    actor,
  );

  const finalView = orchestrator.getSessionView(sessionId);
  assert.equal(finalView?.session.state, "completed");
  console.log("completed");
} finally {
  workspace.registry.close();
}
```

実行します。

```bash
node quickstart.mjs
```

この例では、Workspace の Registry と ArtifactStore を明示的に `WorkOrchestrator` へ渡し、schema v2 の単一 Human Task を登録してから Session を開始します。`getSessionView()` で生成された Task を取得するため、consumer 側で `taskId` の生成規則を組み立てる必要はありません。`randomUUID()` による Session ID は、同じ永続 Workspace で Quickstart を再実行しても Session ID が衝突しないようにするためのものです。

`workspace` を指定しただけでは `registry` や `artifactStore` は自動接続されません。Workspace-backed の `WorkOrchestrator` には、Quickstart のように三つの値を明示してください。

## 4. `startSession()` と filesystem input の snapshot

基本の Session ライフサイクルでは、入力値を `startSession()` の `input` に渡します。Session 開始時にファイルまたはディレクトリを immutable Artifact として snapshot し、bootstrap metadata とともに保存したい場合は `startSessionFromWorkspace()` を使います。

```js
const sessionId = `with-input-${randomUUID()}`;
await orchestrator.startSessionFromWorkspace({
  sessionId,
  workDefinitionId: "quickstart",
  revision: 0,
  input: { source: "filesystem" },
  inputPaths: ["./input", "./request.md"],
  workspace,
});
```

このメソッドは指定した path を ArtifactStore に保存し、Session の入力 Artifact と bootstrap manifest を用意してから Session を開始します。filesystem snapshot は入力の寿命を固定するための上位経路です。Human Task の claim / complete だけを理解するための前提ではありません。

## 5. 最小の in-memory 利用

永続 Workspace が不要な概念説明、単体テスト、短命な process では `new WorkOrchestrator()` を使えます。これは補助的な経路です。

```js
const orchestrator = new WorkOrchestrator();
orchestrator.registerDefinition(definition);
await orchestrator.startSession({
  sessionId: `test-${randomUUID()}`,
  workDefinitionId: definition.workDefinitionId,
});
```

既定の Registry は in-memory SQLite、ArtifactStore は temporary directory、AgentAdapter は deterministic な `FakeAgentAdapter` です。Agent Task を運用する場合は `AgentAdapter` と `WorkerProfile` を明示してください。

## 6. 永続化ライフサイクル

統合された保存領域には `initWorkspace()` / `openWorkspace()` を使います。Registry と ArtifactStore を個別に管理する場合は、初回作成時に `initialize()`、既存の保存領域を開くときに `open()` を使います。

```js
import {
  ArtifactStore,
  Registry,
} from "work-orchestrator";

const registry = Registry.initialize("./data/registry.sqlite");
const artifactStore = ArtifactStore.initialize("./data/artifacts");

try {
  // registerDefinition(), startSession(), ...
} finally {
  registry.close();
}
```

`Registry.open()` と `ArtifactStore.open()` は、すでに初期化された正しい保存領域を開いて検証します。これらは初期化や migration のコマンドではありません。Workspace や個別 authority を生成した呼び出し側が、所有する Registry（必要なら RegistryReader）を `close()` してください。`WorkOrchestrator` 自体に `close()` はありません。

Registry は Session state、Domain commit、command receipt、Task / Execution projection を SQLite に保持し、ArtifactStore は content-addressed な immutable blob bytes を保持します。両者を永続利用する場合は保存先を一時領域にしないでください。Registry は single writer host 前提です。

## 7. 対話 CLI

Workspace を初期化します。

```bash
npx work-orchestrator init .
```

明示的に Workspace を指定して対話モードを起動します。

```bash
npx work-orchestrator --workspace . --actor local-user
```

Workspace tree の中で Workspace discovery に任せる場合は次も使えます。

```bash
npx work-orchestrator --actor local-user
```

`init` と `worker` は実際の command であり、Workspace path を positional argument にできます。

```bash
npx work-orchestrator init ./my-workspace
npx work-orchestrator worker ./my-workspace
```

対話モードの `new` は、Workspace Registry に登録済みの WorkDefinition を一覧表示し、選択した revision から Session を開始します。CLI は Definition を作成・登録しません。Definition の登録は公開 API の `registerDefinition()` を使って事前に行ってください。

## 8. Agent Task

Agent 実装の拡張点は `AgentAdapter` です。Agent Task の contract を満たす `WorkerProfile` も必要です。

```js
const orchestrator = new WorkOrchestrator({
  agentAdapter: myAgentAdapter,
  workers: [{
    workerId: "local-agent",
    revision: 1,
    enabled: true,
    capabilities: ["review"],
    enforceablePermissions: [],
    enforceableBudgets: [],
    routingPriority: 1,
    physicalAvailable: true,
  }],
});
```

Codex CLI を利用する場合は `createCodexCliAdapter()` を使います。

```js
import { createCodexCliAdapter } from "work-orchestrator";

const agentAdapter = createCodexCliAdapter({
  sandbox: "read-only",
  cwd: process.cwd(),
});
```

`FakeAgentAdapter` は受入試験用の deterministic adapter です。実運用では Agent adapter と worker を明示してください。

## 9. Local / in-process と Temporal-backed の選択

| 要件 | 推奨入口 |
| --- | --- |
| 単一 Node.js process 内で orchestration を実行する | `WorkOrchestrator` |
| Session / Task / history を観測する | `getSessionView()` |
| SQLite / Artifact bytes を管理する | `Registry`, `ArtifactStore` |
| Agent 実装を差し替える | `AgentAdapter`, `WorkerProfile` |
| Temporal Server 上で durable Workflow と Worker を使う | `createWorkOrchestratorWorker()` + `WorkOrchestratorTemporalClient` |

`TemporalSessionRuntime` は Temporal SDK を使わない Workflow ID / execution chain / Continue-As-New の契約模型であり、実 Temporal 接続の通常入口ではありません。

## 10. Temporal-backed execution

Temporal-backed mode では Temporal Server、Worker process、Client process が必要です。Workflow ID は `sessionId` と同じ値です。

### Worker 側

Registry と ArtifactStore はあらかじめ `Registry.initialize()` / `ArtifactStore.initialize()` または Workspace の `init` で初期化しておきます。Worker runtime に path を渡す場合、`createTemporalActivities()` はその path を既存 authority として `open()` します。Worker の path 設定が persistence の初期化や migration を自動的に行うわけではありません。

```js
import {
  ArtifactStore,
  Registry,
  createWorkOrchestratorWorker,
  validateAndHashDefinition,
} from "work-orchestrator";

const registry = Registry.open("./data/registry.sqlite");
const artifactStore = ArtifactStore.open("./data/artifacts");
registry.registerDefinition(validateAndHashDefinition(definition));

const worker = await createWorkOrchestratorWorker({
  taskQueue: "work-orchestrator",
  runtime: {
    registry,
    artifactStore,
    workers,
    agentAdapter,
  },
});

await worker.run();
```

`runWorkOrchestratorWorker()` は Worker の生成と `run()` をまとめる convenience function です。

### Client 側

```js
import { connectWorkOrchestratorClient } from "work-orchestrator";

const temporal = await connectWorkOrchestratorClient({
  taskQueue: "work-orchestrator",
});

const handle = await temporal.start({
  sessionId: `temporal-${randomUUID()}`,
  workDefinitionId: "quickstart",
  revision: 0,
});
```

Human Task 操作、cancellation、external event は `WorkOrchestratorTemporalClient` の facade から送信します。

```js
await temporal.claimTask(handle, {
  taskId,
  actor: { actorId: "alice", actorType: "human" },
});

await temporal.completeHumanTask(handle, {
  taskId,
  actor: { actorId: "alice", actorType: "human" },
});
```

`TemporalWorkflowInput` では必要に応じて `registryTaskQueue`、`agentTaskQueue`、`agentScheduleToStartTimeoutMs` を指定できます。物理 Agent Worker が task queue を poll していない場合、schedule-to-start timeout は Execution failure として Domain に反映されます。詳細な Workflow、Activity、Update の契約は [API_REFERENCE.md](./API_REFERENCE.md) を参照してください。

## 11. WorkDefinition の主な Step

`WorkDefinition.root` は次の `Step` のいずれかです。

| `kind` | 用途 |
| --- | --- |
| `task` | Human または Agent が処理する Task |
| `sequence` | child Step を順番に実行 |
| `choice` | decision Task または入力に応じて branch を選択 |
| `parallelAll` | 全 branch を実行して全完了を待つ |
| `waitEvent` | `eventType` / `correlationKey` に一致する external event を待つ |
| `waitTimer` | 指定 `delayMs` の timer を待つ |
| `dynamicExpand` | planner の proposal から実行時 Task を生成 |
| `noop` | schema v2 の no-op |

`registerDefinition()` は Definition の検証と canonical hash を行います。同じ `workDefinitionId` / `revision` に異なる Definition hash を再登録することはできません。

## 12. よくある問題

### `Cannot find package 'work-orchestrator'`

consumer 側で package がインストールされているか確認し、`from "work-orchestrator"` から import してください。`src/` や `dist/` を直接 import する必要はありません。

### `dist/index.js` がない

ローカル package を使う場合は repository root で package を build してから consumer に導入してください。公開 package には build 済みの `dist/` が含まれます。

### Agent Task が期待せず成功する

既定 AgentAdapter は `FakeAgentAdapter` です。実 Agent を使う場合は `agentAdapter` と `workers` を明示してください。

### Agent Task が `NO_ELIGIBLE_WORKER` 相当になる

`WorkerProfile` の `enabled`、`capabilities`、`enforceablePermissions`、`enforceableBudgets` が Task contract を満たしているか確認してください。

### Temporal Workflow が Agent 実行待ちで失敗する

`agentTaskQueue` を poll する物理 Worker が存在するか、`agentScheduleToStartTimeoutMs` が適切か確認してください。

### 永続 Registry を開けない

SQLite file と ArtifactStore root が初期化済みか、親 directory と権限が適切か確認してください。`open()` は欠落した authority を初期化しません。

## 13. API Reference

公開されている型・関数・クラス、主要 class の method、low-level primitive を含む root export の完全索引は [API_REFERENCE.md](./API_REFERENCE.md) にあります。通常の import は package root から行います。

```js
import {
  WorkOrchestrator,
  Registry,
  ArtifactStore,
} from "work-orchestrator";
```

`work-orchestrator/runtime` や `work-orchestrator/registry` のような subpath export は現在提供していません。
