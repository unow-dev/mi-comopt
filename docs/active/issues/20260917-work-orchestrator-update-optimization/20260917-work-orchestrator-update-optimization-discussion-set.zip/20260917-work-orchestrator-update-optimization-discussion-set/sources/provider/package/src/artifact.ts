import { existsSync, lstatSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { basename, extname, join, relative, resolve, sep } from "node:path";
import { sha256, canonicalJson } from "./canonical.js";
import { ArtifactStore } from "./artifact-store.js";
import { DomainError, type ArtifactVersionRuntime, type JsonValue } from "./contracts.js";

export interface DirectoryArtifactManifestV1 {
  formatVersion: 1;
  files: Array<{
    path: string;
    blobHash: string;
    size: number;
    mediaType: string;
  }>;
}

export interface SnapshotOptions {
  logicalPath?: string;
  sourceRef?: string;
  artifactVersionId?: string;
}

export interface SnapshotResult {
  artifact: ArtifactVersionRuntime;
  manifest?: DirectoryArtifactManifestV1;
}

const MEDIA_TYPES: Record<string, string> = {
  ".json": "application/json",
  ".md": "text/markdown",
  ".txt": "text/plain",
  ".csv": "text/csv",
  ".html": "text/html",
  ".js": "text/javascript",
  ".ts": "text/typescript",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".pdf": "application/pdf",
};

export function mediaTypeForPath(path: string): string {
  return MEDIA_TYPES[extname(path).toLowerCase()] ?? "application/octet-stream";
}

export function validateRelativeArtifactPath(path: string): string {
  if (!path || path.includes("\\") || path.startsWith("/") || path.includes("\0")) throw new DomainError("ARTIFACT_NOT_FOUND", `unsafe artifact path: ${path}`);
  const normalized = path.split("/").filter((part) => part.length > 0).join("/");
  if (!normalized || normalized === "." || normalized.split("/").some((part) => part === ".." || part === ".")) throw new DomainError("ARTIFACT_NOT_FOUND", `unsafe artifact path: ${path}`);
  return normalized;
}

export function validateDirectoryManifest(manifest: unknown): DirectoryArtifactManifestV1 {
  if (!manifest || typeof manifest !== "object" || (manifest as { formatVersion?: unknown }).formatVersion !== 1 || !Array.isArray((manifest as { files?: unknown }).files)) {
    throw new DomainError("ARTIFACT_STORE_CORRUPT", "directory manifest format is invalid");
  }
  const files = (manifest as { files: unknown[] }).files.map((entry, index) => {
    if (!entry || typeof entry !== "object") throw new DomainError("ARTIFACT_STORE_CORRUPT", `directory manifest entry ${index} is invalid`);
    const item = entry as Record<string, unknown>;
    const path = validateRelativeArtifactPath(String(item.path ?? ""));
    if (!/^[a-f0-9]{64}$/.test(String(item.blobHash ?? "")) || !Number.isSafeInteger(item.size) || Number(item.size) < 0 || typeof item.mediaType !== "string" || item.mediaType.length === 0) {
      throw new DomainError("ARTIFACT_STORE_CORRUPT", `directory manifest entry ${path} is invalid`);
    }
    return { path, blobHash: String(item.blobHash), size: Number(item.size), mediaType: item.mediaType };
  });
  const sorted = [...files].sort((left, right) => left.path.localeCompare(right.path));
  if (sorted.some((item, index) => index > 0 && item.path === sorted[index - 1].path)) throw new DomainError("ARTIFACT_STORE_CORRUPT", "directory manifest contains duplicate paths");
  if (JSON.stringify(files) !== JSON.stringify(sorted)) throw new DomainError("ARTIFACT_STORE_CORRUPT", "directory manifest files must be sorted");
  return { formatVersion: 1, files: sorted };
}

function directoryFiles(root: string): string[] {
  const result: string[] = [];
  const visit = (current: string): void => {
    for (const entry of readdirSync(current, { withFileTypes: true }).sort((left, right) => left.name.localeCompare(right.name))) {
      const full = join(current, entry.name);
      if (entry.isSymbolicLink()) throw new DomainError("ARTIFACT_NOT_FOUND", `symbolic links are not supported in artifacts: ${full}`);
      if (entry.isDirectory()) visit(full);
      else if (entry.isFile()) result.push(full);
      else throw new DomainError("ARTIFACT_NOT_FOUND", `unsupported directory entry: ${full}`);
    }
  };
  visit(root);
  return result;
}

export function snapshotPath(store: ArtifactStore, sourcePath: string, options: SnapshotOptions = {}): SnapshotResult {
  const absolute = resolve(sourcePath);
  if (!existsSync(absolute)) throw new DomainError("ARTIFACT_NOT_FOUND", `input path does not exist: ${sourcePath}`);
  const sourceRef = options.sourceRef ?? absolute;
  const logicalPath = options.logicalPath ?? basename(absolute);
  const stat = lstatSync(absolute);
  if (stat.isSymbolicLink()) throw new DomainError("ARTIFACT_NOT_FOUND", "symbolic-link inputs are not supported");
  if (stat.isFile()) {
    const staged = store.stage(readFileSync(absolute), mediaTypeForPath(absolute));
    store.finalize(staged);
    return {
      artifact: {
        artifactVersionId: options.artifactVersionId ?? `external:${sha256(`${sourceRef}\0${staged.blobHash}`)}`,
        artifactKind: "file",
        blobHash: staged.blobHash,
        size: staged.size,
        mediaType: staged.mediaType,
        logicalPath,
        origin: { kind: "external", sourceRef },
        immutable: true,
      },
    };
  }
  if (!stat.isDirectory()) throw new DomainError("ARTIFACT_NOT_FOUND", `unsupported input path: ${sourcePath}`);
  const files = directoryFiles(absolute).map((file) => {
    const staged = store.stage(readFileSync(file), mediaTypeForPath(file));
    store.finalize(staged);
    return {
      path: validateRelativeArtifactPath(relative(absolute, file).split(sep).join("/")),
      blobHash: staged.blobHash,
      size: staged.size,
      mediaType: staged.mediaType,
    };
  }).sort((left, right) => left.path.localeCompare(right.path));
  const manifest: DirectoryArtifactManifestV1 = validateDirectoryManifest({ formatVersion: 1, files });
  const manifestBytes = Buffer.from(canonicalJson(manifest as unknown as JsonValue));
  const stagedManifest = store.stage(manifestBytes, "application/vnd.work-orchestrator.directory-manifest+json");
  store.finalize(stagedManifest);
  return {
    manifest,
    artifact: {
      artifactVersionId: options.artifactVersionId ?? `external:${sha256(`${sourceRef}\0${stagedManifest.blobHash}`)}`,
      artifactKind: "directory",
      blobHash: stagedManifest.blobHash,
      size: stagedManifest.size,
      mediaType: stagedManifest.mediaType,
      logicalPath,
      origin: { kind: "external", sourceRef },
      immutable: true,
    },
  };
}

/** Snapshot each top-level output entry. A directory entry remains one ArtifactVersion. */
export function snapshotOutputDirectory(store: ArtifactStore, outputRoot: string, executionId: string): ArtifactVersionRuntime[] {
  if (!existsSync(outputRoot) || !statSync(outputRoot).isDirectory()) return [];
  return readdirSync(outputRoot, { withFileTypes: true }).sort((left, right) => left.name.localeCompare(right.name)).map((entry, ordinal) => {
    if (entry.isSymbolicLink()) throw new DomainError("ARTIFACT_NOT_FOUND", `symbolic-link outputs are not supported: ${entry.name}`);
    const snapshot = snapshotPath(store, join(outputRoot, entry.name), {
      sourceRef: `${executionId}:output:${entry.name}`,
      logicalPath: entry.name,
      artifactVersionId: `${executionId}:artifact:${ordinal}`,
    });
    return { ...snapshot.artifact, origin: { kind: "execution", executionId } };
  });
}

export function readDirectoryManifest(store: ArtifactStore, artifact: ArtifactVersionRuntime): DirectoryArtifactManifestV1 {
  if (artifact.artifactKind !== "directory") throw new DomainError("ARTIFACT_NOT_FOUND", "ArtifactVersion is not a directory");
  const content = store.read(artifact.blobHash);
  if (content.byteLength !== artifact.size) throw new DomainError("ARTIFACT_STORE_CORRUPT", "directory manifest size mismatch");
  return validateDirectoryManifest(JSON.parse(content.toString("utf8")));
}

export function materializeArtifact(store: ArtifactStore, artifact: ArtifactVersionRuntime, destination: string): void {
  if (artifact.artifactKind === "file") {
    const bytes = store.read(artifact.blobHash);
    if (bytes.byteLength !== artifact.size) throw new DomainError("ARTIFACT_STORE_CORRUPT", `artifact ${artifact.artifactVersionId} size mismatch`);
    mkdirSync(resolve(destination, ".."), { recursive: true });
    writeFileSync(destination, bytes, { flag: "w" });
    return;
  }
  mkdirSync(destination, { recursive: true });
  for (const entry of readDirectoryManifest(store, artifact).files) {
    const output = resolve(destination, ...entry.path.split("/"));
    if (!output.startsWith(resolve(destination) + sep)) throw new DomainError("ARTIFACT_STORE_CORRUPT", "directory manifest escaped its destination");
    const bytes = store.read(entry.blobHash);
    if (bytes.byteLength !== entry.size) throw new DomainError("ARTIFACT_STORE_CORRUPT", `directory entry ${entry.path} size mismatch`);
    mkdirSync(resolve(output, ".."), { recursive: true });
    writeFileSync(output, bytes, { flag: "w" });
  }
}
