import { canonicalJson, hashJson, isValidJsonPointer } from "./canonical.js";
import {
  DomainError,
  type DynamicExpandStep,
  type InputBinding,
  type JsonValue,
  type Step,
  type TaskContract,
  type TaskStep,
  type WorkDefinition,
} from "./contracts.js";

const STEP_KINDS = new Set(["task", "sequence", "choice", "parallelAll", "waitEvent", "waitTimer", "dynamicExpand", "noop"]);
const JSON_SCHEMA_TYPES = new Set(["object", "array", "string", "number", "integer", "boolean", "null"]);

export interface ValidatedDefinition extends WorkDefinition {
  definitionHash: string;
}

export function validateAndHashDefinition(input: WorkDefinition): ValidatedDefinition {
  const errors: string[] = [];
  if (!input || typeof input !== "object") errors.push("definition must be an object");
  if (!input?.workDefinitionId) errors.push("workDefinitionId is required");
  if (!Number.isInteger(input?.revision) || input.revision < 0) errors.push("revision must be a non-negative integer");
  if (!Number.isInteger(input?.schemaVersion) || ![1, 2].includes(input.schemaVersion)) errors.push("schemaVersion must be 1 or 2");
  for (const [name, value] of Object.entries(input?.limits ?? {})) {
    const minimum = name === "maxDynamicTasksPerSession" ? 0 : 1;
    if (!Number.isInteger(value) || value < minimum) errors.push(`limits.${name} must be ${minimum === 0 ? "a non-negative" : "a positive"} integer`);
  }

  const ids = new Set<string>();
  const visible = new Set<string>();
  const visibleTasks = new Map<string, TaskStep>();
  if (input?.root) visit(input.root, ids, errors, visible, visibleTasks, input.schemaVersion, "root");
  else errors.push("root is required");
  if (errors.length) throw new DomainError("DEFINITION_INVALID", errors.join("; "), errors as unknown as JsonValue);

  const withoutHash = { ...input } as WorkDefinition;
  delete withoutHash.definitionHash;
  let definitionHash: string;
  try { definitionHash = hashJson(withoutHash as unknown as JsonValue); }
  catch (error) { throw new DomainError("DEFINITION_INVALID", error instanceof Error ? error.message : "definition is not valid JSON"); }
  if (input.definitionHash && input.definitionHash !== definitionHash) throw new DomainError("DEFINITION_INVALID", "definitionHash does not match canonical definition");
  return { ...withoutHash, definitionHash };
}

function visit(step: Step, ids: Set<string>, errors: string[], visible: Set<string>, visibleTasks: Map<string, TaskStep>, schemaVersion: number, path: string): void {
  if (!step || typeof step !== "object" || !STEP_KINDS.has((step as Step).kind)) { errors.push(`${path}: unsupported step kind`); return; }
  if (!step.id || ids.has(step.id)) { errors.push(`${path}: duplicate or empty step id ${step.id ?? ""}`); return; }
  ids.add(step.id);
  if (step.kind === "task") {
    validateTask(step, errors, visible, visibleTasks, schemaVersion, path);
    visible.add(step.id); visibleTasks.set(step.id, step); return;
  }
  if (step.kind === "noop") {
    if (schemaVersion !== 2) errors.push(`${path}: Noop requires schemaVersion 2`);
    return;
  }
  if (step.kind === "sequence") {
    if (!Array.isArray(step.children) || step.children.length === 0) errors.push(`${path}: Sequence must not be empty`);
    const sequenceVisible = new Set(visible); const sequenceTasks = new Map(visibleTasks);
    for (const child of step.children ?? []) {
      visit(child, ids, errors, sequenceVisible, sequenceTasks, schemaVersion, `${path}/${step.id}/${child.id ?? "?"}`);
      if (child?.id) sequenceVisible.add(child.id); if (child?.kind === "task") sequenceTasks.set(child.id, child);
    }
    return;
  }
  if (step.kind === "parallelAll") {
    const branches = Object.entries(step.branches ?? {}); if (branches.length === 0) errors.push(`${path}: ParallelAll must not be empty`);
    for (const [branch, child] of branches) visit(child, ids, errors, new Set(visible), new Map(visibleTasks), schemaVersion, `${path}/${step.id}/${branch}`);
    return;
  }
  if (step.kind === "choice") {
    let branchVisible = new Set(visible); let branchTasks = new Map(visibleTasks);
    if (isTaskStep(step.decision)) {
      if (!step.decision.id || ids.has(step.decision.id)) errors.push(`${path}: duplicate or empty decision id`);
      else {
        ids.add(step.decision.id); validateTask(step.decision, errors, visible, visibleTasks, schemaVersion, `${path}/${step.id}/decision`);
        branchVisible.add(step.decision.id); branchTasks.set(step.decision.id, step.decision);
      }
      const allowed = new Set(step.decision.contract?.allowedOutcomes ?? []); const branches = Object.entries(step.branches ?? {});
      if (branches.length === 0 || allowed.size !== branches.length || branches.some(([key]) => !allowed.has(key))) errors.push(`${path}: Choice outcomes must exactly equal branch keys`);
    } else if (schemaVersion === 2 && isInputBinding(step.decision)) {
      validateBinding("decision", step.decision, errors, visible, visibleTasks, schemaVersion, path);
      const branches = Object.entries(step.branches ?? {});
      if (branches.length === 0) errors.push(`${path}: Choice must have at least one branch`);
      if (step.decision.source === "task" && step.decision.stepId && visibleTasks.has(step.decision.stepId)) {
        const allowed = new Set(visibleTasks.get(step.decision.stepId)!.contract.allowedOutcomes ?? []);
        if (allowed.size !== branches.length || branches.some(([key]) => !allowed.has(key))) errors.push(`${path}: Choice binding branches must exactly equal the referenced Task outcomes`);
      }
    } else errors.push(`${path}: Choice decision must be a Task or v2 InputBinding`);
    for (const [branch, child] of Object.entries(step.branches ?? {})) visit(child, ids, errors, new Set(branchVisible), new Map(branchTasks), schemaVersion, `${path}/${step.id}/${branch}`);
    return;
  }
  if (step.kind === "waitEvent") {
    if (!step.eventType) errors.push(`${path}: eventType is required`);
    if (typeof step.correlationKey === "string") { if (step.correlationKey.length === 0) errors.push(`${path}: correlationKey must not be empty`); }
    else if (schemaVersion === 2 && isInputBinding(step.correlationKey)) validateBinding("correlationKey", step.correlationKey, errors, visible, visibleTasks, schemaVersion, path);
    else errors.push(`${path}: invalid WaitEvent matcher`);
    return;
  }
  if (step.kind === "waitTimer") { if (!Number.isFinite(step.delayMs) || step.delayMs < 0) errors.push(`${path}: delayMs must be finite and non-negative`); return; }
  validateDynamic(step, ids, errors, visible, visibleTasks, schemaVersion, path);
}

function validateTask(task: TaskStep, errors: string[], visible: Set<string>, visibleTasks: Map<string, TaskStep>, schemaVersion: number, path: string): void {
  validateContract(task.contract, errors, schemaVersion, path);
  if (task.contract?.resultSchema !== undefined) validateSchemaDefinition(task.contract.resultSchema, errors, `${path}/resultSchema`);
  if (task.contract?.outputSchema !== undefined) validateSchemaDefinition(task.contract.outputSchema, errors, `${path}/outputSchema`);
  if (typeof task.goal !== "string") errors.push(`${path}: goal must be a string`);
  if (task.inputBindings !== undefined && (!task.inputBindings || typeof task.inputBindings !== "object" || Array.isArray(task.inputBindings))) errors.push(`${path}: inputBindings must be an object`);
  for (const [name, binding] of Object.entries(task.inputBindings ?? {})) validateBinding(name, binding, errors, visible, visibleTasks, schemaVersion, path);
}

function validateSchemaDefinition(schema: JsonValue, errors: string[], path: string): void {
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) { errors.push(`${path}: runtime schema must be an object`); return; }
  const object = schema as Record<string, JsonValue>;
  if (object.type !== undefined && (typeof object.type !== "string" || !JSON_SCHEMA_TYPES.has(object.type))) errors.push(`${path}: unsupported schema type`);
  if (object.additionalProperties !== undefined && typeof object.additionalProperties !== "boolean" && typeof object.additionalProperties !== "object") errors.push(`${path}: additionalProperties must be boolean or schema`);
  const minLength = object.minLength;
  if (minLength !== undefined && (!Number.isInteger(minLength) || Number(minLength) < 0)) errors.push(`${path}: minLength must be a non-negative integer`);
  if (object.required !== undefined && (!Array.isArray(object.required) || !object.required.every((item) => typeof item === "string"))) errors.push(`${path}: required must be a string array`);
  if (object.properties !== undefined) {
    if (!object.properties || typeof object.properties !== "object" || Array.isArray(object.properties)) errors.push(`${path}: properties must be an object`);
    else for (const [key, child] of Object.entries(object.properties)) validateSchemaDefinition(child, errors, `${path}/properties/${key}`);
  }
  if (object.additionalProperties && typeof object.additionalProperties === "object" && !Array.isArray(object.additionalProperties)) validateSchemaDefinition(object.additionalProperties, errors, `${path}/additionalProperties`);
  if (object.items !== undefined) validateSchemaDefinition(object.items, errors, `${path}/items`);
  if (object.enum !== undefined && (!Array.isArray(object.enum) || object.enum.length === 0)) errors.push(`${path}: enum must be a non-empty array`);
}

function validateContract(contract: TaskContract | undefined, errors: string[], schemaVersion: number, path: string): void {
  if (!contract || (contract.workerKind !== "human" && contract.workerKind !== "agent")) { errors.push(`${path}: invalid workerKind`); return; }
  if (!Array.isArray(contract.requiredCapabilities) || !Array.isArray(contract.requestedPermissions)) errors.push(`${path}: capabilities and permissions must be arrays`);
  if (!contract.retryPolicy || !Number.isInteger(contract.retryPolicy.maxAttempts) || contract.retryPolicy.maxAttempts < 1) errors.push(`${path}: maxAttempts must be a positive integer`);
  const requiresBudget = schemaVersion === 1 || contract.workerKind === "agent";
  if (requiresBudget && (!contract.budgets || !Number.isFinite(contract.budgets.maxWallTimeMs) || contract.budgets.maxWallTimeMs <= 0)) errors.push(`${path}: maxWallTimeMs must be finite and positive`);
  for (const [name, value] of Object.entries(contract.budgets ?? {})) if (value !== undefined && (!Number.isFinite(value) || value < 0)) errors.push(`${path}: budget ${name} is invalid`);
  if (contract.allowedOutcomes && (!Array.isArray(contract.allowedOutcomes) || new Set(contract.allowedOutcomes).size !== contract.allowedOutcomes.length || !contract.allowedOutcomes.every((value) => typeof value === "string" && value.length > 0))) errors.push(`${path}: allowedOutcomes must contain unique non-empty strings`);
  if (schemaVersion === 2 && contract.workerKind === "agent" && (!Array.isArray(contract.requiredCapabilities) || contract.requiredCapabilities.length !== 1)) errors.push(`${path}: agent tasks require exactly one capability`);
}

function isInputBinding(value: unknown): value is InputBinding { return Boolean(value && typeof value === "object" && !Array.isArray(value)); }
function isTaskStep(value: unknown): value is TaskStep { return Boolean(value && typeof value === "object" && (value as { kind?: string }).kind === "task"); }

function validateBinding(name: string, binding: InputBinding, errors: string[], visible: Set<string>, visibleTasks: Map<string, TaskStep>, schemaVersion: number, path: string): void {
  if (!binding || (binding.source !== "session" && binding.source !== "step" && binding.source !== "task")) { errors.push(`${path}: input ${name} has invalid source`); return; }
  if (schemaVersion === 1 && binding.source === "task") errors.push(`${path}: input ${name} task source requires schemaVersion 2`);
  if (typeof binding.path !== "string" || !isValidJsonPointer(binding.path)) errors.push(`${path}: input ${name} has invalid JSON Pointer`);
  if ((binding.source === "step" || binding.source === "task") && (!binding.stepId || !visible.has(binding.stepId))) errors.push(`${path}: input ${name} references a lexically invisible step`);
  if (binding.source === "task" && binding.stepId && visible.has(binding.stepId) && !visibleTasks.has(binding.stepId)) errors.push(`${path}: input ${name} references a non-Task step`);
}

function validateDynamic(step: DynamicExpandStep, ids: Set<string>, errors: string[], visible: Set<string>, visibleTasks: Map<string, TaskStep>, schemaVersion: number, path: string): void {
  if (step.planner?.kind !== "task" || step.planner.contract?.workerKind !== "agent") errors.push(`${path}: DynamicExpand planner must be an Agent Task`);
  else validateTask(step.planner, errors, visible, visibleTasks, schemaVersion, `${path}/${step.id}/planner`);
  if (step.strategy !== "sequence" && step.strategy !== "parallelAll") errors.push(`${path}: invalid expansion strategy`);
  if (!Number.isInteger(step.maxTasks) || step.maxTasks < 1) errors.push(`${path}: maxTasks must be positive`);
  const policy = step.proposalPolicy;
  if (!policy || (policy.workerKind !== "human" && policy.workerKind !== "agent")) errors.push(`${path}: invalid proposal policy`);
  if (policy) validateContract({ workerKind: policy.workerKind, requiredCapabilities: policy.requiredCapabilities, requestedPermissions: policy.requestedPermissions, retryPolicy: policy.retryPolicy, budgets: policy.budgets, allowedOutcomes: policy.allowedOutcomes }, errors, schemaVersion, `${path}/proposalPolicy`);
  if (step.planner?.id && ids.has(step.planner.id)) errors.push(`${path}: planner id collides with a static step id`);
  if (step.planner?.id) ids.add(step.planner.id);
}

export function findStep(root: Step, id: string): Step | undefined {
  if (root.id === id) return root;
  if (root.kind === "sequence") for (const child of root.children) { const found = findStep(child, id); if (found) return found; }
  else if (root.kind === "parallelAll") for (const child of Object.values(root.branches)) { const found = findStep(child, id); if (found) return found; }
  else if (root.kind === "choice") {
    if ("kind" in root.decision && root.decision.kind === "task" && root.decision.id === id) return root.decision;
    for (const child of Object.values(root.branches)) { const found = findStep(child, id); if (found) return found; }
  } else if (root.kind === "dynamicExpand") return root.planner.id === id ? root.planner : undefined;
  return undefined;
}

export function definitionWithoutHash(definition: WorkDefinition): JsonValue { const copy = { ...definition }; delete copy.definitionHash; return copy as unknown as JsonValue; }
export function definitionCanonicalJson(definition: WorkDefinition): string { return canonicalJson(definitionWithoutHash(definition)); }
