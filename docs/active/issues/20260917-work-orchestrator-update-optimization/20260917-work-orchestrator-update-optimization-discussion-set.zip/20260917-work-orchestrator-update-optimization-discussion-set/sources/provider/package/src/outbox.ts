import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { basename, join } from "node:path";
import { ArtifactStore } from "./artifact-store.js";
import { readDirectoryManifest, materializeArtifact } from "./artifact.js";
import { canonicalJson, sha256 } from "./canonical.js";
import { DomainError, type ArtifactVersionRuntime, type RuntimeState } from "./contracts.js";
import type { WorkspacePaths } from "./workspace.js";

export const OUTBOX_MARKER_DIRECTORY = ".work-orchestrator-managed";
export const OUTBOX_CONFLICT_DIRECTORY = ".conflicts";

export interface OutboxEntry {
  artifactVersionId: string;
  blobHash: string;
  artifactKind: "file" | "directory";
  relativePath: string;
  path: string;
}

export interface OutboxReconcileResult {
  entries: OutboxEntry[];
  conflicts: string[];
  recreated: string[];
  preserved: string[];
}

function artifactFor(state: RuntimeState, artifactId: string): ArtifactVersionRuntime | undefined {
  const artifact = state.artifacts[artifactId];
  if (!artifact) return undefined;
  return { ...artifact, artifactKind: artifact.artifactKind ?? "file" };
}

function safeName(artifact: ArtifactVersionRuntime): string {
  const label = basename(artifact.logicalPath ?? "artifact").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "") || "artifact";
  return `${sha256(artifact.artifactVersionId).slice(0, 16)}-${label}`;
}

function markerPath(root: string, artifact: ArtifactVersionRuntime): string {
  return join(root, OUTBOX_MARKER_DIRECTORY, `${sha256(artifact.artifactVersionId)}.json`);
}

function outputPath(root: string, artifact: ArtifactVersionRuntime): string {
  return join(root, safeName(artifact));
}

function writeAtomic(path: string, value: unknown): void {
  const temporary = `${path}.tmp-${process.pid}`;
  writeFileSync(temporary, `${canonicalJson(value as never)}\n`, { flag: "w" });
  renameSync(temporary, path);
}

function fileMatches(store: ArtifactStore, artifact: ArtifactVersionRuntime, path: string): boolean {
  if (!existsSync(path)) return false;
  if (artifact.artifactKind === "file") {
    if (!statSync(path).isFile()) return false;
    const bytes = readFileSync(path);
    return bytes.byteLength === artifact.size && sha256(bytes) === artifact.blobHash;
  }
  if (!statSync(path).isDirectory()) return false;
  const manifest = readDirectoryManifest(store, artifact);
  const expected = new Set(manifest.files.map((file) => file.path));
  const actual: string[] = [];
  const visit = (current: string, prefix: string): void => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      const next = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) visit(join(current, entry.name), next);
      else if (entry.isFile()) actual.push(next);
      else actual.push(next);
    }
  };
  visit(path, "");
  if (actual.length !== expected.size || actual.some((item) => !expected.has(item))) return false;
  return manifest.files.every((file) => {
    const content = readFileSync(join(path, ...file.path.split("/")));
    return content.byteLength === file.size && sha256(content) === file.blobHash;
  });
}

function acceptedArtifacts(state: RuntimeState): ArtifactVersionRuntime[] {
  const ids: string[] = [];
  for (const task of Object.values(state.tasks)) if (task.state === "completed") for (const artifactId of task.acceptedOutputArtifactVersionIds) if (!ids.includes(artifactId)) ids.push(artifactId);
  return ids.map((id) => artifactFor(state, id)).filter((artifact): artifact is ArtifactVersionRuntime => Boolean(artifact));
}

export function getOutboxPlan(paths: WorkspacePaths, state: RuntimeState): OutboxEntry[] {
  return acceptedArtifacts(state).map((artifact) => ({ artifactVersionId: artifact.artifactVersionId, blobHash: artifact.blobHash, artifactKind: artifact.artifactKind, relativePath: safeName(artifact), path: outputPath(paths.outboxPath, artifact) }));
}

/** Reconcile only managed entries; user-created files are never removed. */
export function reconcileOutbox(paths: WorkspacePaths, state: RuntimeState, store: ArtifactStore): OutboxReconcileResult {
  mkdirSync(paths.outboxPath, { recursive: true });
  mkdirSync(join(paths.outboxPath, OUTBOX_MARKER_DIRECTORY), { recursive: true });
  const conflictRoot = join(paths.outboxPath, OUTBOX_CONFLICT_DIRECTORY);
  const desired = acceptedArtifacts(state);
  const conflicts: string[] = [];
  const recreated: string[] = [];
  const preserved: string[] = [];

  for (const marker of readdirSync(join(paths.outboxPath, OUTBOX_MARKER_DIRECTORY))) {
    const markerFile = join(paths.outboxPath, OUTBOX_MARKER_DIRECTORY, marker);
    let data: { artifactVersionId?: string; path?: string } = {};
    try { data = JSON.parse(readFileSync(markerFile, "utf8")) as typeof data; } catch { throw new DomainError("WORKSPACE_CORRUPT", `outbox marker is invalid: ${marker}`); }
    const artifact = desired.find((candidate) => candidate.artifactVersionId === data.artifactVersionId);
    if (artifact || !data.path) continue;
    const stalePath = join(paths.outboxPath, data.path);
    if (existsSync(stalePath)) {
      rmSync(stalePath, { recursive: true, force: true });
    }
    rmSync(markerFile, { force: true });
  }

  for (const artifact of desired) {
    const target = outputPath(paths.outboxPath, artifact);
    const marker = markerPath(paths.outboxPath, artifact);
    const managed = existsSync(marker);
    if (existsSync(target) && !fileMatches(store, artifact, target)) {
      mkdirSync(conflictRoot, { recursive: true });
      const conflict = join(conflictRoot, `${Date.now()}-${safeName(artifact)}`);
      renameSync(target, conflict);
      conflicts.push(conflict);
      preserved.push(conflict);
    }
    if (!existsSync(target)) {
      const temporary = join(paths.outboxPath, `.${safeName(artifact)}.tmp-${process.pid}`);
      rmSync(temporary, { recursive: true, force: true });
      materializeArtifact(store, artifact, temporary);
      renameSync(temporary, target);
      recreated.push(target);
    } else if (managed) {
      // Existing matching managed output is already canonical.
    }
    writeAtomic(marker, { formatVersion: 1, artifactVersionId: artifact.artifactVersionId, blobHash: artifact.blobHash, artifactKind: artifact.artifactKind, path: safeName(artifact) });
  }
  return { entries: getOutboxPlan(paths, state), conflicts, recreated, preserved };
}
