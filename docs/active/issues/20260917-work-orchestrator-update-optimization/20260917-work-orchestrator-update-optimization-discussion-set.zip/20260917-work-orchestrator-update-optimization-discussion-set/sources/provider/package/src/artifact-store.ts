import { randomUUID } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sha256 } from "./canonical.js";
import { DomainError } from "./contracts.js";

export const ARTIFACT_STORE_FORMAT_VERSION = 1;
export const ARTIFACT_STORE_MARKER = ".work-orchestrator-artifact-store.json";

export interface StagedBlob {
  stageId: string;
  blobHash: string;
  size: number;
  mediaType: string;
  temporaryPath: string;
}

export interface ArtifactStoreMarker {
  formatVersion: 1;
  storeId: string;
  workspaceId?: string;
}

/** content-addressed immutable blob store。ArtifactVersion の来歴は Registry が保持する。 */
export class ArtifactStore {
  readonly root: string;
  private readonly orphaned = new Map<string, number>();

  /**
   * The constructor remains a compatibility convenience for the v1 package. New
   * persistent callers should use initialize/open so runtime code cannot create
   * storage accidentally.
   */
  constructor(root = join(tmpdir(), `work-orchestrator-artifacts-${randomUUID()}`), options: { create?: boolean } = {}) {
    this.root = root;
    if (options.create === false) {
      this.validateOpen();
      return;
    }
    this.initializeStructure();
  }

  static initialize(root: string): ArtifactStore {
    return new ArtifactStore(root, { create: true });
  }

  static open(root: string): ArtifactStore {
    return new ArtifactStore(root, { create: false });
  }

  static temporary(): ArtifactStore {
    return ArtifactStore.initialize(join(tmpdir(), `work-orchestrator-artifacts-${randomUUID()}`));
  }

  bindWorkspaceId(workspaceId: string): void {
    const marker = this.readMarker();
    if (marker.workspaceId && marker.workspaceId !== workspaceId) throw new DomainError("ARTIFACT_STORE_CORRUPT", "ArtifactStore belongs to a different Workspace");
    writeFileSync(join(this.root, ARTIFACT_STORE_MARKER), `${JSON.stringify({ ...marker, workspaceId })}\n`, { flag: "w" });
  }

  getWorkspaceId(): string | undefined {
    return this.readMarker().workspaceId;
  }

  private initializeStructure(): void {
    mkdirSync(this.root, { recursive: true });
    const markerPath = join(this.root, ARTIFACT_STORE_MARKER);
    if (existsSync(markerPath)) {
      this.readMarker();
    } else {
      const entries = readdirSync(this.root);
      const nonPristine = entries.some((entry) => {
        if (entry === "blobs" || entry === "staging") return readdirSync(join(this.root, entry)).length > 0;
        return true;
      });
      if (nonPristine) throw new DomainError("ARTIFACT_STORE_CORRUPT", "cannot initialize an unmarked data-bearing ArtifactStore");
      writeFileSync(markerPath, JSON.stringify({ formatVersion: ARTIFACT_STORE_FORMAT_VERSION, storeId: randomUUID() }) + "\n", { flag: "wx" });
    }
    mkdirSync(join(this.root, "blobs"), { recursive: true });
    mkdirSync(join(this.root, "staging"), { recursive: true });
  }

  private readMarker(): ArtifactStoreMarker {
    const markerPath = join(this.root, ARTIFACT_STORE_MARKER);
    let marker: unknown;
    try {
      marker = JSON.parse(readFileSync(markerPath, "utf8"));
    } catch (error) {
      throw new DomainError("ARTIFACT_STORE_CORRUPT", `ArtifactStore marker is invalid: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!marker || typeof marker !== "object" || (marker as { formatVersion?: unknown }).formatVersion !== ARTIFACT_STORE_FORMAT_VERSION || typeof (marker as { storeId?: unknown }).storeId !== "string" || ((marker as { workspaceId?: unknown }).workspaceId !== undefined && typeof (marker as { workspaceId?: unknown }).workspaceId !== "string")) {
      const version = marker && typeof marker === "object" ? (marker as { formatVersion?: unknown }).formatVersion : undefined;
      if (typeof version === "number" && version > ARTIFACT_STORE_FORMAT_VERSION) throw new DomainError("FUTURE_FORMAT", `ArtifactStore format ${version} is newer than supported`);
      throw new DomainError("ARTIFACT_STORE_CORRUPT", "ArtifactStore marker has an unsupported shape");
    }
    return marker as ArtifactStoreMarker;
  }

  private validateOpen(): void {
    if (!existsSync(this.root)) throw new DomainError("ARTIFACT_STORE_CORRUPT", `ArtifactStore does not exist: ${this.root}`);
    this.readMarker();
    const blobsPath = join(this.root, "blobs");
    if (!existsSync(blobsPath) || !statSync(blobsPath).isDirectory()) throw new DomainError("ARTIFACT_STORE_CORRUPT", "ArtifactStore blobs directory is missing");
    // staging is temporary state and may be safely recreated after a crash.
    mkdirSync(join(this.root, "staging"), { recursive: true });
  }

  stage(content: string | Uint8Array, mediaType = "application/octet-stream"): StagedBlob {
    const bytes = typeof content === "string" ? Buffer.from(content) : Buffer.from(content);
    const blobHash = sha256(bytes);
    const stageId = randomUUID();
    const temporaryPath = join(this.root, "staging", stageId);
    writeFileSync(temporaryPath, bytes, { flag: "wx" });
    const fd = openSync(temporaryPath, "r");
    try {
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    this.orphaned.set(temporaryPath, Date.now());
    return { stageId, blobHash, size: bytes.byteLength, mediaType: mediaType || "application/octet-stream", temporaryPath };
  }

  finalize(stage: StagedBlob): void {
    if (!existsSync(stage.temporaryPath)) throw new DomainError("ARTIFACT_NOT_FOUND", `staged blob ${stage.stageId} not found`);
    const content = readFileSync(stage.temporaryPath);
    if (sha256(content) !== stage.blobHash || content.byteLength !== stage.size) throw new DomainError("INVARIANT_VIOLATION", "staged blob digest or size mismatch");
    const target = this.blobPath(stage.blobHash);
    if (existsSync(target)) {
      const existing = readFileSync(target);
      if (existing.byteLength !== stage.size || sha256(existing) !== stage.blobHash) throw new DomainError("ARTIFACT_STORE_CORRUPT", `existing blob ${stage.blobHash} failed verification`);
      unlinkSync(stage.temporaryPath);
    } else {
      renameSync(stage.temporaryPath, target);
    }
    this.orphaned.delete(stage.temporaryPath);
  }

  hasBlob(blobHash: string): boolean {
    return existsSync(this.blobPath(blobHash));
  }

  read(blobHash: string): Buffer {
    if (!this.hasBlob(blobHash)) throw new DomainError("ARTIFACT_NOT_FOUND", `blob ${blobHash} not found`);
    const content = readFileSync(this.blobPath(blobHash));
    if (sha256(content) !== blobHash) throw new DomainError("ARTIFACT_STORE_CORRUPT", `blob ${blobHash} failed verification`);
    return content;
  }

  gcOrphans(gracePeriodMs = 60 * 60 * 1000, now = Date.now()): string[] {
    const removed: string[] = [];
    for (const path of readdirSync(join(this.root, "staging"))) {
      const fullPath = join(this.root, "staging", path);
      const age = this.orphaned.get(fullPath) ?? statSync(fullPath).mtimeMs;
      if (now - age >= gracePeriodMs) {
        unlinkSync(fullPath);
        this.orphaned.delete(fullPath);
        removed.push(fullPath);
      }
    }
    return removed;
  }

  blobPath(blobHash: string): string {
    if (!/^[a-f0-9]{64}$/.test(blobHash)) throw new DomainError("ARTIFACT_NOT_FOUND", "invalid blob hash");
    return join(this.root, "blobs", blobHash);
  }
}
