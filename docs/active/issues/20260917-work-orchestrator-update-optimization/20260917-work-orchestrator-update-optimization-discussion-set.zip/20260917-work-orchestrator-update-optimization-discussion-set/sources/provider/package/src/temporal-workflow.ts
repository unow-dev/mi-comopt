import {
  ActivityCancellationType,
  CancellationScope,
  CancelledFailure,
  condition,
  continueAsNew,
  defineQuery,
  defineUpdate,
  proxyActivities,
  setHandler,
  sleep,
  workflowInfo,
} from "@temporalio/workflow";
import type { JsonValue, RuntimeState, RuntimeIntent, AgentRunRequest, AgentRunResult, ActorRef, CommandEnvelope, DomainCommand } from "./contracts.js";
import type {
  CancelSessionUpdateInput,
  ClaimTaskUpdateInput,
  CompleteHumanTaskUpdateInput,
  ReceiveExternalEventUpdateInput,
  ReleaseTaskUpdateInput,
  ResumeAgentTaskUpdateInput,
  TemporalActivities,
  TemporalCommitResult,
  TemporalWorkflowInput,
  TemporalWorkflowResult,
} from "./temporal-contracts.js";

/** v1 の公開 Update 名。Signal は通常の外部イベント入口として使わない。 */
export const claimTaskUpdate = defineUpdate<JsonValue, [ClaimTaskUpdateInput], "claimTask">("claimTask");
export const releaseTaskUpdate = defineUpdate<JsonValue, [ReleaseTaskUpdateInput], "releaseTask">("releaseTask");
export const completeHumanTaskUpdate = defineUpdate<JsonValue, [CompleteHumanTaskUpdateInput], "completeHumanTask">("completeHumanTask");
export const resumeAgentTaskUpdate = defineUpdate<JsonValue, [ResumeAgentTaskUpdateInput], "resumeAgentTask">("resumeAgentTask");
export const cancelSessionUpdate = defineUpdate<JsonValue, [CancelSessionUpdateInput], "cancelSession">("cancelSession");
export const receiveExternalEventUpdate = defineUpdate<JsonValue, [ReceiveExternalEventUpdateInput], "receiveExternalEvent">("receiveExternalEvent");
export const runtimeStateQuery = defineQuery<RuntimeState | undefined, []>("runtimeState");

const REGISTRY_ACTIVITY_OPTIONS = {
  scheduleToStartTimeout: "30 seconds",
  startToCloseTimeout: "30 seconds",
  retry: { maximumAttempts: 3 },
  cancellationType: ActivityCancellationType.WAIT_CANCELLATION_COMPLETED,
} as const;

const DEFAULT_AGENT_SCHEDULE_TO_START_MS = 30_000;
const DEFAULT_AGENT_HEARTBEAT_TIMEOUT_MS = 10_000;

function isTerminal(state: RuntimeState | undefined): boolean {
  return state?.session.state === "completed" || state?.session.state === "cancelled";
}

function isCancellationFailure(error: unknown): boolean {
  if (error instanceof CancelledFailure) return true;
  if (error instanceof Error && "cause" in error) return isCancellationFailure((error as Error & { cause?: unknown }).cause);
  return false;
}

function asFailure(error: unknown): JsonValue {
  return error instanceof Error ? error.message : "Temporal Agent Activity failed";
}

function isAdvancedResponse(response: JsonValue): boolean {
  return typeof response === "object" && response !== null && !Array.isArray(response) && response.advanced === true;
}

function updateCommandId(sessionId: string, name: string, suffix: string, requested?: string): string {
  return requested ?? `update:${name}:${sessionId}:${suffix}`;
}

/**
 * 1 Session を 1 Workflow ID に対応させる実 Temporal Workflow。
 *
 * Domain の永続化は Registry Activity に集約し、Update・Activity 結果・timer
 * firing は commandTail を通る。このため Update handler が async でも同時に
 * Registry を更新する経路は存在しない。
 */
export async function workSessionWorkflow(input: TemporalWorkflowInput): Promise<TemporalWorkflowResult> {
  const info = workflowInfo();
  if (info.workflowId !== input.sessionId) throw new Error("Workflow ID must equal sessionId");
  const workflowTaskQueue = info.taskQueue;
  const agentScheduleToStartTimeoutMs = input.agentScheduleToStartTimeoutMs ?? DEFAULT_AGENT_SCHEDULE_TO_START_MS;
  if (!Number.isFinite(agentScheduleToStartTimeoutMs) || agentScheduleToStartTimeoutMs <= 0) {
    throw new Error("agentScheduleToStartTimeoutMs must be a positive finite number");
  }
  const registryActivities = proxyActivities<Pick<TemporalActivities, "initializeSession" | "commitCommand" | "commitAgentResult">>({
    ...REGISTRY_ACTIVITY_OPTIONS,
    taskQueue: input.registryTaskQueue ?? input.agentTaskQueue ?? workflowTaskQueue,
  });
  const agentActivities = proxyActivities<Pick<TemporalActivities, "runAgent" | "cancelAgent">>({
    taskQueue: input.agentTaskQueue ?? input.registryTaskQueue ?? workflowTaskQueue,
    scheduleToStartTimeout: agentScheduleToStartTimeoutMs,
    startToCloseTimeout: "30 seconds",
    heartbeatTimeout: DEFAULT_AGENT_HEARTBEAT_TIMEOUT_MS,
    retry: { maximumAttempts: 1 },
    cancellationType: ActivityCancellationType.TRY_CANCEL,
  });

  let state: RuntimeState | undefined = input.carriedState;
  let commandQueueDepth = 0;
  let registryCommitInFlight = 0;
  let mutationHandlerInProgress = 0;
  let timerTransitionInProgress = 0;
  const agentScopes = new Map<string, CancellationScope>();
  const cancellationRequests = new Set<string>();
  const timerPromises = new Map<string, Promise<void>>();
  let commandTail: Promise<void> = Promise.resolve();

  const initialized = input.carriedState
    ? Promise.resolve<TemporalCommitResult>({
        response: { sessionId: input.sessionId, state: input.carriedState.session.state, revision: input.carriedState.revision },
        state: input.carriedState,
        intents: [],
        accepted: true,
        duplicate: true,
      })
    : registryActivities.initializeSession({
        sessionId: input.sessionId,
        workDefinitionId: input.workDefinitionId,
        revision: input.revision ?? 0,
        input: input.input ?? null,
        actor: input.actor ?? { actorId: "system", actorType: "system" },
        inputArtifacts: input.inputArtifacts,
        bootstrapManifest: input.bootstrapManifest,
      });

  async function commitAndExecute(result: TemporalCommitResult): Promise<void> {
    state = result.state;
    if (!result.duplicate) await executeIntents(result.intents);
  }

  async function drainAdvance(): Promise<void> {
    for (let count = 0; count < 10_000; count += 1) {
      const current = state;
      if (!current || isTerminal(current)) return;
      const envelope: CommandEnvelope = {
        schemaVersion: 1,
        sessionId: input.sessionId,
        commandId: `internal:advance:${current.revision + 1}`,
        actor: { actorId: "runtime", actorType: "runtime" },
        command: { type: "advance" },
      };
      registryCommitInFlight += 1;
      let result: TemporalCommitResult;
      try {
        result = await registryActivities.commitCommand({ state: current, envelope });
      } finally {
        registryCommitInFlight -= 1;
      }
      await commitAndExecute(result);
      if (!isAdvancedResponse(result.response)) return;
    }
    throw new Error("workflow drive exceeded its progress limit");
  }

  async function processCommand(envelope: CommandEnvelope, agentResult?: { executionId: string; result: AgentRunResult }): Promise<JsonValue> {
    const current = state;
    if (!current) throw new Error("Session has not been initialized");
    mutationHandlerInProgress += 1;
    try {
      registryCommitInFlight += 1;
      let result: TemporalCommitResult;
      try {
        result = agentResult
          ? await registryActivities.commitAgentResult({
              state: current,
              sessionId: input.sessionId,
              executionId: agentResult.executionId,
              result: agentResult.result,
              commandId: envelope.commandId,
              actor: envelope.actor,
            })
          : await registryActivities.commitCommand({ state: current, envelope });
      } finally {
        registryCommitInFlight -= 1;
      }
      await commitAndExecute(result);
      await drainAdvance();
      return result.response;
    } finally {
      mutationHandlerInProgress -= 1;
    }
  }

  function submit(envelope: CommandEnvelope, agentResult?: { executionId: string; result: AgentRunResult }): Promise<JsonValue> {
    commandQueueDepth += 1;
    const result = commandTail.then(
      () => processCommand(envelope, agentResult),
      () => processCommand(envelope, agentResult),
    );
    commandTail = result.then(() => undefined, () => undefined);
    return result.finally(() => {
      commandQueueDepth -= 1;
    });
  }

  function submitAgentResult(executionId: string, result: AgentRunResult): void {
    const commandId = `internal:agentResult:${executionId}`;
    void submit(
      {
        schemaVersion: 1,
        sessionId: input.sessionId,
        commandId,
        actor: { actorId: "runtime", actorType: "runtime" },
        command: { type: "agentResult", executionId, status: result.status, outcome: result.outcome, result: result.result, failure: result.failure },
      },
      { executionId, result },
    ).catch(() => undefined);
  }

  function scheduleTimer(intent: Extract<RuntimeIntent, { kind: "scheduleTimer" }>): void {
    if (timerPromises.has(intent.waitId)) return;
    const timer = sleep(intent.delayMs).then(async () => {
      timerTransitionInProgress += 1;
      try {
        await submit({
          schemaVersion: 1,
          sessionId: input.sessionId,
          commandId: `timer:${intent.waitId}`,
          actor: { actorId: "temporal", actorType: "temporal" },
          command: { type: "timerFired", waitId: intent.waitId },
        });
      } finally {
        timerTransitionInProgress -= 1;
        timerPromises.delete(intent.waitId);
      }
    }).catch(() => undefined);
    timerPromises.set(intent.waitId, timer);
  }

  function executeAgent(intent: Extract<RuntimeIntent, { kind: "dispatchAgent" }>): void {
    const current = state;
    const execution = current?.executions[intent.executionId];
    const task = execution && current?.tasks[execution.taskId];
    if (!current || !execution || !task || execution.state !== "running" || !execution.grant) return;
    const request: AgentRunRequest = { session: { sessionId: current.session.sessionId, workDefinitionId: current.session.workDefinitionId, definitionRevision: current.session.definitionRevision }, task, execution, grant: execution.grant };
    const scope = new CancellationScope();
    agentScopes.set(intent.executionId, scope);
    const activity = scope.run(async () => {
      try {
        return await agentActivities.runAgent.executeWithOptions({
          scheduleToStartTimeout: agentScheduleToStartTimeoutMs,
          startToCloseTimeout: task.contract.budgets?.maxWallTimeMs ?? 30_000,
          heartbeatTimeout: Math.min(DEFAULT_AGENT_HEARTBEAT_TIMEOUT_MS, Math.max(1_000, task.contract.budgets?.maxWallTimeMs ?? 30_000)),
          retry: { maximumAttempts: 1 },
          cancellationType: ActivityCancellationType.TRY_CANCEL,
        }, [request]);
      } catch (error) {
        return {
          status: isCancellationFailure(error) ? "abandoned" : "failed",
          failure: asFailure(error),
        } satisfies AgentRunResult;
      }
    });
    void activity.then(
      (result) => {
        agentScopes.delete(intent.executionId);
        if (cancellationRequests.delete(intent.executionId)) return;
        submitAgentResult(intent.executionId, result);
      },
      (error) => {
        agentScopes.delete(intent.executionId);
        if (cancellationRequests.delete(intent.executionId)) return;
        submitAgentResult(intent.executionId, { status: isCancellationFailure(error) ? "abandoned" : "failed", failure: asFailure(error) });
      },
    );
  }

  async function executeIntents(intents: RuntimeIntent[]): Promise<void> {
    for (const intent of intents) {
      if (intent.kind === "scheduleTimer") scheduleTimer(intent);
      if (intent.kind === "dispatchAgent") executeAgent(intent);
      if (intent.kind === "cancelAgent") {
        cancellationRequests.add(intent.executionId);
        const scope = agentScopes.get(intent.executionId);
        let confirmed = false;
        try {
          confirmed = (await agentActivities.cancelAgent.executeWithOptions({
            scheduleToStartTimeout: agentScheduleToStartTimeoutMs,
            startToCloseTimeout: "30 seconds",
            retry: { maximumAttempts: 1 },
            cancellationType: ActivityCancellationType.WAIT_CANCELLATION_COMPLETED,
          }, [intent.executionId])).confirmed;
        } catch {
          confirmed = false;
        }
        // Adapter が graceful termination を確認できた場合は、Activity 自身の
        // cancellationSignal 処理で正常終了させる。既に終了した Activity に
        // Temporal cancellation command を重ねると ACTIVITY_UNKNOWN になり得る。
        if (!confirmed) scope?.cancel();
        submitAgentResult(intent.executionId, { status: confirmed ? "cancelled" : "abandoned", failure: confirmed ? undefined : "cancellation could not be confirmed" });
        if (!scope) cancellationRequests.delete(intent.executionId);
      }
    }
  }

  function publicCommandId(name: string, suffix: string, requested: string | undefined): string {
    return updateCommandId(input.sessionId, name, suffix, requested);
  }

  setHandler(claimTaskUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("claimTask", value.taskId, value.commandId),
    actor: value.actor,
    command: { type: "claimTask", taskId: value.taskId },
  }));
  setHandler(releaseTaskUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("releaseTask", value.taskId, value.commandId),
    actor: value.actor,
    command: { type: "releaseTask", taskId: value.taskId },
  }));
  setHandler(completeHumanTaskUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("completeHumanTask", value.taskId, value.commandId),
    actor: value.actor,
    command: { type: "completeHumanTask", taskId: value.taskId, outcome: value.outcome, result: value.result, comment: value.comment, artifactVersions: value.artifactVersions },
  }));
  setHandler(resumeAgentTaskUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("resumeAgentTask", value.taskId, value.commandId),
    actor: value.actor,
    command: { type: "resumeAgentTask", taskId: value.taskId },
  }));
  setHandler(cancelSessionUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("cancelSession", "session", value.commandId),
    actor: value.actor,
    command: { type: "cancelSession", reason: value.reason },
  }));
  setHandler(receiveExternalEventUpdate, (value) => submit({
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: publicCommandId("receiveExternalEvent", value.event.eventId, value.commandId),
    actor: value.actor,
    command: { type: "receiveExternalEvent", event: value.event },
  }));
  setHandler(runtimeStateQuery, () => state);

  const initial = await initialized;
  state = initial.state;
  await commitAndExecute(initial);
  await drainAdvance();

  while (!isTerminal(state)) {
    await condition(() => isTerminal(state) || (workflowInfo().continueAsNewSuggested && commandQueueDepth === 0 && registryCommitInFlight === 0 && agentScopes.size === 0 && mutationHandlerInProgress === 0 && timerTransitionInProgress === 0 && timerPromises.size === 0));
    if (isTerminal(state)) break;
    if (workflowInfo().continueAsNewSuggested) {
      const carriedState = state;
      if (!carriedState) throw new Error("Cannot continue without RuntimeState");
      return continueAsNew<typeof workSessionWorkflow>({
        ...input,
        carriedState,
        executionChainNumber: (input.executionChainNumber ?? 0) + 1,
      });
    }
  }

  const finalState = state;
  if (!finalState) throw new Error("Workflow completed without RuntimeState");
  return {
    sessionId: input.sessionId,
    revision: finalState.revision,
    state: finalState.session.state,
    workflowId: workflowInfo().workflowId,
    runId: workflowInfo().runId,
  };
}
