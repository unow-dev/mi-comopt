# Source audit and known drift

This file records implementation facts verified against the source snapshot used for the handoff. It is not a substitute for reading the source while editing.

## Snapshot identity

Archive SHA-256:

`267433bd750d06e89e93f389f9c9843e4f3cf832712590055b054628f26e9e23`

## Package distribution

Current `package/package.json`:

```json
"files": [
  "dist",
  "README.md"
]
```

Therefore package-relative links to `./docs/README.md` and `./docs/API_REFERENCE.md` do not survive packaging unless `docs` is added.

## CLI parser behavior

`runCli(argv, io)` currently performs:

```ts
const command = argv[0] && !argv[0].startsWith("-") ? argv[0] : undefined;
const args = command ? argv.slice(1) : argv;
```

It then parses `--workspace` from `args`.

Consequences:

- `work-orchestrator init ./ws` works: `init` is command, `./ws` becomes workspace path.
- `work-orchestrator worker ./ws` works: `worker` is command, `./ws` becomes workspace path.
- `work-orchestrator --workspace ./ws --actor alice` works in interactive mode.
- `work-orchestrator ./ws --actor alice` does **not** select `./ws` as interactive Workspace; `./ws` is consumed as the command token.

The package documentation must not claim otherwise.

## Interactive `new` flow

The CLI `new` flow reads definitions already stored in the Registry, asks the user to choose one, collects optional filesystem input paths, creates a UUID-based Session ID, and calls `startSessionFromWorkspace()`.

It does not author/register a new WorkDefinition.

## Current `StartSessionInput`

Verified source shape:

```ts
export interface StartSessionInput {
  sessionId: string;
  workDefinitionId?: string;
  revision?: number;
  input?: JsonValue;
  actor?: ActorRef;
  commandId?: string;
  definition?: WorkDefinition;
  inputArtifacts?: import("./contracts.js").ArtifactVersionRuntime[];
  bootstrapManifest?: { artifactVersionId: string; blobHash: string };
}
```

The current API reference is incomplete and its revision-default wording is stale.

## Current `OrchestratorOptions`

Verified source shape:

```ts
export interface OrchestratorOptions {
  registry?: Registry;
  artifactStore?: ArtifactStore;
  workers?: WorkerProfile[];
  agentAdapter?: AgentAdapter;
  workspace?: OpenWorkspace;
}
```

The constructor does not treat `workspace` as an instruction to automatically replace `registry` and `artifactStore`. Workspace-backed documentation therefore passes all three explicitly.

## Root export modules

`src/index.ts` currently re-exports:

- `contracts`
- `canonical`
- `validation`
- `machines`
- `artifact-store`
- `artifact`
- `workspace`
- `registry`
- `domain`
- `runtime`
- `temporal-contracts`
- `temporal-workflow`
- `temporal-activities`
- `temporal-worker`
- `temporal-client`
- `outbox`
- `cli`

and directly exports compatibility helper `hello()`.

## Known names missing from the current API reference

A mechanical comparison of source exported declarations against names present in the current `API_REFERENCE.md` identified these currently missing names. Recheck after edits; do not blindly copy this list if source changes before implementation.

### contracts

- `NoopStep`

### artifact-store

- `ARTIFACT_STORE_FORMAT_VERSION`
- `ARTIFACT_STORE_MARKER`
- `ArtifactStoreMarker`

### artifact

- `DirectoryArtifactManifestV1`
- `SnapshotOptions`
- `SnapshotResult`
- `mediaTypeForPath`
- `validateRelativeArtifactPath`
- `validateDirectoryManifest`
- `snapshotPath`
- `snapshotOutputDirectory`
- `readDirectoryManifest`
- `materializeArtifact`

### workspace

- `WORKSPACE_FORMAT_VERSION`
- `WORKSPACE_STATE_PATH`
- `WORKSPACE_REGISTRY_PATH`
- `WORKSPACE_ARTIFACTS_PATH`
- `WorkspaceConfig`
- `WorkspaceState`
- `WorkspacePaths`
- `OpenWorkspace`
- `InitWorkspaceResult`
- `workspacePaths`
- `initWorkspace`
- `openWorkspace`
- `findWorkspace`
- `resolveWorkspace`
- `safeWorkspaceKey`
- `ExecutionWorkspace`
- `executionWorkspace`
- `prepareExecutionWorkspace`

### registry

- `InitialSessionOptions`
- `RegistryPage`
- `REGISTRY_APPLICATION_ID`
- `REGISTRY_SCHEMA_VERSION`
- `RegistryReader`

### runtime

- top-level `deliverExternalEvent`

### outbox

- `OUTBOX_MARKER_DIRECTORY`
- `OUTBOX_CONFLICT_DIRECTORY`
- `OutboxEntry`
- `OutboxReconcileResult`
- `getOutboxPlan`
- `reconcileOutbox`

### cli

- `CliIO`
- `createReadlineIO`
- `InteractiveCliOptions`
- `CliOrchestrator`
- `TemporalCliOrchestrator`
- `runInteractiveCli`
- `runCli`

## Persistence lifecycle

The code exposes explicit initialization/open lifecycle APIs for Registry and ArtifactStore. Documentation should distinguish creation/initialization from opening existing authority and should use Workspace lifecycle APIs for the normal integrated path.

## Quickstart rerun safety

A fixed Session ID is inappropriate for the canonical persistent Quickstart because a second run against the same Workspace can collide with the prior Session. Use a unique ID via `randomUUID()`.

A fixed WorkDefinition ID/revision is acceptable if the documented definition body is unchanged and the Registry registration semantics accept the identical definition; the Session ID is the important value to make unique in the user walkthrough.
