# Acceptance checklist

The issue is complete only when all applicable checks below pass.

## Documentation structure

- [x] `package/README.md` presents Workspace-first as the normal persistent path.
- [x] `package/README.md` does not duplicate the full canonical Quickstart.
- [x] `package/README.md` links to `./docs/README.md` and `./docs/API_REFERENCE.md`.
- [x] package-consumer CLI examples use `npx work-orchestrator ...`, not repository-only `npm run cli -- ...` as the normal usage form.
- [x] interactive explicit Workspace selection uses `--workspace`.
- [x] no surviving documentation claims that `work-orchestrator [workspace]` is the interactive Workspace syntax.
- [x] the docs state that interactive `new` operates on already registered WorkDefinitions.

## Canonical Quickstart

- [x] main Quickstart uses a Workspace created by `work-orchestrator init` (or explicitly documents equivalent `initWorkspace()`).
- [x] Quickstart calls `openWorkspace()`.
- [x] `WorkOrchestrator` receives `registry`, `artifactStore`, and `workspace` explicitly.
- [x] Quickstart registers a schema v2 single Human Task definition.
- [x] Quickstart uses a unique Session ID, e.g. `quickstart-${randomUUID()}`.
- [x] Quickstart calls `startSession()`.
- [x] Quickstart reads the Session view and locates the Human Task.
- [x] Quickstart claims and completes the Human Task.
- [x] Quickstart checks final Session state is `completed`.
- [x] Quickstart closes the Workspace Registry in `finally`.
- [x] `startSessionFromWorkspace()` is documented separately for filesystem-input snapshotting.
- [x] in-memory usage is clearly secondary.

## API reference accuracy

- [x] `OrchestratorOptions.workspace` is documented.
- [x] examples do not imply `workspace` automatically wires Registry/ArtifactStore.
- [x] `StartSessionInput` matches source, including optional `workDefinitionId`, `commandId`, inline `definition`, `inputArtifacts`, and `bootstrapManifest`.
- [x] omitted `revision` is not documented as `0`.
- [x] registered-definition revision selection is described as latest/highest revision when omitted.
- [x] Workspace public APIs are documented.
- [x] `startSessionFromWorkspace()` is documented.
- [x] `completeHumanTaskWithInput()` is documented.
- [x] `openHumanTaskWorkspace()` is documented.
- [x] `completeHumanTaskFromWorkspace()` is documented.
- [x] `deliverExternalEvent()` coverage matches the public API(s).
- [x] persistence lifecycle language matches `initialize()` / `open()` semantics.
- [x] Temporal path-based storage is described as opening initialized authorities, not initializing them.
- [x] “Complete root export index” has been re-audited against every module re-exported by `src/index.ts`.
- [x] compatibility helper `hello()` remains accounted for if the index promises complete root exports.

## Packaging

- [x] `package/package.json#files` contains `docs`.
- [x] package-distribution regression test is added using existing `node:test` infrastructure.
- [x] regression test asserts `README.md` is packed.
- [x] regression test asserts `docs/README.md` is packed.
- [x] regression test asserts `docs/API_REFERENCE.md` is packed.
- [x] regression test asserts key built `dist` files are packed (`dist/index.js`, `dist/index.d.ts`, `dist/cli-entry.js` at minimum).

## Automated verification

- [x] existing build succeeds.
- [x] `npm test` succeeds.
- [x] `npm pack --dry-run --json` succeeds.
- [x] dry-run package listing contains the required docs and built entry points.

## Packed-consumer verification

Use an empty temporary directory and the generated tarball rather than importing directly from the source tree.

- [x] tarball installs successfully into an empty consumer.
- [x] installed package contains the version-matched docs.
- [x] `npx work-orchestrator init .` succeeds.
- [x] canonical Quickstart imports from installed `work-orchestrator` package.
- [x] Definition registration succeeds.
- [x] Session starts successfully.
- [x] Human Task is claimable/completable.
- [x] final Session state is `completed`.
- [x] rerunning the Quickstart does not fail due to Session ID reuse.

## Scope guard

- [x] no runtime behavior was changed to satisfy documentation.
- [x] no new CLI command was added.
- [x] no positional interactive Workspace support was added.
- [x] no Definition-registration CLI was added.
- [x] no automatic Registry/ArtifactStore wiring from `workspace` was added.
- [x] no migration change was added.
- [x] no new docs generator/export-index generator was introduced.
- [x] docs, manifest, and distribution regression test land in the same PR.
