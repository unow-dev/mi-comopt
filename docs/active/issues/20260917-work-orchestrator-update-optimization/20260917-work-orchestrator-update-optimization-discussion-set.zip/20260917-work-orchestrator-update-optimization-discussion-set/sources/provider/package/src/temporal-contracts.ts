import type {
  ActorRef,
  AgentRunRequest,
  AgentRunResult,
  CommandEnvelope,
  DomainCommand,
  JsonValue,
  RuntimeIntent,
  RuntimeState,
  WorkerProfile,
} from "./contracts.js";

/** Temporal Workflow の開始引数。Workflow ID は sessionId と同じ値を使う。 */
export interface TemporalWorkflowInput {
  sessionId: string;
  workDefinitionId: string;
  revision?: number;
  input?: JsonValue;
  actor?: ActorRef;
  registryTaskQueue?: string;
  agentTaskQueue?: string;
  /** Agent Activity の schedule-to-start timeout。未指定時は 30 秒。 */
  agentScheduleToStartTimeoutMs?: number;
  carriedState?: RuntimeState;
  executionChainNumber?: number;
  inputArtifacts?: import("./contracts.js").ArtifactVersionRuntime[];
  bootstrapManifest?: { artifactVersionId: string; blobHash: string };
}

export interface TemporalWorkflowResult {
  sessionId: string;
  revision: number;
  state: RuntimeState["session"]["state"];
  workflowId: string;
  runId: string;
}

export interface TemporalCommitInput {
  state: RuntimeState;
  envelope: CommandEnvelope;
}

export interface TemporalStartSessionInput {
  sessionId: string;
  workDefinitionId: string;
  revision: number;
  input: JsonValue;
  actor: ActorRef;
  inputArtifacts?: import("./contracts.js").ArtifactVersionRuntime[];
  bootstrapManifest?: { artifactVersionId: string; blobHash: string };
}

export interface TemporalAgentResultInput {
  state: RuntimeState;
  sessionId: string;
  executionId: string;
  result: AgentRunResult;
  commandId: string;
  actor: ActorRef;
}

export interface TemporalCommitResult {
  response: JsonValue;
  state: RuntimeState;
  intents: RuntimeIntent[];
  accepted: boolean;
  duplicate: boolean;
}

export interface TemporalActivities {
  initializeSession(input: TemporalStartSessionInput): Promise<TemporalCommitResult>;
  commitCommand(input: TemporalCommitInput): Promise<TemporalCommitResult>;
  commitAgentResult(input: TemporalAgentResultInput): Promise<TemporalCommitResult>;
  runAgent(request: AgentRunRequest): Promise<AgentRunResult>;
  cancelAgent(executionId: string): Promise<{ confirmed: boolean }>;
}

export interface TemporalWorkerRuntimeOptions {
  registryPath?: string;
  artifactRoot?: string;
  registry?: import("./registry.js").Registry;
  artifactStore?: import("./artifact-store.js").ArtifactStore;
  workers?: WorkerProfile[];
  agentAdapter?: import("./runtime.js").AgentAdapter;
  cancellationGraceMs?: number;
  heartbeatIntervalMs?: number;
}

export interface TemporalCommandUpdateInput {
  actor: ActorRef;
  commandId?: string;
}

export interface ClaimTaskUpdateInput extends TemporalCommandUpdateInput {
  taskId: string;
}

export interface ReleaseTaskUpdateInput extends TemporalCommandUpdateInput {
  taskId: string;
}

export interface CompleteHumanTaskUpdateInput extends TemporalCommandUpdateInput {
  taskId: string;
  outcome?: string;
  result?: JsonValue;
  comment?: string;
  artifactVersions?: import("./contracts.js").ArtifactVersionRuntime[];
}

export interface ResumeAgentTaskUpdateInput extends TemporalCommandUpdateInput {
  taskId: string;
}

export interface CancelSessionUpdateInput extends TemporalCommandUpdateInput {
  reason?: string;
}

export interface ReceiveExternalEventUpdateInput extends TemporalCommandUpdateInput {
  event: Extract<DomainCommand, { type: "receiveExternalEvent" }>["event"];
}

export type TemporalPublicUpdateInput =
  | ClaimTaskUpdateInput
  | ReleaseTaskUpdateInput
  | CompleteHumanTaskUpdateInput
  | ResumeAgentTaskUpdateInput
  | CancelSessionUpdateInput
  | ReceiveExternalEventUpdateInput;
