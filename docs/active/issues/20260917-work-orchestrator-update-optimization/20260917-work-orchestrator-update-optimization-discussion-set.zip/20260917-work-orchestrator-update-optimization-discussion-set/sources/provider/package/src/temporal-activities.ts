import { Context } from "@temporalio/activity";
import { canonicalJson, hashJson } from "./canonical.js";
import { ArtifactStore } from "./artifact-store.js";
import { createInitialRuntimeState, reduceCommand } from "./domain.js";
import {
  DomainError,
  type AgentRunRequest,
  type AgentRunResult,
  type ArtifactVersionRuntime,
  type CommandEnvelope,
  type JsonValue,
  type ReductionAccepted,
  type WorkerProfile,
} from "./contracts.js";
import { Registry } from "./registry.js";
import { FakeAgentAdapter, type AgentAdapter } from "./runtime.js";
import type {
  TemporalActivities,
  TemporalAgentResultInput,
  TemporalCommitInput,
  TemporalCommitResult,
  TemporalStartSessionInput,
  TemporalWorkerRuntimeOptions,
} from "./temporal-contracts.js";

export const TEMPORAL_ACTIVITY_DEFAULTS = {
  scheduleToStartTimeoutMs: 30_000,
  registryStartToCloseTimeoutMs: 30_000,
  heartbeatTimeoutMs: 10_000,
  retryMaximumAttempts: 1,
  cancellationGraceMs: 5_000,
} as const;

function responseForState(sessionId: string, state: { session: { state: string }; revision: number }): JsonValue {
  return { sessionId, state: state.session.state, revision: state.revision };
}

function rejectedResponse(error: unknown): JsonValue {
  if (error instanceof DomainError) return error.details === undefined
    ? { ok: false, error: { code: error.code, message: error.message } }
    : { ok: false, error: { code: error.code, message: error.message, details: error.details } };
  return { ok: false, error: { code: "INVARIANT_VIOLATION", message: error instanceof Error ? error.message : String(error) } };
}

function commitResult(input: TemporalCommitInput, reduction: Parameters<Registry["commit"]>[1], registry: Registry, requestHash: string): TemporalCommitResult {
  let result;
  try {
    result = registry.commit(input.envelope, reduction, requestHash);
  } catch (error) {
    if (error instanceof Error && error.message === "IDEMPOTENCY_KEY_CONFLICT") {
      const state = registry.getRuntimeState(input.envelope.sessionId) ?? input.state;
      return { response: rejectedResponse(new DomainError("IDEMPOTENCY_KEY_CONFLICT", error.message)), state, intents: [], accepted: false, duplicate: false };
    }
    throw error;
  }
  const persisted = registry.getRuntimeState(input.envelope.sessionId) ?? input.state;
  const accepted = reduction.kind === "accepted";
  return {
    response: result.response,
    state: persisted,
    intents: result.duplicate || reduction.kind === "rejected" ? [] : reduction.intents,
    accepted: result.duplicate ? (registry.getReceipt(input.envelope.sessionId, input.envelope.commandId)?.accepted ?? accepted) : accepted,
    duplicate: result.duplicate,
  };
}

function materializeArtifacts(result: AgentRunResult, executionId: string, artifactStore: ArtifactStore): { result: AgentRunResult; artifactVersions?: ArtifactVersionRuntime[] } {
  try {
    const artifactVersions = result.artifacts
      ?.filter((artifact) => result.status !== "abandoned" || artifact.reliableRunReport === true)
      .map((artifact, ordinal) => {
        const staged = artifactStore.stage(artifact.content, artifact.mediaType ?? "application/octet-stream");
        artifactStore.finalize(staged);
        return {
          artifactVersionId: `${executionId}:artifact:${ordinal}`,
          artifactKind: "file" as const,
          blobHash: staged.blobHash,
          size: staged.size,
          mediaType: staged.mediaType,
          origin: { kind: "execution", executionId } as const,
          immutable: true as const,
        };
      });
    return { result, artifactVersions };
  } catch (error) {
    return { result: { status: "failed", failure: error instanceof Error ? error.message : "ArtifactStore failed" } };
  }
}

function buildStartEnvelope(input: TemporalStartSessionInput): CommandEnvelope {
  return {
    schemaVersion: 1,
    sessionId: input.sessionId,
    commandId: `start:${input.sessionId}`,
    actor: input.actor,
    command: { type: "advance" },
  };
}

function initializeSession(input: TemporalStartSessionInput, registry: Registry, artifactStore: ArtifactStore): TemporalCommitResult {
  const envelope = buildStartEnvelope(input);
  const requestHash = hashJson({ envelope, workDefinitionId: input.workDefinitionId, revision: input.revision, input: input.input, inputArtifacts: input.inputArtifacts ?? [], bootstrapManifest: input.bootstrapManifest ?? null } as unknown as JsonValue);
  const existing = registry.getRuntimeState(input.sessionId);
  if (existing) {
    const receipt = registry.getReceipt(input.sessionId, envelope.commandId);
    if (receipt?.requestHash === requestHash) return { response: receipt.response, state: existing, intents: [], accepted: receipt.accepted, duplicate: true };
    if (receipt) return { response: rejectedResponse(new DomainError("IDEMPOTENCY_KEY_CONFLICT", "start command was already used with a different request")), state: existing, intents: [], accepted: false, duplicate: false };
    throw new DomainError("INVARIANT_VIOLATION", `Session ${input.sessionId} exists without a start receipt`);
  }
  const definition = registry.getDefinition(input.workDefinitionId, input.revision);
  if (!definition) throw new DomainError("DEFINITION_INVALID", `definition ${input.workDefinitionId}@${input.revision} is not registered`);
  let inputArtifacts = input.inputArtifacts ?? [];
  if (inputArtifacts.length === 0 && input.bootstrapManifest) {
    const manifest = JSON.parse(artifactStore.read(input.bootstrapManifest.blobHash).toString("utf8")) as { formatVersion?: number; inputs?: unknown[] };
    if (manifest.formatVersion !== 1 || !Array.isArray(manifest.inputs)) throw new DomainError("ARTIFACT_STORE_CORRUPT", "Session bootstrap manifest is invalid");
    inputArtifacts = manifest.inputs as ArtifactVersionRuntime[];
  }
  const artifacts = Object.fromEntries(inputArtifacts.map((artifact) => [artifact.artifactVersionId, { ...artifact, artifactKind: artifact.artifactKind ?? "file" as const }]));
  const state = createInitialRuntimeState(definition, input.sessionId, input.input, artifacts);
  state.revision = 1;
  const reduction: ReductionAccepted = {
    kind: "accepted",
    nextState: state,
    facts: [{ type: "SessionStarted", entityId: input.sessionId, data: { workDefinitionId: definition.workDefinitionId, revision: definition.revision } }],
    intents: [],
    response: responseForState(input.sessionId, state),
    advanceRevision: true,
  };
  const committed = registry.commitInitialSession(envelope, reduction, requestHash, { definition, artifactVersions: inputArtifacts, bootstrapManifest: input.bootstrapManifest });
  return { response: committed.response, state: registry.getRuntimeState(input.sessionId) ?? state, intents: [], accepted: true, duplicate: committed.duplicate };
}

function createRegistryActivities(registry: Registry, artifactStore: ArtifactStore, workers: WorkerProfile[]): Pick<TemporalActivities, "initializeSession" | "commitCommand" | "commitAgentResult"> {
  return {
    async initializeSession(input): Promise<TemporalCommitResult> {
      return initializeSession(input, registry, artifactStore);
    },
    async commitCommand(input): Promise<TemporalCommitResult> {
      const reduction = reduceCommand(input.state, input.envelope, { workers });
      return commitResult(input, reduction, registry, hashJson(input.envelope as unknown as JsonValue));
    },
    async commitAgentResult(input): Promise<TemporalCommitResult> {
      const materialized = materializeArtifacts(input.result, input.executionId, artifactStore);
      const command: Extract<import("./contracts.js").DomainCommand, { type: "agentResult" }> = {
        type: "agentResult",
        executionId: input.executionId,
        status: materialized.result.status,
        outcome: materialized.result.outcome,
        result: materialized.result.result,
        failure: materialized.result.failure,
        artifactVersions: materialized.artifactVersions,
      };
      const envelope: CommandEnvelope = {
        schemaVersion: 1,
        sessionId: input.sessionId,
        commandId: input.commandId,
        actor: input.actor,
        command,
      };
      const reduction = reduceCommand(input.state, envelope, { workers });
      return commitResult({ state: input.state, envelope }, reduction, registry, hashJson(envelope as unknown as JsonValue));
    },
  };
}

function createAgentActivities(agentAdapter: AgentAdapter, cancellationGraceMs: number, heartbeatIntervalMs: number): Pick<TemporalActivities, "runAgent" | "cancelAgent"> {
  return {
    async runAgent(request: AgentRunRequest): Promise<AgentRunResult> {
      const context = Context.current();
      const signal = context.cancellationSignal;
      let resolveCancellation: ((result: AgentRunResult) => void) | undefined;
      let cancellationTimer: ReturnType<typeof setTimeout> | undefined;
      const cancellationResult = new Promise<AgentRunResult>((resolve) => {
        resolveCancellation = resolve;
      });
      const onAbort = (): void => {
        void (async () => {
          let confirmed = false;
          try {
            confirmed = (await agentAdapter.cancel(request.execution.executionId)).confirmed;
          } catch {
            confirmed = false;
          }
          cancellationTimer = setTimeout(async () => {
            if (!confirmed && agentAdapter.forceKill) await agentAdapter.forceKill(request.execution.executionId).catch(() => undefined);
            resolveCancellation?.({ status: confirmed ? "cancelled" : "abandoned", failure: confirmed ? undefined : "cancellation could not be confirmed" });
          }, cancellationGraceMs);
        })();
      };
      signal.addEventListener("abort", onAbort, { once: true });
      const heartbeatTimer = setInterval(() => {
        try {
          context.heartbeat({ executionId: request.execution.executionId });
        } catch {
          // Activity が終了処理中なら heartbeat は不要。
        }
      }, Math.max(250, heartbeatIntervalMs));
      try {
        const run = agentAdapter.run(request);
        const result = await Promise.race([run, cancellationResult]);
        return signal.aborted ? await cancellationResult : result;
      } catch (error) {
        if (signal.aborted) return cancellationResult;
        return { status: "failed", failure: error instanceof Error ? error.message : "Agent Activity failed" };
      } finally {
        signal.removeEventListener("abort", onAbort);
        clearInterval(heartbeatTimer);
        if (cancellationTimer) clearTimeout(cancellationTimer);
      }
    },
    async cancelAgent(executionId: string): Promise<{ confirmed: boolean }> {
      try {
        return await agentAdapter.cancel(executionId);
      } catch {
        return { confirmed: false };
      }
    },
  };
}

/** Temporal Worker に登録する Registry/Agent Activity 群を生成する。 */
export function createTemporalActivities(options: TemporalWorkerRuntimeOptions = {}): TemporalActivities {
  const registry = options.registry ?? Registry.open(options.registryPath ?? "registry.sqlite");
  const artifactStore = options.artifactStore ?? ArtifactStore.open(options.artifactRoot ?? "artifacts");
  const workers = [...(options.workers ?? [])];
  for (const worker of workers) {
    registry.db.prepare("INSERT OR REPLACE INTO workers(worker_id, revision, profile_json) VALUES (?, ?, ?)").run(
      worker.workerId,
      worker.revision,
      canonicalJson(worker as unknown as JsonValue),
    );
  }
  const adapter = options.agentAdapter ?? new FakeAgentAdapter();
  return {
    ...createRegistryActivities(registry, artifactStore, workers),
    ...createAgentActivities(
      adapter,
      options.cancellationGraceMs ?? TEMPORAL_ACTIVITY_DEFAULTS.cancellationGraceMs,
      options.heartbeatIntervalMs ?? Math.floor(TEMPORAL_ACTIVITY_DEFAULTS.heartbeatTimeoutMs / 2),
    ),
  };
}
