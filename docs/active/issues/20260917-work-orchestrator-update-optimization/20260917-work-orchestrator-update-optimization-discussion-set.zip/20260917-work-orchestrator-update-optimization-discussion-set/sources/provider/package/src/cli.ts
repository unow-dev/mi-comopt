import { createInterface, type Interface as ReadlineInterface } from "node:readline/promises";
import { stdin as defaultInput, stdout as defaultOutput } from "node:process";
import { randomUUID } from "node:crypto";
import { NativeConnection } from "@temporalio/worker";
import { DomainError, type ActorRef, type ArtifactVersionRuntime, type JsonValue, type RuntimeState, type TaskRuntime } from "./contracts.js";
import { canonicalJson } from "./canonical.js";
import { snapshotOutputDirectory, snapshotPath } from "./artifact.js";
import { createCodexCliAdapter, WorkOrchestrator } from "./runtime.js";
import { runWorkOrchestratorWorker } from "./temporal-worker.js";
import { WorkOrchestratorTemporalClient } from "./temporal-client.js";
import { prepareExecutionWorkspace, type OpenWorkspace } from "./workspace.js";
import { initWorkspace, openWorkspace, resolveWorkspace } from "./workspace.js";

export interface CliIO {
  question(prompt: string): Promise<string>;
  write(message: string): void;
}

export function createReadlineIO(input = defaultInput, output = defaultOutput): CliIO & { close(): void } {
  const readline: ReadlineInterface = createInterface({ input, output });
  return {
    question: (prompt) => readline.question(prompt),
    write: (message) => output.write(message),
    close: () => readline.close(),
  };
}

export interface InteractiveCliOptions {
  workspace?: OpenWorkspace;
  workspacePath?: string;
  actorId?: string;
  io: CliIO;
  orchestrator?: CliOrchestrator;
}

export interface CliOrchestrator {
  state(sessionId: string): RuntimeState | undefined;
  startSessionFromWorkspace(input: { sessionId: string; workDefinitionId: string; revision?: number; input?: JsonValue; inputPaths: string[]; actor?: ActorRef; workspace?: OpenWorkspace }): Promise<JsonValue>;
  completeHumanTaskWithInput(sessionId: string, taskId: string, actor: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string; artifactVersions?: ArtifactVersionRuntime[] }, commandId: string): Promise<JsonValue>;
  openHumanTaskWorkspace(sessionId: string, taskId: string, actor: ActorRef): Promise<{ executionId: string; root: string; inputPath: string; workPath: string; outputPath: string }>;
  completeHumanTaskFromWorkspace(sessionId: string, taskId: string, actor: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string }, commandId: string): Promise<JsonValue>;
  resumeAgentTask(sessionId: string, taskId: string, actor: ActorRef, commandId?: string): Promise<JsonValue>;
}

/** CLI mutation facade for a real Temporal Workflow. Reads remain RegistryReader reads. */
export class TemporalCliOrchestrator implements CliOrchestrator {
  private readonly handles = new Map<string, ReturnType<WorkOrchestratorTemporalClient["client"]["workflow"]["getHandle"]>>();

  constructor(private readonly client: WorkOrchestratorTemporalClient, private readonly workspace: OpenWorkspace) {}

  state(sessionId: string): RuntimeState | undefined {
    return this.workspace.registry.getRuntimeState(sessionId);
  }

  private handle(sessionId: string) {
    const existing = this.handles.get(sessionId);
    if (existing) return existing;
    const handle = this.client.client.workflow.getHandle(sessionId);
    this.handles.set(sessionId, handle);
    return handle;
  }

  async startSessionFromWorkspace(input: { sessionId: string; workDefinitionId: string; revision?: number; input?: JsonValue; inputPaths: string[]; actor?: ActorRef; workspace?: OpenWorkspace }): Promise<JsonValue> {
    const artifacts = input.inputPaths.map((path, ordinal) => snapshotPath(this.workspace.artifactStore, path, { sourceRef: path, artifactVersionId: `${input.sessionId}:input:${ordinal}` }).artifact);
    const manifest = Buffer.from(canonicalJson({ formatVersion: 1, sessionId: input.sessionId, inputs: artifacts } as unknown as JsonValue));
    const staged = this.workspace.artifactStore.stage(manifest, "application/vnd.work-orchestrator.session-bootstrap+json");
    this.workspace.artifactStore.finalize(staged);
    await this.client.start({ sessionId: input.sessionId, workDefinitionId: input.workDefinitionId, revision: input.revision, input: input.input, actor: input.actor, bootstrapManifest: { artifactVersionId: `${input.sessionId}:bootstrap-manifest`, blobHash: staged.blobHash } });
    this.handles.set(input.sessionId, this.client.client.workflow.getHandle(input.sessionId));
    // A new Session may spend a short interval in Agent execution before the
    // first human action becomes visible. Refresh until an actionable Human or
    // Attention item exists so the CLI does not consume a business answer while
    // the derived read model is still catching up.
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const state = this.state(input.sessionId);
      if (state && (state.session.state === "completed" || state.session.state === "cancelled" || Object.values(state.tasks).some((task) => (task.workerKind === "human" && (task.state === "ready" || task.state === "active")) || (task.workerKind === "agent" && task.attention)))) break;
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    return { sessionId: input.sessionId, started: true };
  }

  async completeHumanTaskWithInput(sessionId: string, taskId: string, actorRef: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string; artifactVersions?: ArtifactVersionRuntime[] }, commandId: string): Promise<JsonValue> {
    return await this.client.completeHumanTask(this.handle(sessionId), { taskId, actor: actorRef, commandId, ...input }) as JsonValue;
  }

  async openHumanTaskWorkspace(sessionId: string, taskId: string, actorRef: ActorRef): Promise<{ executionId: string; root: string; inputPath: string; workPath: string; outputPath: string }> {
    const state = this.state(sessionId);
    if (!state) throw new DomainError("SESSION_NOT_FOUND", `Session ${sessionId} not found`);
    const task = state.tasks[taskId];
    if (!task) throw new DomainError("TASK_NOT_FOUND", `Task ${taskId} not found`);
    if (task.state === "ready") await this.client.claimTask(this.handle(sessionId), { taskId, actor: actorRef, commandId: `claim:${taskId}:${actorRef.actorId}` });
    const refreshed = this.state(sessionId);
    const current = refreshed?.tasks[taskId];
    if (!refreshed || !current?.currentExecutionId || current.claimantActorId !== actorRef.actorId) throw new DomainError("NOT_CLAIM_OWNER", "Human Task is claimed by another actor");
    return prepareExecutionWorkspace(this.workspace, refreshed, taskId, current.currentExecutionId, this.workspace.artifactStore);
  }

  async completeHumanTaskFromWorkspace(sessionId: string, taskId: string, actorRef: ActorRef, input: { outcome?: string; result?: JsonValue; comment?: string }, commandId: string): Promise<JsonValue> {
    const state = this.state(sessionId);
    const task = state?.tasks[taskId];
    if (!state || !task?.currentExecutionId) throw new DomainError("WORKSPACE_REQUIRED", "Human Task must be opened before output completion");
    const execution = prepareExecutionWorkspace(this.workspace, state, taskId, task.currentExecutionId, this.workspace.artifactStore);
    const artifacts = snapshotOutputDirectory(this.workspace.artifactStore, execution.outputPath, task.currentExecutionId);
    return this.completeHumanTaskWithInput(sessionId, taskId, actorRef, { ...input, artifactVersions: artifacts }, commandId);
  }

  async resumeAgentTask(sessionId: string, taskId: string, actorRef: ActorRef, commandId = `retry-agent:${taskId}:${actorRef.actorId}`): Promise<JsonValue> {
    return await this.client.resumeAgentTask(this.handle(sessionId), { taskId, actor: actorRef, commandId }) as JsonValue;
  }
}

function actorIdFrom(options: InteractiveCliOptions): string {
  return options.actorId ?? process.env.WORK_ORCHESTRATOR_ACTOR_ID ?? process.env.USER ?? "unknown-actor";
}

function actor(actorId: string): ActorRef {
  return { actorId, actorType: "human" };
}

function inputPaths(value: string): string[] {
  return value.split(",").map((item) => item.trim()).filter(Boolean);
}

function actionableTasks(workspace: OpenWorkspace): Array<{ sessionId: string; task: TaskRuntime }> {
  const tasks: Array<{ sessionId: string; task: TaskRuntime }> = [];
  for (const session of workspace.registry.listSessions(200)) {
    const sessionId = String(session.session_id);
    const state = workspace.registry.getRuntimeState(sessionId);
    if (!state) continue;
    if (state.session.state === "completed" || state.session.state === "cancelled") continue;
    for (const task of Object.values(state.tasks)) {
      if (task.workerKind === "human" && (task.state === "ready" || task.state === "active")) tasks.push({ sessionId, task });
      if (task.workerKind === "agent" && task.attention) tasks.push({ sessionId, task });
    }
  }
  return tasks;
}

async function chooseHumanTask(options: InteractiveCliOptions, orchestration: CliOrchestrator, actorId: string, entry: { sessionId: string; task: TaskRuntime }): Promise<void> {
  const { task } = entry;
  const human = actor(actorId);
  const isFileTask = task.contract.outputSchema !== undefined;
  if (isFileTask) {
    await orchestration.openHumanTaskWorkspace(entry.sessionId, task.taskId, human);
    options.io.write(`Workspaceを開きました。output/ に保存後、Complete を実行してください。\n`);
    await options.io.question("Complete [Enter]: ");
    await orchestration.completeHumanTaskFromWorkspace(entry.sessionId, task.taskId, human, {}, `complete-human:${task.taskId}:${actorId}:workspace`);
    return;
  }
  const allowed = task.contract.allowedOutcomes ?? [];
  let outcome: string | undefined;
  if (allowed.length > 1) outcome = (await options.io.question(`Outcome (${allowed.join("/")}): `)).trim();
  else if (allowed.length === 1) outcome = allowed[0];
  let result: JsonValue | undefined;
  if (task.contract.resultSchema !== undefined) {
    const raw = (await options.io.question("Result JSON: ")).trim();
    result = raw ? JSON.parse(raw) as JsonValue : null;
  }
  await orchestration.completeHumanTaskWithInput(entry.sessionId, task.taskId, human, { outcome, result }, `complete-human:${task.taskId}:${actorId}:simple`);
}

export async function runInteractiveCli(options: InteractiveCliOptions): Promise<void> {
  const workspace = options.workspace ?? openWorkspace(resolveWorkspace(options.workspacePath));
  const actorId = actorIdFrom(options);
  const orchestration = options.orchestrator ?? new WorkOrchestrator({
    registry: workspace.registry,
    artifactStore: workspace.artifactStore,
    workspace,
    agentAdapter: createCodexCliAdapter({ sandbox: "workspace-write" }),
  });
  try {
    const active = actionableTasks(workspace).filter((entry) => entry.task.workerKind === "human" && entry.task.state === "active" && entry.task.claimantActorId === actorId);
    if (active.length === 1) {
      await chooseHumanTask(options, orchestration, actorId, active[0]);
      return;
    }
    while (true) {
      const tasks = actionableTasks(workspace);
      options.io.write("\nWork Orchestrator\n");
      options.io.write(tasks.length === 0 ? "作業はありません。\n" : tasks.map((entry, index) => `${index + 1}. ${entry.task.workerKind === "human" ? "Human" : "Attention"}: ${entry.task.goal}`).join("\n") + "\n");
      const action = (await options.io.question("Action [new/task/retry/quit]: ")).trim().toLowerCase();
      if (action === "quit" || action === "q" || action === "") return;
      if (action === "new" || action === "n") {
        const definitions = workspace.registry.listDefinitions();
        const ids = [...new Set(definitions.map((definition) => definition.workDefinitionId))];
        if (ids.length === 0) throw new DomainError("DEFINITION_INVALID", "登録済みWorkDefinitionがありません");
        const selectedId = ids.length === 1 ? ids[0] : (await options.io.question(`WorkDefinition (${ids.join("/")}): `)).trim();
        const selected = definitions.filter((definition) => definition.workDefinitionId === selectedId).sort((left, right) => right.revision - left.revision)[0];
        if (!selected) throw new DomainError("DEFINITION_INVALID", `WorkDefinition ${selectedId} が見つかりません`);
        const paths = inputPaths(await options.io.question("Input paths (comma-separated, optional): "));
        await options.io.question("Start [Enter]: ");
        const sessionId = `session-${randomUUID()}`;
        await orchestration.startSessionFromWorkspace({ sessionId, workDefinitionId: selected.workDefinitionId, revision: selected.revision, inputPaths: paths, actor: actor(actorId), workspace });
        options.io.write(`Sessionを開始しました: ${sessionId}\n`);
        continue;
      }
      const index = Number.parseInt(action, 10) - 1;
      if (!Number.isInteger(index) || index < 0 || index >= tasks.length) continue;
      const selected = tasks[index];
      if (selected.task.workerKind === "human") await chooseHumanTask(options, orchestration, actorId, selected);
      else await orchestration.resumeAgentTask(selected.sessionId, selected.task.taskId, actor(actorId), `retry-agent:${selected.task.taskId}:${actorId}`);
    }
  } finally {
    if (!options.workspace) workspace.registry.close();
  }
}

export async function runCli(argv: string[], io?: CliIO): Promise<void> {
  const write = io?.write ?? ((message: string) => process.stdout.write(message));
  const command = argv[0] && !argv[0].startsWith("-") ? argv[0] : undefined;
  const args = command ? argv.slice(1) : argv;
  let workspacePath: string | undefined;
  let actorId: string | undefined;
  for (let index = 0; index < args.length; index += 1) {
    const value = args[index];
    if (value === "--actor") actorId = args[++index];
    else if (value === "--workspace") workspacePath = args[++index];
    else if (!value.startsWith("-")) workspacePath = value;
    else throw new DomainError("INVALID_COMMAND", `unknown option: ${value}`);
  }
  if (command === "init") {
    const result = initWorkspace(workspacePath ?? process.cwd());
    write(`Workspaceを初期化しました: ${result.workspace.root}\n`);
    return;
  }
  if (command === "worker") {
    const root = resolveWorkspace(workspacePath);
    const workspace = openWorkspace(root);
    const address = workspace.config.temporal.address ?? "localhost:7233";
    const namespace = workspace.config.temporal.namespace ?? "default";
    const taskQueue = workspace.config.temporal.taskQueue ?? "work-orchestrator";
    const connection = await NativeConnection.connect({ address });
    write(`Workerを起動します: ${root} (${address})\n`);
    try {
      await runWorkOrchestratorWorker({
        connection,
        namespace,
        taskQueue,
        runtime: { registry: workspace.registry, artifactStore: workspace.artifactStore, workers: workspace.registry.listWorkers(), agentAdapter: createCodexCliAdapter({ sandbox: "workspace-write" }) },
      });
    } finally {
      await connection.close();
      workspace.registry.close();
    }
    return;
  }
  if (!io && !process.stdin.isTTY) throw new DomainError("INVALID_COMMAND", "interactive mode requires a TTY");
  const created = io ? undefined : createReadlineIO();
  try {
    await runInteractiveCli({ workspacePath, actorId, io: io ?? created! });
  } finally {
    created?.close();
  }
}
