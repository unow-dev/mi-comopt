# Work Orchestrator 利用者向けドキュメント更新

## Purpose

`package/README.md`、`package/docs/README.md` および `package/docs/API_REFERENCE.md` を、ライブラリ利用者が初回Workspace構築、公開APIの利用、WorkDefinition登録および業務開始までの手順を一貫して理解できる内容へ更新する。
