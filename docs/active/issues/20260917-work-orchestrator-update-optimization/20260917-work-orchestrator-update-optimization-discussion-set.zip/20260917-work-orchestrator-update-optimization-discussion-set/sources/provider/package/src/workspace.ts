import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, unlinkSync, writeFileSync, renameSync } from "node:fs";
import { hostname } from "node:os";
import { basename, dirname, join, resolve } from "node:path";
import { ArtifactStore } from "./artifact-store.js";
import { canonicalJson, sha256 } from "./canonical.js";
import { materializeArtifact } from "./artifact.js";
import { DomainError, type ArtifactVersionRuntime, type JsonValue, type RuntimeState } from "./contracts.js";
import { Registry } from "./registry.js";

export const WORKSPACE_FORMAT_VERSION = 1;
export const WORKSPACE_STATE_PATH = join(".work-orchestrator", "workspace-state.json");
export const WORKSPACE_REGISTRY_PATH = join(".work-orchestrator", "registry.sqlite");
export const WORKSPACE_ARTIFACTS_PATH = join(".work-orchestrator", "artifacts");

export interface WorkspaceConfig {
  formatVersion: 1;
  temporal: {
    address?: string;
    namespace?: string;
    taskQueue?: string;
    registryTaskQueue?: string;
    agentTaskQueue?: string;
  };
  [key: string]: JsonValue | undefined;
}

export interface WorkspaceState {
  formatVersion: 1;
  workspaceId: string;
}

export interface WorkspacePaths {
  root: string;
  configPath: string;
  statePath: string;
  registryPath: string;
  artifactRoot: string;
  inboxPath: string;
  workPath: string;
  outboxPath: string;
  sessionsPath: string;
}

export interface OpenWorkspace extends WorkspacePaths {
  config: WorkspaceConfig;
  state: WorkspaceState;
  registry: Registry;
  artifactStore: ArtifactStore;
}

export interface InitWorkspaceResult {
  workspace: WorkspacePaths;
  state: WorkspaceState;
  created: boolean;
  resumed: boolean;
}

const DEFAULT_CONFIG: WorkspaceConfig = {
  formatVersion: 1,
  temporal: {
    address: "localhost:7233",
    namespace: "default",
    taskQueue: "work-orchestrator",
    registryTaskQueue: "work-orchestrator-registry",
    agentTaskQueue: "work-orchestrator-agent",
  },
};

export function workspacePaths(root: string): WorkspacePaths {
  const absolute = resolve(root);
  return {
    root: absolute,
    configPath: join(absolute, "work-orchestrator.json"),
    statePath: join(absolute, WORKSPACE_STATE_PATH),
    registryPath: join(absolute, WORKSPACE_REGISTRY_PATH),
    artifactRoot: join(absolute, WORKSPACE_ARTIFACTS_PATH),
    inboxPath: join(absolute, "inbox"),
    workPath: join(absolute, "work"),
    outboxPath: join(absolute, "outbox"),
    sessionsPath: join(absolute, "sessions"),
  };
}

function parseJson(path: string, errorCode: "WORKSPACE_CORRUPT" | "FUTURE_FORMAT"): unknown {
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch (error) {
    throw new DomainError(errorCode, `invalid JSON at ${path}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

function readConfig(paths: WorkspacePaths): WorkspaceConfig {
  if (!existsSync(paths.configPath)) throw new DomainError("WORKSPACE_CORRUPT", "work-orchestrator.json is missing");
  const config = parseJson(paths.configPath, "WORKSPACE_CORRUPT");
  if (!config || typeof config !== "object" || (config as { formatVersion?: unknown }).formatVersion !== WORKSPACE_FORMAT_VERSION || !(config as { temporal?: unknown }).temporal || typeof (config as { temporal?: unknown }).temporal !== "object") {
    throw new DomainError("WORKSPACE_CORRUPT", "workspace configuration is invalid");
  }
  return config as WorkspaceConfig;
}

function readState(paths: WorkspacePaths): WorkspaceState {
  if (!existsSync(paths.statePath)) throw new DomainError("WORKSPACE_METADATA_MISSING", "workspace completion marker is missing");
  const state = parseJson(paths.statePath, "WORKSPACE_CORRUPT");
  if (!state || typeof state !== "object" || (state as { formatVersion?: unknown }).formatVersion !== WORKSPACE_FORMAT_VERSION || typeof (state as { workspaceId?: unknown }).workspaceId !== "string" || !(state as { workspaceId: string }).workspaceId) {
    const version = state && typeof state === "object" ? (state as { formatVersion?: unknown }).formatVersion : undefined;
    if (typeof version === "number" && version > WORKSPACE_FORMAT_VERSION) throw new DomainError("FUTURE_FORMAT", `workspace format ${version} is newer than supported`);
    throw new DomainError("WORKSPACE_CORRUPT", "workspace completion marker is invalid");
  }
  return state as WorkspaceState;
}

function writeJsonAtomically(path: string, value: unknown): void {
  const temporary = `${path}.tmp-${process.pid}-${randomUUID()}`;
  writeFileSync(temporary, `${canonicalJson(value as JsonValue)}\n`, { flag: "wx" });
  renameSync(temporary, path);
}

function acquireInitLock(paths: WorkspacePaths): () => void {
  const lockPath = join(paths.root, ".work-orchestrator", "init.lock");
  try {
    writeFileSync(lockPath, `${canonicalJson({ pid: process.pid, hostname: hostname(), createdAt: new Date().toISOString() } as unknown as JsonValue)}\n`, { flag: "wx" });
  } catch (error) {
    if (!existsSync(lockPath)) throw error;
    let lock: { pid?: number; hostname?: string; createdAt?: string } = {};
    try { lock = JSON.parse(readFileSync(lockPath, "utf8")) as typeof lock; } catch { throw new DomainError("WORKSPACE_CORRUPT", "init lock is malformed"); }
    const createdAt = Date.parse(lock.createdAt ?? "");
    let alive = false;
    if (lock.hostname === hostname() && Number.isInteger(lock.pid) && lock.pid !== process.pid) {
      try { process.kill(lock.pid!, 0); alive = true; } catch { alive = false; }
    }
    if (alive || (Number.isFinite(createdAt) && Date.now() - createdAt < 60_000)) throw new DomainError("INVALID_STATE", "workspace init is already in progress");
    unlinkSync(lockPath);
    writeFileSync(lockPath, `${canonicalJson({ pid: process.pid, hostname: hostname(), createdAt: new Date().toISOString() } as unknown as JsonValue)}\n`, { flag: "wx" });
  }
  return () => { if (existsSync(lockPath)) unlinkSync(lockPath); };
}

function isPristineRegistry(path: string): boolean {
  if (!existsSync(path)) return true;
  try {
    const registry = Registry.open(path);
    const pristine = registry.listDefinitions().length === 0 && registry.listSessions(1).length === 0;
    registry.close();
    return pristine;
  } catch {
    return statSync(path).size === 0;
  }
}

function isPristineArtifactStore(root: string): boolean {
  if (!existsSync(root)) return true;
  try {
    const store = ArtifactStore.open(root);
    const blobs = requireDirectoryEntries(join(root, "blobs"));
    return blobs.length === 0;
  } catch {
    return requireDirectoryEntries(root).filter((entry) => entry !== "staging").every((entry) => entry === "blobs" && requireDirectoryEntries(join(root, entry)).length === 0);
  }
}

function requireDirectoryEntries(path: string): string[] {
  if (!existsSync(path) || !statSync(path).isDirectory()) return [];
  return readdirSync(path);
}

export function initWorkspace(root: string, options: { config?: Partial<WorkspaceConfig> } = {}): InitWorkspaceResult {
  const paths = workspacePaths(root);
  mkdirSync(join(paths.root, ".work-orchestrator"), { recursive: true });
  const releaseLock = acquireInitLock(paths);
  try {
    const markerExists = existsSync(paths.statePath);
    const configExists = existsSync(paths.configPath);
    const config = configExists ? readConfig(paths) : { ...DEFAULT_CONFIG, ...(options.config ?? {}), temporal: { ...DEFAULT_CONFIG.temporal, ...(options.config?.temporal ?? {}) } };
    if (markerExists) {
      const state = readState(paths);
      if (!configExists) throw new DomainError("WORKSPACE_CORRUPT", "completed workspace is missing its configuration");
      // A completed Workspace may recreate only derived directories. Authorities
      // must be opened, never synthesized.
      const registry = Registry.open(paths.registryPath);
      if (registry.getWorkspaceId() !== state.workspaceId) {
        registry.close();
        throw new DomainError("WORKSPACE_CORRUPT", "Registry Workspace identity does not match the completion marker");
      }
      registry.close();
      const store = ArtifactStore.open(paths.artifactRoot);
      if (store.getWorkspaceId() !== state.workspaceId) throw new DomainError("WORKSPACE_CORRUPT", "ArtifactStore Workspace identity does not match the completion marker");
      for (const directory of [paths.inboxPath, paths.workPath, paths.outboxPath, paths.sessionsPath]) mkdirSync(directory, { recursive: true });
      return { workspace: paths, state, created: false, resumed: false };
    }

    const registryExists = existsSync(paths.registryPath) && statSync(paths.registryPath).size > 0;
    const artifactExists = existsSync(paths.artifactRoot);
    if (registryExists && !isPristineRegistry(paths.registryPath)) throw new DomainError("WORKSPACE_METADATA_MISSING", "data-bearing Registry has no workspace metadata");
    if (artifactExists && !isPristineArtifactStore(paths.artifactRoot)) throw new DomainError("WORKSPACE_METADATA_MISSING", "data-bearing ArtifactStore has no workspace metadata");

    const workspaceId = randomUUID();
    const registry = Registry.initialize(paths.registryPath);
    const existingRegistryWorkspaceId = registry.getWorkspaceId();
    if (existingRegistryWorkspaceId && existingRegistryWorkspaceId !== workspaceId) {
      registry.close();
      throw new DomainError("WORKSPACE_METADATA_MISSING", "recognized Registry belongs to another Workspace");
    }
    registry.setWorkspaceId(workspaceId);
    registry.close();
    const artifactStore = ArtifactStore.initialize(paths.artifactRoot);
    artifactStore.bindWorkspaceId(workspaceId);
    for (const directory of [paths.inboxPath, paths.workPath, paths.outboxPath, paths.sessionsPath]) mkdirSync(directory, { recursive: true });
    if (!configExists) writeJsonAtomically(paths.configPath, config);
    const state: WorkspaceState = { formatVersion: 1, workspaceId };
    // Completion marker is intentionally the final publication step.
    writeJsonAtomically(paths.statePath, state);
    return { workspace: paths, state, created: true, resumed: registryExists || artifactExists };
  } finally {
    releaseLock();
  }
}

export function openWorkspace(root: string): OpenWorkspace {
  const paths = workspacePaths(root);
  const config = readConfig(paths);
  const state = readState(paths);
  const registry = Registry.open(paths.registryPath);
  const artifactStore = ArtifactStore.open(paths.artifactRoot);
  if (registry.getWorkspaceId() !== state.workspaceId || artifactStore.getWorkspaceId() !== state.workspaceId) {
    registry.close();
    throw new DomainError("WORKSPACE_CORRUPT", "Workspace identity does not match its authorities");
  }
  return { ...paths, config, state, registry, artifactStore };
}

export function findWorkspace(start = process.cwd()): string | undefined {
  let current = resolve(start);
  while (true) {
    const paths = workspacePaths(current);
    if (existsSync(paths.statePath)) return current;
    const parent = dirname(current);
    if (parent === current) return undefined;
    current = parent;
  }
}

export function resolveWorkspace(explicit?: string, start = process.cwd()): string {
  const root = explicit ? resolve(explicit) : findWorkspace(start);
  if (!root) throw new DomainError("WORKSPACE_METADATA_MISSING", "completed Workspace was not found");
  return root;
}

export function safeWorkspaceKey(id: string): string {
  return sha256(id).slice(0, 32);
}

export interface ExecutionWorkspace {
  root: string;
  sessionId: string;
  executionId: string;
  inputPath: string;
  workPath: string;
  outputPath: string;
  metadataPath: string;
}

export function executionWorkspace(paths: WorkspacePaths, sessionId: string, executionId: string): ExecutionWorkspace {
  const root = join(paths.sessionsPath, safeWorkspaceKey(sessionId), safeWorkspaceKey(executionId));
  return { root, sessionId, executionId, inputPath: join(root, "input"), workPath: join(root, "work"), outputPath: join(root, "output"), metadataPath: join(root, ".execution.json") };
}

export function prepareExecutionWorkspace(paths: WorkspacePaths, state: RuntimeState, taskId: string, executionId: string, store: ArtifactStore): ExecutionWorkspace {
  const task = state.tasks[taskId];
  const execution = state.executions[executionId];
  if (!task || !execution) throw new DomainError("INVALID_STATE", "Execution workspace references an unknown Domain object");
  const workspace = executionWorkspace(paths, state.session.sessionId, executionId);
  mkdirSync(workspace.inputPath, { recursive: true });
  mkdirSync(workspace.workPath, { recursive: true });
  mkdirSync(workspace.outputPath, { recursive: true });
  const metadata = { formatVersion: 1, workspaceId: state.session.sessionId, sessionId: state.session.sessionId, taskId, executionId, inputArtifactVersionIds: task.inputArtifactVersionIds };
  if (existsSync(workspace.metadataPath)) {
    const existing = parseJson(workspace.metadataPath, "WORKSPACE_CORRUPT") as typeof metadata;
    if (existing.formatVersion !== 1 || existing.sessionId !== metadata.sessionId || existing.taskId !== taskId || existing.executionId !== executionId) throw new DomainError("WORKSPACE_CORRUPT", "Execution workspace metadata does not match Domain identity");
  } else writeJsonAtomically(workspace.metadataPath, metadata);
  const manifest = { formatVersion: 1, artifactVersionIds: task.inputArtifactVersionIds };
  const manifestPath = join(workspace.inputPath, "manifest.json");
  if (!existsSync(manifestPath) || canonicalJson(parseJson(manifestPath, "WORKSPACE_CORRUPT") as JsonValue) !== canonicalJson(manifest as unknown as JsonValue)) writeJsonAtomically(manifestPath, manifest);
  for (const [ordinal, artifactId] of task.inputArtifactVersionIds.entries()) {
    const artifact = state.artifacts[artifactId];
    if (!artifact) continue;
    rmSync(join(workspace.inputPath, String(ordinal).padStart(4, "0")), { recursive: true, force: true });
    const destination = join(workspace.inputPath, String(ordinal).padStart(4, "0"), artifact.logicalPath ? basename(artifact.logicalPath) : artifactId);
    materializeArtifact(store, artifact, destination);
  }
  return workspace;
}
