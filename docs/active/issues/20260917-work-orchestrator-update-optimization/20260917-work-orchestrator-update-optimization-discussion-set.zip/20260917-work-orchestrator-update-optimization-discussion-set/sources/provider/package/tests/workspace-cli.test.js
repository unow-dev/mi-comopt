import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, rmSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { Client } from "@temporalio/client";
import { TestWorkflowEnvironment } from "@temporalio/testing";
import { Worker } from "@temporalio/worker";
import {
  ArtifactStore,
  Registry,
  WorkOrchestrator,
  initWorkspace,
  openWorkspace,
  snapshotPath,
  materializeArtifact,
  validateAndHashDefinition,
  runInteractiveCli,
  reconcileOutbox,
  FakeAgentAdapter,
  TemporalCliOrchestrator,
  WorkOrchestratorTemporalClient,
  createTemporalActivities,
  workSessionWorkflow,
} from "../dist/index.js";

function directory() {
  return mkdtempSync(join(tmpdir(), "work-orchestrator-acceptance-"));
}

function humanDefinition(id = "human-cli") {
  return validateAndHashDefinition({
    workDefinitionId: id,
    revision: 0,
    schemaVersion: 2,
    root: { kind: "task", id: "human", goal: "Review", contract: { workerKind: "human", requiredCapabilities: [], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, allowedOutcomes: ["approve", "reject"] } },
  });
}

test("Storage lifecycle and init are non-destructive", () => {
  const root = directory();
  const missingRegistry = join(root, "missing.sqlite");
  assert.throws(() => Registry.open(missingRegistry));
  assert.equal(existsSync(missingRegistry), false);
  assert.throws(() => Registry.openReadOnly(missingRegistry));
  const first = initWorkspace(root);
  const configBefore = readFileSync(join(root, "work-orchestrator.json"), "utf8");
  const second = initWorkspace(root);
  assert.equal(first.created, true);
  assert.equal(second.created, false);
  assert.equal(readFileSync(join(root, "work-orchestrator.json"), "utf8"), configBefore);
  const workspace = openWorkspace(root);
  assert.equal(workspace.registry.getWorkspaceId(), workspace.state.workspaceId);
  assert.equal(workspace.artifactStore.getWorkspaceId(), workspace.state.workspaceId);
  workspace.registry.close();
});

test("Directory input is one immutable ArtifactVersion and materializes from its manifest", () => {
  const root = directory();
  const source = join(root, "source");
  mkdirSync(join(source, "nested"), { recursive: true });
  writeFileSync(join(source, "a.txt"), "a");
  writeFileSync(join(source, "nested", "b.txt"), "b");
  const store = ArtifactStore.temporary();
  const snapshot = snapshotPath(store, source);
  assert.equal(snapshot.artifact.artifactKind, "directory");
  assert.equal(snapshot.manifest.files.length, 2);
  const destination = join(root, "materialized");
  materializeArtifact(store, snapshot.artifact, destination);
  assert.equal(readFileSync(join(destination, "nested", "b.txt"), "utf8"), "b");
});

test("Corrupt authorities fail closed and completed init does not recreate them", () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  writeFileSync(join(root, "input.txt"), "immutable");
  const snapshot = snapshotPath(workspace.artifactStore, join(root, "input.txt"));
  writeFileSync(workspace.artifactStore.blobPath(snapshot.artifact.blobHash), "corrupt");
  assert.throws(() => workspace.artifactStore.read(snapshot.artifact.blobHash));
  workspace.registry.close();
  rmSync(join(root, ".work-orchestrator", "registry.sqlite"));
  assert.throws(() => initWorkspace(root));
});

test("Simple Human completion auto-claims and uses one mutation", async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  const orchestrator = new WorkOrchestrator({ registry: workspace.registry, artifactStore: workspace.artifactStore, workspace });
  await orchestrator.startSession({ sessionId: "simple-human", definition: humanDefinition(), commandId: "start-simple-human" });
  const task = Object.values(orchestrator.state("simple-human").tasks)[0];
  const response = await orchestrator.completeHumanTaskWithInput("simple-human", task.taskId, { actorId: "reviewer", actorType: "human" }, { outcome: "approve" }, "complete-simple-human");
  assert.equal(response.outcome, "approve");
  assert.equal(orchestrator.state("simple-human").tasks[task.taskId].state, "completed");
  workspace.registry.close();
});

test("Human output is snapshotted and modified managed outbox bytes are preserved", async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  const definition = validateAndHashDefinition({
    workDefinitionId: "human-file",
    revision: 0,
    schemaVersion: 2,
    root: { kind: "task", id: "human", goal: "write a file", contract: { workerKind: "human", requiredCapabilities: [], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, outputSchema: { type: "object" } } },
  });
  const orchestrator = new WorkOrchestrator({ registry: workspace.registry, artifactStore: workspace.artifactStore, workspace });
  await orchestrator.startSession({ sessionId: "human-file-session", definition, commandId: "start-human-file" });
  const task = Object.values(orchestrator.state("human-file-session").tasks)[0];
  const executionWorkspace = await orchestrator.openHumanTaskWorkspace("human-file-session", task.taskId, { actorId: "writer", actorType: "human" });
  writeFileSync(join(executionWorkspace.outputPath, "answer.txt"), "canonical");
  await orchestrator.completeHumanTaskFromWorkspace("human-file-session", task.taskId, { actorId: "writer", actorType: "human" }, { result: {} }, "complete-human-file");
  const managed = readdirSync(join(root, "outbox")).find((name) => name.endsWith("-answer.txt"));
  assert.ok(managed);
  writeFileSync(join(root, "outbox", managed), "user edit");
  const state = orchestrator.state("human-file-session");
  const result = reconcileOutbox(workspace, state, workspace.artifactStore);
  assert.equal(result.conflicts.length, 1);
  assert.equal(readFileSync(join(root, "outbox", managed), "utf8"), "canonical");
  assert.ok(result.preserved.every((path) => readFileSync(path, "utf8") === "user edit"));
  workspace.registry.close();
});

test("Scripted CLI keeps New work and approval paths compact", async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  workspace.registry.registerDefinition(humanDefinition("cli-definition"));
  const answers = ["new", "", "", "1", "approve"];
  const prompts = [];
  const io = {
    async question(prompt) { prompts.push(prompt); return answers.shift() ?? ""; },
    write() {},
  };
  await runInteractiveCli({ workspace, actorId: "reviewer", io });
  assert.equal(prompts.filter((prompt) => prompt.startsWith("Input paths")).length, 1);
  assert.equal(prompts.filter((prompt) => prompt.startsWith("Start")).length, 1);
  assert.equal(prompts.filter((prompt) => prompt.startsWith("Outcome")).length, 1);
  workspace.registry.close();
});

test("CLI does not show Agent attention from a cancelled Session", async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  const definition = validateAndHashDefinition({
    workDefinitionId: "cli-cancelled-attention",
    revision: 0,
    schemaVersion: 2,
    root: { kind: "task", id: "agent", goal: "requires unavailable worker", contract: { workerKind: "agent", requiredCapabilities: ["unavailable"], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } } },
  });
  const orchestrator = new WorkOrchestrator({ registry: workspace.registry, artifactStore: workspace.artifactStore, workspace, agentAdapter: new FakeAgentAdapter(), workers: [] });
  workspace.registry.registerDefinition(definition);
  await orchestrator.startSession({ sessionId: "cancelled-attention-session", workDefinitionId: definition.workDefinitionId });
  await orchestrator.cancelSession("cancelled-attention-session", { actorId: "operator", actorType: "operator" });
  const writes = [];
  const io = { async question() { return ""; }, write(message) { writes.push(message); } };
  await runInteractiveCli({ workspace, actorId: "operator", io, orchestrator });
  assert.ok(writes.some((message) => message.includes("作業はありません。")));
  assert.equal(writes.some((message) => message.includes("Attention")), false);
  workspace.registry.close();
});

test("CLI drives Agent -> Human -> Agent to Session completion", async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  const definition = validateAndHashDefinition({
    workDefinitionId: "cli-e2e-definition",
    revision: 0,
    schemaVersion: 2,
    root: { kind: "sequence", id: "root", children: [
      { kind: "task", id: "agent-one", goal: "prepare", contract: { workerKind: "agent", requiredCapabilities: ["fixture"], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } } },
      { kind: "task", id: "human", goal: "approve", contract: { workerKind: "human", requiredCapabilities: [], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, allowedOutcomes: ["approve", "reject"] } },
      { kind: "task", id: "agent-two", goal: "finish", contract: { workerKind: "agent", requiredCapabilities: ["fixture"], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } } },
    ] },
  });
  workspace.registry.registerDefinition(definition);
  const adapter = {
    async run() { return { status: "succeeded" }; },
    async cancel() { return { confirmed: true }; },
  };
  const orchestrator = new WorkOrchestrator({
    registry: workspace.registry,
    artifactStore: workspace.artifactStore,
    workspace,
    agentAdapter: adapter,
    workers: [{ workerId: "fixture", revision: 1, enabled: true, capabilities: ["fixture"], enforceablePermissions: [], enforceableBudgets: [], routingPriority: 1 }],
  });
  const answers = ["new", "", "", "1", "approve", ""];
  const io = { async question() { return answers.shift() ?? ""; }, write() {} };
  await runInteractiveCli({ workspace, actorId: "reviewer", io, orchestrator });
  const session = workspace.registry.listSessions(10)[0];
  assert.equal(orchestrator.state(String(session.session_id)).session.state, "completed");
  workspace.registry.close();
});

test("Temporal Test Environment drives the same CLI Agent -> Human -> Agent flow", { timeout: 120_000 }, async () => {
  const root = directory();
  initWorkspace(root);
  const workspace = openWorkspace(root);
  const definition = validateAndHashDefinition({
    workDefinitionId: "temporal-cli-e2e-definition",
    revision: 0,
    schemaVersion: 2,
    root: { kind: "sequence", id: "root", children: [
      { kind: "task", id: "agent-one", goal: "prepare", contract: { workerKind: "agent", requiredCapabilities: ["fixture"], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } } },
      { kind: "task", id: "human", goal: "approve", contract: { workerKind: "human", requiredCapabilities: [], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, allowedOutcomes: ["approve", "reject"] } },
      { kind: "task", id: "agent-two", goal: "finish", contract: { workerKind: "agent", requiredCapabilities: ["fixture"], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } } },
    ] },
  });
  workspace.registry.registerDefinition(definition);
  const environment = await TestWorkflowEnvironment.createTimeSkipping();
  const worker = await Worker.create({
    connection: environment.nativeConnection,
    taskQueue: "temporal-cli-e2e",
    workflowsPath: fileURLToPath(new URL("../dist/temporal-workflow.js", import.meta.url)),
    activities: createTemporalActivities({ registry: workspace.registry, artifactStore: workspace.artifactStore, workers: [{ workerId: "fixture", revision: 1, enabled: true, capabilities: ["fixture"], enforceablePermissions: [], enforceableBudgets: [], routingPriority: 1 }], agentAdapter: new FakeAgentAdapter() }),
  });
  const workerRun = worker.run();
  try {
    const temporalClient = new WorkOrchestratorTemporalClient({ client: new Client({ connection: environment.nativeConnection }), taskQueue: "temporal-cli-e2e" });
    const orchestrator = new TemporalCliOrchestrator(temporalClient, workspace);
    const answers = ["new", "", "", "1", "approve", ""];
    const io = { async question() { return answers.shift() ?? ""; }, write() {} };
    await runInteractiveCli({ workspace, actorId: "reviewer", io, orchestrator });
    for (let index = 0; index < 80; index += 1) {
      const session = workspace.registry.listSessions(10)[0];
      if (session && (session.state === "completed" || session.state === "cancelled")) break;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    const session = workspace.registry.listSessions(10)[0];
    assert.equal(session.state, "completed");
  } finally {
    await worker.shutdown();
    await workerRun.catch(() => undefined);
    await environment.teardown();
    workspace.registry.close();
  }
});
