# raw snapshot拡張とデータベース起点の分析処理: 議論セット

## このセットの目的

`ISSUE_BODY.md` を具体化する際に、現行のComment DB、dataset JSONを直接入力する後続処理、公開artifact境界、およびUI取り込みの実装を同じ参照単位で確認できるようにする。

## 読み始める順序

1. `ISSUE_BODY.md` — 議論対象の目的、背景および初期考察。
2. `raw-snapshot.schema.json` — 今回のraw snapshot入力契約案。
3. `sources/package/src/database/comment-database.js`、`sources/package/db/comment-database/001-init.sql`、`sources/package/scripts/comment-database.mjs` — 現行の正規化入力、保存、migrationおよびCLI境界。
4. `sources/package/src/processing/` と `sources/package/scripts/candidate-workflow.mjs` — 現在dataset JSONを入力とする候補評価・更新・handoff・公開の経路。
5. `sources/package/src/ui/` — UIがDBを直接読まず、生成artifactを取り込む現状の境界。
6. `sources/docs/active/issues/` — 現行Comment DB、レイヤー分離、raw統合および更新運用に関する有効なissue本文。

## 収録範囲

- raw snapshot schema案、現行Comment DBの実装・migration・CLI・テスト。
- keyword候補／account候補の現行processing実装、公開artifact生成境界、入力datasetの最小fixture、および現行契約。
- 生成artifactを取り込むUIの境界実装。
- `docs/active` 配下のうち、この議論の前提となる有効なissue本文のみ。

## 意図的な除外

- `docs/active` 外の文書、`docs/archive`、過去のhandoff／source snapshot、旧実装、互換shim、生成済みデータ、実データ、browser buildおよび依存パッケージ。
- 現行処理中に歴史的な移行経路を扱う箇所は、その経路のデータ・仕様・shimを収録しない。ここでは現在のraw snapshotからDBを介する経路の設計に必要な実装だけを参照対象とする。

## 現在の対応関係

```text
raw snapshot（今回の新規契約）
  -> raw snapshot保存 / 正規化
  -> Comment DB
  -> 分析用dataset
  -> keyword・account候補処理
  -> 公開artifact
  -> UI
```

このセットは参照用のコピーであり、実装・テストをそのまま実行するための配布物ではない。変更はリポジトリ本体で行う。
