# Work Task Sequence: 候補キーワード更新フロー

## Purpose

Integrated Labeling の publication 済み 3-class artifact を起点に、候補キーワードの提案、評価、履歴管理、公開および `NEW` 表示を、追跡可能かつ再現可能に運用できる状態にする。

## Task Sequence

- [x] 1. 要求整理の範囲で、AIエージェントが、仕様の正本、受入条件、対象外事項および実施順序を確認する。
- [x] 2. 決定的評価基盤の範囲で、AIエージェントが、候補評価に必要な契約、方針、正規化および評価処理を整備する。
- [x] 3. 決定的評価基盤の検証範囲で、AIエージェントまたはCIが、評価結果、境界条件、並び順および成果物の再現性を確認する。
- [x] 4. 候補レジストリと初期移行の範囲で、AIエージェントが、候補の恒久的な識別、ライフサイクルおよび既存候補の移行を整備する。
- [x] 5. 公開と画面表示の範囲で、AIエージェントが、追跡可能で原子的な公開、現在状態の管理および `NEW` 表示を整備する。
- [x] 6. 公開と画面表示の検証範囲で、AIエージェントまたはCIが、bootstrap 結果、公開系成果物の再構成、競合時の保護および `NEW` 判定を確認する。
- [x] 7. 外部候補提案境界の範囲で、AIエージェントが、外部LLMとの入出力契約、提案の検証および変更セットの確定処理を整備する。
- [x] 8. 候補更新フローの統合検証範囲で、AIエージェントまたはCIが、fixture を用いた更新から公開までの一連の処理と、既存ローカル生成経路の廃止を確認する。
- [x] 9. リリース判断の範囲で、人間が、受入条件、移行結果および公開影響を確認してcutoverを承認する。
- [x] 10. 作業結果の範囲で、AIエージェントが、実施内容、検証結果および残存する運用上の注意点を記録する。

## Work Notes

- 実装の正本は handoff 内の JSON Schema、evaluation policy、taxonomy、および各 child issue とする。
- 実施順序は Child 1（決定的評価基盤）、Child 2（レジストリ・bootstrap・publication・UI）、Child 3（外部LLM境界）の依存関係に従う。
- 外部LLMのprovider、model、API呼び出しおよび候補発見ロジックは対象外とする。
- Child 2 の完了から Child 3 の完了までは、semantic candidate update を停止し、再構築のみを許可する。
- legacy 187候補は bootstrap 対象であり、初回公開時にも `NEW` として扱わない。
- ベースラインコミットは `f79bc56`（`chore: capture candidate keyword update baseline`）。
- 決定的処理は `package/src/lib/candidate-workflow.js`、更新統合は `package/src/lib/update-flow.js`、atomic promotion は `package/src/lib/publication.js` に実装した。
- `package/src/data/` のbootstrap成果物は187件、推奨度は高42・中11・任意134、初回 `NEW` は0件。`candidate-workflow validate-current` で再構成検証済み。
- fixture proposalによる `full_update` E2Eで、外部LLM呼び出しなしのadd→評価→公開→`introduced_at`確定を検証済み。
- 外部LLM provider/model/API実装は対象外のため実装していない。受入確認とcutover承認は完了した。
- cutover承認済み。承認者: ユーザー、承認日: 2026-08-25、対象コミット: `c0ce13a`。
