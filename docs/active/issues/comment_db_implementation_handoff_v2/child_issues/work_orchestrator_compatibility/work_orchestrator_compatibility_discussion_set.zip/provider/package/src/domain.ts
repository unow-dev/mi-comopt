import { cloneJson, jsonPointer } from "./canonical.js";
import { canTransitionExecution, canTransitionSession, canTransitionTask, transitionExecution, transitionSession, transitionTask } from "./machines.js";
import {
  DomainError,
  type ActorRef,
  type AgentRunResult,
  type CommandEnvelope,
  type DomainCommand,
  type DomainFact,
  type DynamicExpandStep,
  type ExecutionGrant,
  type ExecutionRuntime,
  type JsonValue,
  type Reduction,
  type RuntimeIntent,
  type RuntimeState,
  type ScopeRuntime,
  type Step,
  type TaskProposal,
  type TaskRuntime,
  type TaskStep,
  type WorkerProfile,
  type WorkDefinition,
} from "./contracts.js";
import { findStep } from "./validation.js";

export interface ReducerContext {
  workers: WorkerProfile[];
}

export function createInitialRuntimeState(definition: WorkDefinition, sessionId: string, input: JsonValue): RuntimeState {
  const rootScopeId = `${sessionId}:scope:root`;
  return {
    version: 1,
    revision: 0,
    session: {
      sessionId,
      workDefinitionId: definition.workDefinitionId,
      definitionRevision: definition.revision,
      definitionHash: definition.definitionHash!,
      state: "running",
      input,
      rootScopeId,
    },
    definition,
    scopes: {
      [rootScopeId]: newScope(rootScopeId, definition.root),
    },
    tasks: {},
    executions: {},
    waits: {},
    events: [],
    resultsByStepId: {},
    artifacts: {},
    order: 0,
  };
}

export function reduceCommand(state: RuntimeState, envelope: CommandEnvelope, context: ReducerContext): Reduction {
  try {
    if (envelope.schemaVersion !== 1 || envelope.sessionId !== state.session.sessionId) {
      return rejected(new DomainError("INVALID_COMMAND", "command envelope is invalid"));
    }
    if (state.session.state === "completed" || state.session.state === "cancelled") {
      if (envelope.command.type === "advance") return accepted(state, [], [], { advanced: false }, false);
      return rejected(new DomainError("SESSION_TERMINAL", "terminal Session cannot accept new work"));
    }
    switch (envelope.command.type) {
      case "advance": return reduceAdvance(state, context);
      case "claimTask": return reduceClaim(state, envelope.command.taskId, envelope.actor);
      case "releaseTask": return reduceRelease(state, envelope.command.taskId, envelope.actor);
      case "completeHumanTask": return reduceCompleteHuman(state, envelope.command, envelope.actor);
      case "resumeAgentTask": return reduceResumeAgent(state, envelope.command.taskId);
      case "cancelSession": return reduceCancelSession(state, envelope.command.reason);
      case "receiveExternalEvent": return reduceReceiveEvent(state, envelope.command.event);
      case "timerFired": return reduceTimerFired(state, envelope.command.waitId);
      case "agentResult": return reduceAgentResult(state, envelope.command, context);
      default: return rejected(new DomainError("INVALID_COMMAND", "unsupported command"));
    }
  } catch (error) {
    if (error instanceof DomainError) return rejected(error);
    throw error;
  }
}

function reduceAdvance(state: RuntimeState, context: ReducerContext): Reduction {
  const next = copyState(state);
  const facts: DomainFact[] = [];
  const intents: RuntimeIntent[] = [];
  const changed = advanceWorkflow(next, context, facts, intents);
  return accepted(next, facts, intents, { advanced: changed }, changed);
}

function advanceWorkflow(state: RuntimeState, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  if (state.session.state === "cancelling") {
    return drainCancellation(state, facts);
  }
  if (state.session.state !== "running") return false;
  const rootChanged = visitScope(state, state.session.rootScopeId, context, facts, intents);
  if (!rootChanged) {
    // Intervention Tasks are intentionally outside the business AST and are still
    // processed by this single command processor.
    for (const scope of Object.values(state.scopes)) {
      if (scope.scopeId === state.session.rootScopeId || scope.state !== "active") continue;
      if (visitScope(state, scope.scopeId, context, facts, intents)) return true;
    }
  }
  const root = state.scopes[state.session.rootScopeId];
  if (root.state === "completed" && state.session.state === "running") {
    state.session.state = transitionSession(state.session.state, "ROOT_COMPLETED");
    facts.push(fact("SessionCompleted", state.session.sessionId));
    return true;
  }
  return rootChanged;
}

function visitScope(state: RuntimeState, scopeId: string, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  const scope = state.scopes[scopeId];
  if (!scope || scope.state !== "active") return false;
  const step = scope.generatedTask ?? findStep(state.definition.root, scope.stepId);
  if (!step) throw new DomainError("INVARIANT_VIOLATION", `step ${scope.stepId} not found`);

  if (step.kind === "task") return visitTaskScope(state, scope, step, context, facts, intents);
  if (step.kind === "sequence") return visitSequence(state, scope, step, context, facts, intents);
  if (step.kind === "parallelAll") return visitParallel(state, scope, step, context, facts, intents);
  if (step.kind === "choice") return visitChoice(state, scope, step, context, facts, intents);
  if (step.kind === "waitEvent") return visitEventWait(state, scope, step, facts);
  if (step.kind === "waitTimer") return visitTimerWait(state, scope, step, facts, intents);
  return visitDynamic(state, scope, step, context, facts, intents);
}

function visitTaskScope(state: RuntimeState, scope: ScopeRuntime, step: TaskStep, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  let task = scope.taskId ? state.tasks[scope.taskId] : undefined;
  if (!task) {
    const taskId = `${state.session.sessionId}:task:${scope.scopeId}`;
    task = {
      taskId,
      sessionId: state.session.sessionId,
      scopeId: scope.scopeId,
      stepId: step.id,
      workerKind: step.contract.workerKind,
      goal: step.goal,
      contract: cloneJson(step.contract as unknown as JsonValue) as unknown as typeof step.contract,
      inputs: {
        ...resolveInputs(state, step),
        ...(scope.generatedParameters === undefined ? {} : { proposalParameters: scope.generatedParameters }),
      },
      inputArtifactVersionIds: resolveInputArtifacts(state, step, scope),
      state: "ready",
      acceptedOutputArtifactVersionIds: [],
      generatedOrdinal: scope.generatedOrdinal,
    };
    state.tasks[taskId] = task;
    scope.taskId = taskId;
    facts.push(fact("TaskActivated", taskId, { stepId: step.id, workerKind: step.contract.workerKind }));
    return true;
  }
  if (task.state === "completed" || task.state === "cancelled") {
    scope.state = task.state === "completed" ? "completed" : "cancelled";
    scope.result = task.result ?? null;
    state.resultsByStepId[scope.stepId] = scope.result;
    facts.push(fact(scope.state === "completed" ? "ScopeCompleted" : "ScopeCancelled", scope.scopeId, { result: scope.result }));
    if (task.interventionForTaskId) handleInterventionCompletion(state, task, facts);
    return true;
  }
  if (task.state === "waiting" || task.state === "active" && task.currentExecutionId) return false;
  if (task.workerKind === "human") return false;
  if (state.session.state !== "running") return false;
  const worker = selectWorker(task, context.workers);
  if (!worker) {
    if (task.attention !== "NO_ELIGIBLE_WORKER") {
      task.attention = "NO_ELIGIBLE_WORKER";
      facts.push(fact("TaskAttentionSet", task.taskId, task.attention));
      return true;
    }
    return false;
  }
  dispatchAgent(state, task, worker, facts, intents);
  return true;
}

function visitSequence(state: RuntimeState, scope: ScopeRuntime, step: Extract<Step, { kind: "sequence" }>, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  if (scope.childIds.length === 0 && step.children.length > 0) {
    const child = makeChildScope(state, scope, step.children[0], 0);
    scope.childIds.push(child.scopeId);
    return true;
  }
  if (scope.cursor < scope.childIds.length) {
    const child = state.scopes[scope.childIds[scope.cursor]];
    if (child.state === "active" && visitScope(state, child.scopeId, context, facts, intents)) return true;
    if (child.state === "completed") {
      scope.cursor += 1;
      if (scope.cursor < step.children.length) {
        const nextChild = makeChildScope(state, scope, step.children[scope.cursor], scope.cursor);
        scope.childIds.push(nextChild.scopeId);
      } else {
        scope.state = "completed";
        scope.result = scope.childIds.map((id) => state.scopes[id].result ?? null) as unknown as JsonValue;
        state.resultsByStepId[scope.stepId] = scope.result;
        facts.push(fact("ScopeCompleted", scope.scopeId, { result: scope.result }));
      }
      return true;
    }
    return false;
  }
  scope.state = "completed";
  scope.result = [];
  state.resultsByStepId[scope.stepId] = scope.result;
  return true;
}

function visitParallel(state: RuntimeState, scope: ScopeRuntime, step: Extract<Step, { kind: "parallelAll" }>, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  const branches = Object.entries(step.branches);
  if (scope.childIds.length === 0) {
    for (const [branch, childStep] of branches) {
      const child = makeChildScope(state, scope, childStep, scope.childIds.length);
      child.stepId = childStep.id;
      state.scopes[child.scopeId] = child;
      void branch;
      scope.childIds.push(child.scopeId);
    }
    return true;
  }
  let changed = false;
  for (const childId of scope.childIds) {
    const child = state.scopes[childId];
    if (child.state === "active" && visitScope(state, child.scopeId, context, facts, intents)) changed = true;
  }
  if (changed) return true;
  if (scope.childIds.every((id) => state.scopes[id].state === "completed")) {
    const result: Record<string, JsonValue> = {};
    branches.forEach(([branch, _], index) => { result[branch] = state.scopes[scope.childIds[index]].result ?? null; });
    scope.state = "completed";
    scope.result = result;
    state.resultsByStepId[scope.stepId] = result;
    facts.push(fact("ScopeCompleted", scope.scopeId, { result }));
    return true;
  }
  return false;
}

function visitChoice(state: RuntimeState, scope: ScopeRuntime, step: Extract<Step, { kind: "choice" }>, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  if (!scope.decisionTaskId) {
    const decisionScope = makeChildScope(state, scope, step.decision, 0);
    scope.decisionTaskId = decisionScope.scopeId;
    scope.childIds.push(decisionScope.scopeId);
    return true;
  }
  const decisionScope = state.scopes[scope.decisionTaskId];
  if (decisionScope.state === "active" && visitScope(state, decisionScope.scopeId, context, facts, intents)) return true;
  if (!scope.selectedBranch && decisionScope.state === "completed") {
    const task = decisionScope.taskId ? state.tasks[decisionScope.taskId] : undefined;
    const outcome = task?.outcome;
    if (!outcome || !(outcome in step.branches)) throw new DomainError("OUTCOME_INVALID", "Choice decision did not select a branch");
    scope.selectedBranch = outcome;
    const branch = makeChildScope(state, scope, step.branches[outcome], 1);
    scope.childIds.push(branch.scopeId);
    return true;
  }
  if (scope.selectedBranch) {
    const branch = state.scopes[scope.childIds[1]];
    if (branch.state === "active" && visitScope(state, branch.scopeId, context, facts, intents)) return true;
    if (branch.state === "completed") {
      scope.state = "completed";
      scope.result = branch.result ?? null;
      state.resultsByStepId[scope.stepId] = scope.result;
      facts.push(fact("ScopeCompleted", scope.scopeId, { selectedBranch: scope.selectedBranch, result: scope.result }));
      return true;
    }
  }
  return false;
}

function visitEventWait(state: RuntimeState, scope: ScopeRuntime, step: Extract<Step, { kind: "waitEvent" }>, facts: DomainFact[]): boolean {
  let wait = scope.waitId ? state.waits[scope.waitId] : undefined;
  if (!wait) {
    const waitId = `${state.session.sessionId}:wait:${scope.scopeId}`;
    wait = { waitId, scopeId: scope.scopeId, kind: "event", state: "waiting", eventType: step.eventType, correlationKey: step.correlationKey, createdAtOrder: ++state.order };
    state.waits[waitId] = wait;
    scope.waitId = waitId;
    facts.push(fact("WaitOpened", waitId, { kind: "event", eventType: step.eventType, correlationKey: step.correlationKey }));
    return true;
  }
  if (wait.state === "waiting") {
    const event = state.events.find((candidate) => !candidate.consumedByWaitId && candidate.eventType === step.eventType && candidate.correlationKey === step.correlationKey);
    if (!event) return false;
    event.consumedByWaitId = wait.waitId;
    wait.state = "consumed";
    wait.consumedEventId = event.eventId;
    scope.state = "completed";
    scope.result = event.payload;
    state.resultsByStepId[scope.stepId] = event.payload;
    facts.push(fact("ExternalEventConsumed", event.eventId, { waitId: wait.waitId }));
    return true;
  }
  if (wait.state === "consumed") {
    scope.state = "completed";
    scope.result = scope.result ?? null;
    state.resultsByStepId[scope.stepId] = scope.result;
    return true;
  }
  scope.state = "cancelled";
  return true;
}

function visitTimerWait(state: RuntimeState, scope: ScopeRuntime, step: Extract<Step, { kind: "waitTimer" }>, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  let wait = scope.waitId ? state.waits[scope.waitId] : undefined;
  if (!wait) {
    const waitId = `${state.session.sessionId}:wait:${scope.scopeId}`;
    wait = { waitId, scopeId: scope.scopeId, kind: "timer", state: "waiting", delayMs: step.delayMs, createdAtOrder: ++state.order };
    state.waits[waitId] = wait;
    scope.waitId = waitId;
    intents.push({ kind: "scheduleTimer", waitId, delayMs: step.delayMs });
    facts.push(fact("WaitOpened", waitId, { kind: "timer", delayMs: step.delayMs }));
    return true;
  }
  if (wait.state === "consumed") {
    scope.state = "completed";
    scope.result = null;
    state.resultsByStepId[scope.stepId] = null;
    facts.push(fact("WaitCompleted", wait.waitId));
    return true;
  }
  if (wait.state === "cancelled") {
    scope.state = "cancelled";
    return true;
  }
  return false;
}

function visitDynamic(state: RuntimeState, scope: ScopeRuntime, step: DynamicExpandStep, context: ReducerContext, facts: DomainFact[], intents: RuntimeIntent[]): boolean {
  if (!scope.plannerScopeId) {
    const planner = makeChildScope(state, scope, step.planner, 0);
    scope.plannerScopeId = planner.scopeId;
    scope.childIds.push(planner.scopeId);
    return true;
  }
  const planner = state.scopes[scope.plannerScopeId];
  if (planner.state === "active" && visitScope(state, planner.scopeId, context, facts, intents)) return true;
  if (!scope.proposals && planner.state === "completed") {
    const plannerTask = planner.taskId ? state.tasks[planner.taskId] : undefined;
    const proposals = parseProposals(plannerTask?.result);
    if (proposals.length > step.maxTasks) throw new DomainError("INVALID_COMMAND", "planner returned too many proposals");
    for (const proposal of proposals) for (const artifactId of proposal.inputArtifactVersionIds) {
      if (!state.artifacts[artifactId]) throw new DomainError("ARTIFACT_NOT_FOUND", `planner referenced unknown ArtifactVersion ${artifactId}`);
    }
    const existingGenerated = Object.values(state.tasks).filter((task) => task.generatedOrdinal !== undefined).length;
    const maxForSession = state.definition.limits?.maxDynamicTasksPerSession ?? 100;
    if (existingGenerated + proposals.length > maxForSession) throw new DomainError("INVALID_COMMAND", "dynamic task session budget exceeded");
    scope.proposals = proposals;
    scope.generatedChildIds = [];
    proposals.forEach((proposal, index) => {
      const generatedStep: TaskStep = {
        kind: "task",
        id: `${scope.stepId}:generated:${index}`,
        goal: `${step.proposalPolicy.goalPrefix ?? ""}${proposal.goal}`,
        contract: {
          workerKind: step.proposalPolicy.workerKind,
          requiredCapabilities: [...step.proposalPolicy.requiredCapabilities],
          requestedPermissions: [...step.proposalPolicy.requestedPermissions],
          retryPolicy: { ...step.proposalPolicy.retryPolicy },
          budgets: { ...step.proposalPolicy.budgets },
          allowedOutcomes: step.proposalPolicy.allowedOutcomes ? [...step.proposalPolicy.allowedOutcomes] : undefined,
        },
      };
      const generated = makeChildScope(state, scope, generatedStep, index + 1);
      generated.generatedTask = generatedStep;
      generated.generatedOrdinal = index;
      generated.inputArtifactVersionIds = [...proposal.inputArtifactVersionIds];
      generated.generatedParameters = { type: proposal.type, parameters: proposal.parameters };
      state.scopes[generated.scopeId] = generated;
      scope.generatedChildIds!.push(generated.scopeId);
      scope.childIds.push(generated.scopeId);
    });
    return true;
  }
  const generatedIds = scope.generatedChildIds ?? [];
  if (step.strategy === "sequence") {
    const index = Math.max(0, scope.cursor);
    if (index < generatedIds.length) {
      const child = state.scopes[generatedIds[index]];
      if (child.state === "active" && visitScope(state, child.scopeId, context, facts, intents)) return true;
      if (child.state === "completed") {
        scope.cursor += 1;
        return true;
      }
      return false;
    }
  } else {
    let changed = false;
    for (const childId of generatedIds) {
      const child = state.scopes[childId];
      if (child.state === "active" && visitScope(state, child.scopeId, context, facts, intents)) changed = true;
    }
    if (changed) return true;
  }
  if (generatedIds.every((id) => state.scopes[id].state === "completed")) {
    scope.state = "completed";
    scope.result = generatedIds.map((id) => state.scopes[id].result ?? null) as unknown as JsonValue;
    state.resultsByStepId[scope.stepId] = scope.result;
    facts.push(fact("ScopeCompleted", scope.scopeId, { result: scope.result }));
    return true;
  }
  return false;
}

function reduceClaim(state: RuntimeState, taskId: string, actor: ActorRef): Reduction {
  const next = copyState(state);
  const task = requireTask(next, taskId);
  if (task.workerKind !== "human" || task.state !== "ready") throw new DomainError("INVALID_STATE", "Human Task is not ready to claim");
  task.state = transitionTask(task.state, "CLAIM");
  task.claimantActorId = actor.actorId;
  const execution = createHumanExecution(next, task);
  task.currentExecutionId = execution.executionId;
  return accepted(next, [fact("HumanTaskClaimed", taskId, { actorId: actor.actorId, executionId: execution.executionId })], [], { taskId, executionId: execution.executionId });
}

function reduceRelease(state: RuntimeState, taskId: string, actor: ActorRef): Reduction {
  const next = copyState(state);
  const task = requireTask(next, taskId);
  if (task.workerKind !== "human" || task.state !== "active" || task.claimantActorId !== actor.actorId) throw new DomainError("NOT_CLAIM_OWNER", "only the current claimant can release the Task");
  const execution = requireCurrentExecution(next, task);
  execution.state = transitionExecution(execution.state, "CANCEL_ACKNOWLEDGED");
  task.state = transitionTask(task.state, "RELEASE");
  task.currentExecutionId = undefined;
  task.claimantActorId = undefined;
  return accepted(next, [fact("HumanExecutionCancelled", execution.executionId), fact("HumanTaskReleased", taskId)], [], { taskId, executionId: execution.executionId });
}

function reduceCompleteHuman(state: RuntimeState, command: Extract<DomainCommand, { type: "completeHumanTask" }>, actor: ActorRef): Reduction {
  const next = copyState(state);
  const task = requireTask(next, command.taskId);
  if (task.workerKind !== "human" || task.state !== "active" || task.claimantActorId !== actor.actorId) throw new DomainError("NOT_CLAIM_OWNER", "only the current claimant can complete the Task");
  validateOutcome(task, command.outcome);
  validateResult(task.contract.resultSchema, command.result ?? null);
  const execution = requireCurrentExecution(next, task);
  execution.state = transitionExecution(execution.state, "SUCCEED");
  execution.result = command.result ?? null;
  task.state = transitionTask(task.state, "COMPLETE");
  task.currentExecutionId = undefined;
  task.claimantActorId = undefined;
  task.outcome = command.outcome;
  task.result = command.result ?? null;
  const facts = [fact("HumanExecutionSucceeded", execution.executionId), fact("TaskCompleted", task.taskId, { outcome: command.outcome ?? null })];
  const intents: RuntimeIntent[] = [];
  if (task.interventionForTaskId) handleInterventionCompletion(next, task, facts, intents);
  return accepted(next, facts, intents, { taskId: task.taskId, state: task.state, outcome: command.outcome ?? null });
}

function reduceResumeAgent(state: RuntimeState, taskId: string): Reduction {
  const next = copyState(state);
  const task = requireTask(next, taskId);
  if (task.workerKind !== "agent") throw new DomainError("INVALID_STATE", "only Agent Tasks can be resumed");
  if (task.state === "ready" && task.attention === "NO_ELIGIBLE_WORKER") {
    task.attention = undefined;
    return accepted(next, [fact("AgentTaskResumed", taskId)], [], { taskId, resumed: true });
  }
  if (task.state === "waiting" && task.contract.retryPolicy.manualRetryAllowed) {
    task.state = transitionTask(task.state, "REDISPATCH");
    task.attention = undefined;
    return accepted(next, [fact("AgentTaskResumed", taskId)], [], { taskId, resumed: true });
  }
  throw new DomainError("MANUAL_RETRY_NOT_ALLOWED", "Agent Task cannot be resumed in its current policy/state");
}

function reduceCancelSession(state: RuntimeState, reason: string | undefined): Reduction {
  const next = copyState(state);
  if (state.session.state === "cancelling") return accepted(next, [], [], { sessionId: state.session.sessionId, state: "cancelling" }, false);
  next.session.state = transitionSession(next.session.state, "CANCEL_REQUESTED");
  next.session.attention = reason;
  const facts: DomainFact[] = [fact("SessionCancellationRequested", next.session.sessionId, reason ? { reason } : undefined)];
  const intents: RuntimeIntent[] = [];
  beginCancellation(next, facts, intents);
  return accepted(next, facts, intents, { sessionId: next.session.sessionId, state: next.session.state });
}

function reduceReceiveEvent(state: RuntimeState, event: Extract<DomainCommand, { type: "receiveExternalEvent" }>["event"]): Reduction {
  const next = copyState(state);
  if (next.events.some((candidate) => candidate.eventId === event.eventId)) return accepted(next, [], [], { eventId: event.eventId, duplicate: true }, false);
  const maxEvents = next.definition.limits?.maxBufferedExternalEvents ?? 100;
  if (next.events.filter((candidate) => !candidate.consumedByWaitId).length >= maxEvents) throw new DomainError("EVENT_BUFFER_FULL", "external event buffer is full");
  next.events.push({ ...event, acceptedOrder: ++next.order });
  return accepted(next, [fact("ExternalEventBuffered", event.eventId, { eventType: event.eventType, correlationKey: event.correlationKey })], [], { eventId: event.eventId, buffered: true });
}

function reduceTimerFired(state: RuntimeState, waitId: string): Reduction {
  const next = copyState(state);
  const wait = next.waits[waitId];
  if (!wait) throw new DomainError("WAIT_NOT_FOUND", `Wait ${waitId} not found`);
  if (wait.kind !== "timer" || wait.state !== "waiting") throw new DomainError("INVALID_STATE", "timer is not waiting");
  wait.state = "consumed";
  return accepted(next, [fact("TimerFired", waitId)], [], { waitId, fired: true });
}

function reduceAgentResult(state: RuntimeState, command: Extract<DomainCommand, { type: "agentResult" }>, context: ReducerContext): Reduction {
  const next = copyState(state);
  const execution = next.executions[command.executionId];
  if (!execution) throw new DomainError("INVALID_STATE", `Execution ${command.executionId} not found`);
  if (execution.state !== "running") return accepted(next, [], [], { executionId: execution.executionId, duplicate: true }, false);
  const task = requireTask(next, execution.taskId);
  const intents: RuntimeIntent[] = [];
  const event = command.status === "succeeded" ? "SUCCEED" : command.status === "failed" ? "FAIL" : command.status === "cancelled" ? "CANCEL_ACKNOWLEDGED" : "ABANDON";
  execution.state = transitionExecution(execution.state, event);
  execution.result = command.result;
  execution.failure = command.failure;
  task.currentExecutionId = undefined;
  const facts: DomainFact[] = [fact(`AgentExecution${capitalize(command.status)}`, execution.executionId, command.failure)];
  if (command.artifactVersions) {
    for (const artifact of command.artifactVersions) {
      if (artifact.origin.kind !== "execution" || artifact.origin.executionId !== execution.executionId) throw new DomainError("INVARIANT_VIOLATION", "Artifact provenance does not match Execution");
      if (next.artifacts[artifact.artifactVersionId] && JSON.stringify(next.artifacts[artifact.artifactVersionId]) !== JSON.stringify(artifact)) throw new DomainError("INVARIANT_VIOLATION", "ArtifactVersion is immutable");
      next.artifacts[artifact.artifactVersionId] = artifact;
      execution.producedArtifactVersionIds.push(artifact.artifactVersionId);
    }
  }
  const cancelledByIntent = next.session.state === "cancelling" || execution.cancellationRequested;
  if (command.status === "succeeded" && !cancelledByIntent) {
    validateResult(task.contract.resultSchema, command.result ?? null);
    validateAgentOutcome(task, command.result);
    task.state = transitionTask(task.state, "COMPLETE");
    task.result = command.result ?? null;
    task.acceptedOutputArtifactVersionIds = [...execution.producedArtifactVersionIds];
    facts.push(fact("TaskCompleted", task.taskId, { outputArtifactVersionIds: task.acceptedOutputArtifactVersionIds }));
  } else if (cancelledByIntent) {
    if (task.state === "active") task.state = transitionTask(task.state, "CANCEL");
    task.attention = command.status === "abandoned" ? "EXECUTION_ABANDONED_DURING_CANCELLATION" : "CANCELLED_BEFORE_AGENT_RESULT";
    facts.push(fact("TaskCancelled", task.taskId));
  } else if (command.status === "failed" || command.status === "cancelled" || command.status === "abandoned") {
    const nextAttempt = execution.attempt + 1;
    const worker = task.state === "active" ? selectWorker(task, context.workers) : undefined;
    if (command.status === "failed" && nextAttempt <= task.contract.retryPolicy.maxAttempts && worker) {
      dispatchAgent(next, task, worker, facts, intents);
      facts.push(fact("AgentRetryScheduled", task.taskId, { failedExecutionId: execution.executionId, attempt: nextAttempt }));
    } else {
      if (task.state === "active") task.state = transitionTask(task.state, "BLOCK");
      task.attention = command.status === "abandoned" ? "EXECUTION_ABANDONED" : "RETRY_EXHAUSTED";
      facts.push(fact("TaskBlocked", task.taskId, task.attention));
      if (task.contract.retryPolicy.interventionOnExhaustion !== false) createIntervention(next, task, facts);
    }
  }
  if (next.session.state === "cancelling" && !Object.values(next.executions).some((item) => item.state === "running")) {
    cancelCompletedScopes(next);
    next.session.state = transitionSession(next.session.state, "CANCELLATION_DRAINED");
    facts.push(fact("SessionCancelled", next.session.sessionId));
  }
  return accepted(next, facts, intents, { executionId: execution.executionId, state: execution.state, taskState: task.state });
}

function drainCancellation(state: RuntimeState, facts: DomainFact[]): boolean {
  let changed = false;
  for (const scope of Object.values(state.scopes)) {
    if (scope.state === "active") {
      const task = scope.taskId ? state.tasks[scope.taskId] : undefined;
      if (task?.state === "cancelled" || (scope.waitId && state.waits[scope.waitId]?.state === "cancelled")) {
        scope.state = "cancelled";
        changed = true;
      }
    }
  }
  if (!Object.values(state.executions).some((execution) => execution.state === "running") && state.session.state === "cancelling") {
    state.session.state = transitionSession(state.session.state, "CANCELLATION_DRAINED");
    facts.push(fact("SessionCancelled", state.session.sessionId));
    changed = true;
  }
  return changed;
}

function handleInterventionCompletion(state: RuntimeState, intervention: TaskRuntime, facts: DomainFact[], intents: RuntimeIntent[] = []): void {
  const original = intervention.interventionForTaskId ? state.tasks[intervention.interventionForTaskId] : undefined;
  if (!original) return;
  if (intervention.outcome === "manual_retry" && original.state === "waiting") {
    original.state = transitionTask(original.state, "REDISPATCH");
    original.attention = undefined;
    facts.push(fact("AgentTaskManuallyResumed", original.taskId));
  } else if (intervention.outcome === "cancel_session" && state.session.state === "running") {
    state.session.state = transitionSession(state.session.state, "CANCEL_REQUESTED");
    original.attention = "CANCELLED_BY_INTERVENTION";
    facts.push(fact("SessionCancellationRequested", state.session.sessionId));
    beginCancellation(state, facts, intents);
  }
}

function beginCancellation(state: RuntimeState, facts: DomainFact[], intents: RuntimeIntent[]): void {
  for (const task of Object.values(state.tasks)) {
    if (task.state === "ready" || task.state === "waiting") {
      task.state = transitionTask(task.state, "CANCEL");
      facts.push(fact("TaskCancelled", task.taskId));
    } else if (task.state === "active") {
      const execution = task.currentExecutionId ? state.executions[task.currentExecutionId] : undefined;
      if (execution?.state === "running" && task.workerKind === "agent") {
        execution.cancellationRequested = true;
        intents.push({ kind: "cancelAgent", executionId: execution.executionId });
      } else if (execution?.state === "running") {
        execution.state = transitionExecution(execution.state, "CANCEL_ACKNOWLEDGED");
        task.state = transitionTask(task.state, "CANCEL");
        task.currentExecutionId = undefined;
        task.claimantActorId = undefined;
        facts.push(fact("TaskCancelled", task.taskId));
      } else {
        task.state = transitionTask(task.state, "CANCEL");
      }
    }
  }
  for (const wait of Object.values(state.waits)) if (wait.state === "waiting") wait.state = "cancelled";
  cancelCompletedScopes(state);
  if (!Object.values(state.executions).some((execution) => execution.state === "running") && state.session.state === "cancelling") {
    state.session.state = transitionSession(state.session.state, "CANCELLATION_DRAINED");
    facts.push(fact("SessionCancelled", state.session.sessionId));
  }
}

function cancelCompletedScopes(state: RuntimeState): void {
  for (let pass = 0; pass < Object.keys(state.scopes).length + 1; pass += 1) {
    let changed = false;
    for (const scope of Object.values(state.scopes)) {
      if (scope.state !== "active") continue;
      const task = scope.taskId ? state.tasks[scope.taskId] : undefined;
      const wait = scope.waitId ? state.waits[scope.waitId] : undefined;
      if (task?.state === "cancelled" || wait?.state === "cancelled" || (scope.childIds.length > 0 && scope.childIds.every((id) => state.scopes[id]?.state === "cancelled"))) {
        scope.state = "cancelled";
        changed = true;
      }
    }
    if (!changed) break;
  }
}

function createIntervention(state: RuntimeState, blocked: TaskRuntime, facts: DomainFact[]): void {
  if (Object.values(state.tasks).some((task) => task.interventionForTaskId === blocked.taskId && task.state !== "cancelled" && task.state !== "completed")) return;
  const index = Object.values(state.tasks).filter((task) => task.interventionForTaskId === blocked.taskId).length;
  const scopeId = `${blocked.taskId}:intervention-scope:${index}`;
  const taskId = `${blocked.taskId}:intervention:${index}`;
  const step: TaskStep = {
    kind: "task",
    id: `${blocked.stepId}:intervention:${index}`,
    goal: `Intervene for ${blocked.goal}`,
    contract: {
      workerKind: "human",
      requiredCapabilities: [],
      requestedPermissions: [],
      retryPolicy: { maxAttempts: 1 },
      budgets: { maxWallTimeMs: 24 * 60 * 60 * 1000 },
      allowedOutcomes: ["manual_retry", "cancel_session"],
    },
  };
  state.scopes[scopeId] = { ...newScope(scopeId, step), generatedTask: step };
  state.tasks[taskId] = {
    taskId,
    sessionId: state.session.sessionId,
    scopeId,
    stepId: step.id,
    workerKind: "human",
    goal: step.goal,
    contract: step.contract,
    inputs: {},
    state: "ready",
    interventionForTaskId: blocked.taskId,
    acceptedOutputArtifactVersionIds: [],
    inputArtifactVersionIds: [],
  };
  state.scopes[scopeId].taskId = taskId;
  facts.push(fact("HumanInterventionTaskCreated", taskId, { blockedTaskId: blocked.taskId }));
}

function dispatchAgent(state: RuntimeState, task: TaskRuntime, worker: WorkerProfile, facts: DomainFact[], intents: RuntimeIntent[]): void {
  if (task.state === "ready") task.state = transitionTask(task.state, "DISPATCH");
  else if (task.state === "waiting") task.state = transitionTask(task.state, "REDISPATCH");
  const attempt = Math.max(0, ...Object.values(state.executions).filter((execution) => execution.taskId === task.taskId).map((execution) => execution.attempt)) + 1;
  const executionId = `${task.taskId}:execution:${attempt}`;
  const grant: ExecutionGrant = {
    workerId: worker.workerId,
    workerRevision: worker.revision,
    capabilities: [...task.contract.requiredCapabilities],
    permissions: [...task.contract.requestedPermissions],
    budgets: { ...task.contract.budgets },
  };
  const execution: ExecutionRuntime = {
    executionId,
    taskId: task.taskId,
    attempt,
    workerId: worker.workerId,
    workerRevision: worker.revision,
    grant,
    state: "running",
    producedArtifactVersionIds: [],
    startedAtOrder: ++state.order,
  };
  state.executions[executionId] = execution;
  task.currentExecutionId = executionId;
  task.attention = undefined;
  facts.push(fact("AgentExecutionStarted", executionId, { workerId: worker.workerId, workerRevision: worker.revision, grant: grant as unknown as JsonValue }));
  intents.push({ kind: "dispatchAgent", executionId });
}

function createHumanExecution(state: RuntimeState, task: TaskRuntime): ExecutionRuntime {
  const attempt = Math.max(0, ...Object.values(state.executions).filter((execution) => execution.taskId === task.taskId).map((execution) => execution.attempt)) + 1;
  const execution: ExecutionRuntime = {
    executionId: `${task.taskId}:execution:${attempt}`,
    taskId: task.taskId,
    attempt,
    state: "running",
    producedArtifactVersionIds: [],
    startedAtOrder: ++state.order,
  };
  state.executions[execution.executionId] = execution;
  return execution;
}

function makeChildScope(state: RuntimeState, parent: ScopeRuntime, step: Step, ordinal: number): ScopeRuntime {
  const scopeId = `${parent.scopeId}:child:${ordinal}:${step.id}`;
  const child = newScope(scopeId, step);
  child.generatedOrdinal = step.kind === "task" && step.id.includes(":generated:") ? ordinal - 1 : undefined;
  state.scopes[scopeId] = child;
  return child;
}

function newScope(scopeId: string, step: Step): ScopeRuntime {
  return { scopeId, stepId: step.id, kind: step.kind, state: "active", childIds: [], cursor: 0 };
}

function resolveInputs(state: RuntimeState, step: TaskStep): Record<string, JsonValue> {
  const result: Record<string, JsonValue> = {};
  for (const [name, binding] of Object.entries(step.inputBindings ?? {})) {
    const source = binding.source === "session" ? state.session.input : state.resultsByStepId[binding.stepId!];
    const value = jsonPointer(source ?? null, binding.path);
    if (value === undefined) throw new DomainError("INVALID_COMMAND", `input binding ${name} could not be resolved`);
    result[name] = value;
  }
  return result;
}

function resolveInputArtifacts(state: RuntimeState, step: TaskStep, scope: ScopeRuntime): string[] {
  const ids = new Set(scope.inputArtifactVersionIds ?? []);
  for (const binding of Object.values(step.inputBindings ?? {})) {
    if (binding.source !== "step" || !binding.stepId) continue;
    for (const task of Object.values(state.tasks)) {
      if (task.stepId === binding.stepId) for (const artifactId of task.acceptedOutputArtifactVersionIds) ids.add(artifactId);
    }
  }
  return [...ids];
}

function selectWorker(task: TaskRuntime, workers: WorkerProfile[]): WorkerProfile | undefined {
  return workers.filter((worker) => worker.enabled)
    .filter((worker) => task.contract.requiredCapabilities.every((capability) => worker.capabilities.includes(capability)))
    .filter((worker) => task.contract.requestedPermissions.every((permission) => worker.enforceablePermissions.includes(permission)))
    .filter((worker) => Object.entries(task.contract.budgets).every(([budget, value]) => value === undefined || budget === "maxWallTimeMs" || worker.enforceableBudgets.includes(budget)))
    .sort((left, right) => left.routingPriority - right.routingPriority || left.workerId.localeCompare(right.workerId))[0];
}

function requireTask(state: RuntimeState, taskId: string): TaskRuntime {
  const task = state.tasks[taskId];
  if (!task) throw new DomainError("TASK_NOT_FOUND", `Task ${taskId} not found`);
  return task;
}

function requireCurrentExecution(state: RuntimeState, task: TaskRuntime): ExecutionRuntime {
  if (!task.currentExecutionId) throw new DomainError("INVALID_STATE", "Task has no current Execution");
  const execution = state.executions[task.currentExecutionId];
  if (!execution || execution.state !== "running") throw new DomainError("INVALID_STATE", "Task does not have a running Execution");
  return execution;
}

function validateOutcome(task: TaskRuntime, outcome: string | undefined): void {
  const allowed = task.contract.allowedOutcomes;
  if (!allowed && outcome !== undefined) throw new DomainError("OUTCOME_INVALID", "Task Contract does not allow an outcome");
  if (allowed && (outcome === undefined || !allowed.includes(outcome))) throw new DomainError("OUTCOME_INVALID", `outcome ${outcome ?? "<missing>"} is not allowed`);
}

function validateAgentOutcome(task: TaskRuntime, result: JsonValue | undefined): void {
  const outcome = result && typeof result === "object" && !Array.isArray(result) && typeof result.outcome === "string" ? result.outcome : undefined;
  if (!task.contract.allowedOutcomes) {
    if (outcome !== undefined) throw new DomainError("OUTCOME_INVALID", "Task Contract does not allow an outcome");
    return;
  }
  validateOutcome(task, outcome);
  task.outcome = outcome;
}

function validateResult(schema: JsonValue | undefined, value: JsonValue): void {
  if (schema === undefined) return;
  if (!matchesSchema(schema, value)) throw new DomainError("OUTCOME_INVALID", "Task result does not satisfy its result schema");
}

function matchesSchema(schema: JsonValue, value: JsonValue): boolean {
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) return false;
  const definition = schema as Record<string, JsonValue>;
  const type = definition.type;
  if (typeof type === "string") {
    const valid = type === "null" ? value === null
      : type === "array" ? Array.isArray(value)
        : type === "object" ? value !== null && typeof value === "object" && !Array.isArray(value)
          : type === "integer" ? typeof value === "number" && Number.isInteger(value)
            : typeof value === type;
    if (!valid) return false;
  }
  if (Array.isArray(definition.enum) && !definition.enum.some((candidate) => JSON.stringify(candidate) === JSON.stringify(value))) return false;
  if (Array.isArray(value)) return definition.items === undefined || value.every((item) => matchesSchema(definition.items!, item));
  if (value !== null && typeof value === "object") {
    const required = Array.isArray(definition.required) ? definition.required : [];
    if (required.some((key) => typeof key !== "string" || !(key in value))) return false;
    const properties = definition.properties;
    if (properties && typeof properties === "object" && !Array.isArray(properties)) {
      for (const [key, child] of Object.entries(properties)) if (key in value && !matchesSchema(child, (value as Record<string, JsonValue>)[key])) return false;
    }
  }
  return true;
}

function parseProposals(result: JsonValue | undefined): TaskProposal[] {
  if (!Array.isArray(result)) throw new DomainError("INVALID_COMMAND", "Dynamic planner result must be an array");
  return result.map((item, index) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) throw new DomainError("INVALID_COMMAND", `proposal ${index} is not an object`);
    const proposal = item as Record<string, JsonValue | undefined>;
    if (typeof proposal.type !== "string" || typeof proposal.goal !== "string" || !Array.isArray(proposal.inputArtifactVersionIds) || proposal.parameters === undefined) {
      throw new DomainError("INVALID_COMMAND", `proposal ${index} has invalid shape`);
    }
    if (!proposal.inputArtifactVersionIds.every((id) => typeof id === "string")) throw new DomainError("INVALID_COMMAND", `proposal ${index} has invalid artifact references`);
    return {
      type: proposal.type,
      goal: proposal.goal,
      inputArtifactVersionIds: proposal.inputArtifactVersionIds as string[],
      parameters: proposal.parameters,
    };
  });
}

function copyState(state: RuntimeState): RuntimeState {
  return cloneJson(state as unknown as JsonValue) as unknown as RuntimeState;
}

function accepted(state: RuntimeState, facts: DomainFact[], intents: RuntimeIntent[], response: JsonValue, advanceRevision = true): Reduction {
  const next = copyState(state);
  if (advanceRevision) next.revision += 1;
  return { kind: "accepted", nextState: next, facts, intents, response, advanceRevision };
}

function rejected(error: DomainError): Reduction {
  return { kind: "rejected", error, response: { ok: false, error: { code: error.code, message: error.message } } };
}

function fact(type: string, entityId: string, data?: JsonValue): DomainFact {
  return data === undefined ? { type, entityId } : { type, entityId, data };
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
