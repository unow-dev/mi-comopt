import { randomUUID } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sha256 } from "./canonical.js";
import { DomainError } from "./contracts.js";

export interface StagedBlob {
  stageId: string;
  blobHash: string;
  size: number;
  mediaType: string;
  temporaryPath: string;
}

/** content-addressed immutable blob store。ArtifactVersion の来歴は Registry が保持する。 */
export class ArtifactStore {
  readonly root: string;
  private readonly orphaned = new Map<string, number>();

  constructor(root = join(tmpdir(), `work-orchestrator-artifacts-${randomUUID()}`)) {
    this.root = root;
    mkdirSync(join(root, "blobs"), { recursive: true });
    mkdirSync(join(root, "staging"), { recursive: true });
  }

  stage(content: string | Uint8Array, mediaType = "application/octet-stream"): StagedBlob {
    const bytes = typeof content === "string" ? Buffer.from(content) : Buffer.from(content);
    const blobHash = sha256(bytes);
    const stageId = randomUUID();
    const temporaryPath = join(this.root, "staging", stageId);
    writeFileSync(temporaryPath, bytes, { flag: "wx" });
    const fd = openSync(temporaryPath, "r");
    try {
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    this.orphaned.set(temporaryPath, Date.now());
    return { stageId, blobHash, size: bytes.byteLength, mediaType, temporaryPath };
  }

  finalize(stage: StagedBlob): void {
    if (!existsSync(stage.temporaryPath)) throw new DomainError("ARTIFACT_NOT_FOUND", `staged blob ${stage.stageId} not found`);
    const content = readFileSync(stage.temporaryPath);
    if (sha256(content) !== stage.blobHash || content.byteLength !== stage.size) throw new DomainError("INVARIANT_VIOLATION", "staged blob digest or size mismatch");
    const target = this.blobPath(stage.blobHash);
    if (existsSync(target)) {
      unlinkSync(stage.temporaryPath);
    } else {
      renameSync(stage.temporaryPath, target);
    }
    this.orphaned.delete(stage.temporaryPath);
  }

  hasBlob(blobHash: string): boolean {
    return existsSync(this.blobPath(blobHash));
  }

  read(blobHash: string): Buffer {
    if (!this.hasBlob(blobHash)) throw new DomainError("ARTIFACT_NOT_FOUND", `blob ${blobHash} not found`);
    return readFileSync(this.blobPath(blobHash));
  }

  gcOrphans(gracePeriodMs = 60 * 60 * 1000, now = Date.now()): string[] {
    const removed: string[] = [];
    for (const path of readdirSync(join(this.root, "staging"))) {
      const fullPath = join(this.root, "staging", path);
      const age = this.orphaned.get(fullPath) ?? statSync(fullPath).mtimeMs;
      if (now - age >= gracePeriodMs) {
        unlinkSync(fullPath);
        this.orphaned.delete(fullPath);
        removed.push(fullPath);
      }
    }
    return removed;
  }

  blobPath(blobHash: string): string {
    if (!/^[a-f0-9]{64}$/.test(blobHash)) throw new DomainError("ARTIFACT_NOT_FOUND", "invalid blob hash");
    return join(this.root, "blobs", blobHash);
  }
}
