# Work Orchestrator v1

Work Orchestrator は、`WorkDefinition` を実行可能な Task / Execution / Wait に展開し、Human Task、Agent Task、外部イベント、timer、成果物、監査履歴を一つの実行モデルで扱う Node.js パッケージです。

詳細な利用方法と API 仕様は `docs/` にまとめています。

- [導入ガイド](./docs/README.md) — ローカル package の build/install、Human Task Quickstart、永続化、Agent、Temporal-backed execution
- [API Reference](./docs/API_REFERENCE.md) — 主要 API の使い分け、契約、root export の完全索引

最初に利用する場合は [導入ガイド](./docs/README.md) から進めてください。
