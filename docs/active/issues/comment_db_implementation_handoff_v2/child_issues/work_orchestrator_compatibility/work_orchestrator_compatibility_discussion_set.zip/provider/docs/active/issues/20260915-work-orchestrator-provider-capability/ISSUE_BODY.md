# Work Orchestrator Provider Capability

## Purpose

`work-orchestrator/package` の公開契約と runtime が、Comment DB workflow に必要な動的 deployment event 相関、即時終端、Choice の結果可視性を正確に表現し、Consumer の WorkDefinition を安全に検証・登録できる状態にする。

## Background

Comment DB State Management / Workflow Handoff v2 では、deployment trigger の結果に応じて `deploymentRequestId` を相関キーとして deployment event を待ち、event の成功後も独立した verify と Deployment State の記録を行う workflow が定義されている。異なる deployment の event を消費しないこと、duplicate event を冪等に扱うこと、failed/cancelled event と recovery deployment を区別することが必要である。

一方、現行 Provider package（revision `b504699`、package version `0.0.0`）には次の表現力上の差分がある。

- `WaitEventStep.correlationKey` が固定 `string` であり、Session または先行 Task の結果から deployment ごとの値を解決できない。
- runtime が定義上の固定 `correlationKey` と event の値を比較しており、wait 開始時に解決した相関値を immutable に保持する契約がない。
- 空の `Sequence` が validator で拒否され、不要な Task・Human Task・外部処理を実行せずに終わる terminal branch を表現できない。
- Choice の decision Task は必須である一方、validator が branch 内の input binding から decision の結果を参照できる visibility を提供していない。

Consumer 側で静的な相関値、ワイルドカード、共通 request ID へ置換すると deployment event の isolation と recovery 境界を壊すため、Provider の公開契約・validator・runtime を業務要件に適合させる必要がある。

## Scope

- 動的な deployment event correlation の公開契約、解決、wait state の immutable 保持および event isolation
- duplicate event、failed/cancelled event、already-deployed、recovery deployment の実行意味論
- terminal branch の即時完了と不要な実行・再試行の抑止
- Choice decision outcome、branch input visibility、validator と runtime result の整合
- 公開 root export、型宣言、canonical hash、validator、runtime、Registry、Temporal 境界および配布対象 `dist`
- Consumer から `comment-data-update` と `deploy-promoted-release` の2つの WorkDefinition を検証・登録する連携確認

## Acceptance Criteria

- Session または先行 Task の値から deployment event の correlation を解決できる。
- 解決済み correlation は wait の存続中に暗黙変更されず、異なる deployment の event を消費しない。
- duplicate event は重複した Deployment Version / Transition を作らず、failed/cancelled event は Promotion を維持したまま Deployment State を進めない。
- already-deployed は event wait を不要に再実行せず、独立した verify と必要な記録へ正しく進む。recovery deployment は先行する業務工程を再実行しない。
- terminal branch は不要な Task、Human Task、外部処理および再試行を実行せず、所定の branch result と Session 状態へ到達する。
- Choice の decision outcome と branch key が一致し、branch 内の input binding から公開された visibility 契約に従って decision 結果を参照できる。
- 上記の意味論が公開型、validator、canonical hash、runtime、Registry / Temporal 実行境界で一貫している。
- 既存 v1 の受入テストを維持したうえで、Provider package の typecheck、build、unit / acceptance test および配布対象 `dist` の検証が成功する。
- Consumer 側で2つの WorkDefinition が `validateAndHashDefinition()` を通過し、`WorkOrchestrator.registerDefinition()` により登録できる。
- 同一 `(workDefinitionId, revision)` の登録は immutable であり、canonical definition が変わった場合は再利用されない。

## Dependencies

- `tiktok-filter-keywords` 側の Consumer Compatibility issue における Definition builder、input binding、routing outcome および snapshot の整理
- 動的 correlation、terminal、Choice visibility の後方互換性と公開契約についての人間による仕様判断
- Comment DB Handoff v2 の normative workflow、application service、deployment event および acceptance contract

## Out of Scope

- `tiktok-filter-keywords` 側の WorkDefinition builder と compatibility adapter の実装
- Comment DB の State Control Plane、Application Service、DB schema / migration の実装
- Comment DB の business authoritative state を Work Orchestrator Registry に保存すること
- Classification / Keyword Selection の human cutover 判断

## References

- Source issue: `/home/uya/Workspace/tiktok-filter-keywords/docs/active/issues/comment_db_implementation_handoff_v2/child_issues/work_orchestrator_provider_capability/ISSUE_BODY.md`
- Workflow contract: `/home/uya/Workspace/tiktok-filter-keywords/docs/active/issues/comment_db_implementation_handoff_v2/02_WORK_ORCHESTRATOR_FLOW.md`
- Acceptance matrix: `/home/uya/Workspace/tiktok-filter-keywords/docs/active/issues/comment_db_implementation_handoff_v2/05_ACCEPTANCE_TESTS.md`
- Compatibility gap analysis: `/home/uya/Workspace/tiktok-filter-keywords/docs/active/issues/comment_db_implementation_handoff_v2/WORK_ORCHESTRATOR_COMPATIBILITY_GAP.md`
- Existing Provider contract: [Work Orchestration v1 implementation handoff](../first-implementation/work-orchestration-implementation-handoff-v1/01-IMPLEMENTATION-SPEC-v1.md)
