import { DatabaseSync } from "node:sqlite";
import { canonicalJson, hashJson, sha256 } from "./canonical.js";
import { DomainError } from "./contracts.js";
import type {
  CommandEnvelope,
  DomainCommit,
  DomainFact,
  JsonValue,
  Reduction,
  RuntimeState,
  WorkDefinition,
} from "./contracts.js";

interface ReceiptRow {
  session_id: string;
  command_id: string;
  request_hash: string;
  accepted: number;
  resulting_revision: number | null;
  response_json: string;
}

export interface CommitResult {
  response: JsonValue;
  duplicate: boolean;
  resultingRevision: number | null;
}

export interface RegistryOptions {
  readOnly?: boolean;
}

const MIGRATIONS: readonly { version: number; sql: string }[] = [
  {
    version: 1,
    sql: `
      CREATE TABLE IF NOT EXISTS work_definitions (
        work_definition_id TEXT NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 0),
        definition_hash TEXT NOT NULL,
        schema_version INTEGER NOT NULL,
        definition_json TEXT NOT NULL,
        PRIMARY KEY (work_definition_id, revision),
        UNIQUE (work_definition_id, revision, definition_hash)
      );
      CREATE TABLE IF NOT EXISTS work_sessions (
        session_id TEXT PRIMARY KEY,
        work_definition_id TEXT NOT NULL,
        definition_revision INTEGER NOT NULL,
        definition_hash TEXT NOT NULL,
        state TEXT NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 0),
        runtime_snapshot_json TEXT NOT NULL,
        state_hash TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS command_receipts (
        session_id TEXT NOT NULL,
        command_id TEXT NOT NULL,
        request_hash TEXT NOT NULL,
        accepted INTEGER NOT NULL,
        resulting_revision INTEGER,
        response_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (session_id, command_id),
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS domain_commits (
        session_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        command_id TEXT NOT NULL,
        command_type TEXT NOT NULL,
        facts_json TEXT NOT NULL,
        resulting_state_hash TEXT NOT NULL,
        PRIMARY KEY (session_id, revision),
        UNIQUE (session_id, command_id),
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS scope_instances (
        scope_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        step_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        state TEXT NOT NULL,
        result_json TEXT,
        child_ids_json TEXT NOT NULL,
        cursor INTEGER NOT NULL,
        runtime_json TEXT NOT NULL,
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS tasks (
        task_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        scope_id TEXT NOT NULL,
        step_id TEXT NOT NULL,
        worker_kind TEXT NOT NULL,
        goal TEXT NOT NULL,
        contract_json TEXT NOT NULL,
        inputs_json TEXT NOT NULL,
        state TEXT NOT NULL,
        current_execution_id TEXT,
        claimant_actor_id TEXT,
        outcome TEXT,
        result_json TEXT,
        attention TEXT,
        intervention_for_task_id TEXT,
        generated_ordinal INTEGER,
        accepted_artifact_ids_json TEXT NOT NULL,
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS executions (
        execution_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        task_id TEXT NOT NULL,
        attempt INTEGER NOT NULL,
        worker_id TEXT,
        worker_revision INTEGER,
        grant_json TEXT,
        state TEXT NOT NULL,
        cancellation_requested INTEGER NOT NULL,
        failure_json TEXT,
        result_json TEXT,
        produced_artifact_ids_json TEXT NOT NULL,
        started_at_order INTEGER NOT NULL,
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id),
        FOREIGN KEY (task_id) REFERENCES tasks(task_id),
        UNIQUE (task_id, attempt)
      );
      CREATE TABLE IF NOT EXISTS waits (
        wait_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        scope_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        state TEXT NOT NULL,
        event_type TEXT,
        correlation_key TEXT,
        delay_ms INTEGER,
        created_at_order INTEGER NOT NULL,
        consumed_event_id TEXT,
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS external_events (
        session_id TEXT NOT NULL,
        event_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        correlation_key TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        occurred_at TEXT,
        accepted_order INTEGER NOT NULL,
        consumed_by_wait_id TEXT,
        PRIMARY KEY (session_id, event_id),
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS artifacts (
        artifact_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        created_at_order INTEGER NOT NULL,
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id)
      );
      CREATE TABLE IF NOT EXISTS artifact_versions (
        artifact_version_id TEXT PRIMARY KEY,
        artifact_id TEXT NOT NULL,
        session_id TEXT NOT NULL,
        blob_hash TEXT NOT NULL,
        size INTEGER NOT NULL,
        media_type TEXT NOT NULL,
        origin_kind TEXT NOT NULL,
        origin_ref TEXT NOT NULL,
        immutable INTEGER NOT NULL DEFAULT 1 CHECK (immutable = 1),
        FOREIGN KEY (session_id) REFERENCES work_sessions(session_id),
        UNIQUE (artifact_version_id)
      );
      CREATE TABLE IF NOT EXISTS task_inputs (
        task_id TEXT NOT NULL,
        input_name TEXT NOT NULL,
        artifact_version_id TEXT,
        value_json TEXT,
        PRIMARY KEY (task_id, input_name),
        FOREIGN KEY (task_id) REFERENCES tasks(task_id)
      );
      CREATE TABLE IF NOT EXISTS execution_outputs (
        execution_id TEXT NOT NULL,
        artifact_version_id TEXT NOT NULL,
        PRIMARY KEY (execution_id, artifact_version_id),
        FOREIGN KEY (execution_id) REFERENCES executions(execution_id),
        FOREIGN KEY (artifact_version_id) REFERENCES artifact_versions(artifact_version_id)
      );
      CREATE TABLE IF NOT EXISTS task_outputs (
        task_id TEXT NOT NULL,
        artifact_version_id TEXT NOT NULL,
        PRIMARY KEY (task_id, artifact_version_id),
        FOREIGN KEY (task_id) REFERENCES tasks(task_id),
        FOREIGN KEY (artifact_version_id) REFERENCES artifact_versions(artifact_version_id)
      );
      CREATE TABLE IF NOT EXISTS artifact_derivations (
        derived_artifact_version_id TEXT NOT NULL,
        source_artifact_version_id TEXT NOT NULL,
        PRIMARY KEY (derived_artifact_version_id, source_artifact_version_id),
        FOREIGN KEY (derived_artifact_version_id) REFERENCES artifact_versions(artifact_version_id),
        FOREIGN KEY (source_artifact_version_id) REFERENCES artifact_versions(artifact_version_id)
      );
      CREATE TABLE IF NOT EXISTS workers (
        worker_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        profile_json TEXT NOT NULL,
        PRIMARY KEY (worker_id, revision)
      );
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        checksum TEXT NOT NULL,
        applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE UNIQUE INDEX IF NOT EXISTS one_running_execution_per_task
        ON executions(task_id) WHERE state = 'running';
      CREATE INDEX IF NOT EXISTS domain_commits_by_session ON domain_commits(session_id, revision);
      CREATE INDEX IF NOT EXISTS executions_by_task ON executions(task_id, attempt);
    `,
  },
  {
    version: 2,
    sql: "ALTER TABLE tasks ADD COLUMN input_artifact_ids_json TEXT NOT NULL DEFAULT '[]';",
  },
];

export class Registry {
  readonly db: DatabaseSync;

  constructor(path = ":memory:", options: RegistryOptions = {}) {
    this.db = new DatabaseSync(path, { readOnly: options.readOnly ?? false });
    if (options.readOnly) {
      this.db.exec("PRAGMA foreign_keys = ON;");
    } else {
      this.db.exec("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL;");
      this.migrate();
    }
  }

  static openReadOnly(path: string): Registry {
    return new Registry(path, { readOnly: true });
  }

  migrate(): void {
    this.db.exec("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);");
    for (const migration of MIGRATIONS) {
      const checksum = sha256(migration.sql);
      const row = this.db.prepare("SELECT checksum FROM schema_migrations WHERE version = ?").get(migration.version) as { checksum?: string } | undefined;
      if (row && row.checksum !== checksum) throw new Error(`migration checksum mismatch for version ${migration.version}`);
      if (!row) {
        this.db.exec("BEGIN IMMEDIATE");
        try {
          this.db.exec(migration.sql);
          this.db.prepare("INSERT INTO schema_migrations(version, checksum) VALUES (?, ?)").run(migration.version, checksum);
          this.db.exec("COMMIT");
        } catch (error) {
          this.db.exec("ROLLBACK");
          throw error;
        }
      }
    }
  }

  close(): void {
    this.db.close();
  }

  registerDefinition(definition: WorkDefinition): void {
    const existing = this.db.prepare("SELECT definition_hash FROM work_definitions WHERE work_definition_id = ? AND revision = ?").get(definition.workDefinitionId, definition.revision) as { definition_hash?: string } | undefined;
    if (existing && existing.definition_hash !== definition.definitionHash) throw new DomainError("DEFINITION_IMMUTABLE", "definition revision is immutable");
    if (!existing) {
      this.db.prepare("INSERT INTO work_definitions(work_definition_id, revision, definition_hash, schema_version, definition_json) VALUES (?, ?, ?, ?, ?)").run(
        definition.workDefinitionId,
        definition.revision,
        definition.definitionHash!,
        definition.schemaVersion,
        canonicalJson(definition as unknown as JsonValue),
      );
    }
  }

  getDefinition(workDefinitionId: string, revision: number): WorkDefinition | undefined {
    const row = this.db.prepare("SELECT definition_json FROM work_definitions WHERE work_definition_id = ? AND revision = ?").get(workDefinitionId, revision) as { definition_json?: string } | undefined;
    return row ? JSON.parse(row.definition_json!) as WorkDefinition : undefined;
  }

  getRuntimeState(sessionId: string): RuntimeState | undefined {
    const row = this.db.prepare("SELECT runtime_snapshot_json FROM work_sessions WHERE session_id = ?").get(sessionId) as { runtime_snapshot_json?: string } | undefined;
    return row ? JSON.parse(row.runtime_snapshot_json!) as RuntimeState : undefined;
  }

  getSessionProjection(sessionId: string): Record<string, unknown> | undefined {
    return this.db.prepare("SELECT session_id, work_definition_id, definition_revision, definition_hash, state, revision, state_hash FROM work_sessions WHERE session_id = ?").get(sessionId) as Record<string, unknown> | undefined;
  }

  getDomainCommits(sessionId: string): Array<Record<string, unknown>> {
    return this.db.prepare("SELECT session_id, revision, command_id, command_type, facts_json, resulting_state_hash FROM domain_commits WHERE session_id = ? ORDER BY revision").all(sessionId) as Array<Record<string, unknown>>;
  }

  getReceipt(sessionId: string, commandId: string): { requestHash: string; response: JsonValue; accepted: boolean; resultingRevision: number | null } | undefined {
    const row = this.db.prepare("SELECT request_hash, response_json, accepted, resulting_revision FROM command_receipts WHERE session_id = ? AND command_id = ?").get(sessionId, commandId) as ReceiptRow | undefined;
    if (!row) return undefined;
    return { requestHash: row.request_hash, response: JSON.parse(row.response_json) as JsonValue, accepted: row.accepted === 1, resultingRevision: row.resulting_revision };
  }

  commit<C extends CommandEnvelope>(envelope: C, reduction: Reduction, requestHash: string, createIfMissing = false): CommitResult {
    const existing = this.getReceipt(envelope.sessionId, envelope.commandId);
    if (existing) {
      if (existing.requestHash !== requestHash) throw new Error("IDEMPOTENCY_KEY_CONFLICT");
      return { response: existing.response, duplicate: true, resultingRevision: existing.resultingRevision };
    }
    const current = this.getSessionProjection(envelope.sessionId);
    if (!current && !createIfMissing) throw new Error(`session ${envelope.sessionId} not found`);
    const nextState = reduction.kind === "accepted" ? reduction.nextState : undefined;
    const expectedRevision = nextState && reduction.kind === "accepted" && reduction.advanceRevision ? nextState.revision - 1 : (current?.revision as number | undefined);
    if (current && nextState && Number(current.revision) !== expectedRevision) throw new Error("revision conflict");
    if (!current && (!nextState || !createIfMissing)) throw new Error("session is not initialized");

    this.db.exec("BEGIN IMMEDIATE");
    try {
      if (reduction.kind === "rejected") {
        this.db.prepare("INSERT INTO command_receipts(session_id, command_id, request_hash, accepted, resulting_revision, response_json) VALUES (?, ?, ?, 0, NULL, ?)").run(
          envelope.sessionId, envelope.commandId, requestHash, canonicalJson(reduction.response),
        );
        this.db.exec("COMMIT");
        return { response: reduction.response, duplicate: false, resultingRevision: null };
      }
      // 初回 Session は Receipt の外部キーを満たすため、同一トランザクション内で
      // 先にスナップショットを作る。DomainCommit と最終的な upsert は後続で行う。
      if (!current) this.persistState(nextState!);
      const responseJson = canonicalJson(reduction.response);
      this.db.prepare("INSERT INTO command_receipts(session_id, command_id, request_hash, accepted, resulting_revision, response_json) VALUES (?, ?, ?, 1, ?, ?)").run(
        envelope.sessionId,
        envelope.commandId,
        requestHash,
        reduction.advanceRevision ? nextState!.revision : null,
        responseJson,
      );
      if (reduction.advanceRevision) {
        const commit: DomainCommit = {
          sessionId: envelope.sessionId,
          revision: nextState!.revision,
          commandId: envelope.commandId,
          commandType: envelope.command.type,
          facts: reduction.facts,
          resultingStateHash: hashJson(nextState as unknown as JsonValue),
        };
        this.db.prepare("INSERT INTO domain_commits(session_id, revision, command_id, command_type, facts_json, resulting_state_hash) VALUES (?, ?, ?, ?, ?, ?)").run(
          commit.sessionId, commit.revision, commit.commandId, commit.commandType, canonicalJson(commit.facts as unknown as JsonValue), commit.resultingStateHash,
        );
        this.persistState(nextState!);
      } else if (!current) {
        throw new Error("a non-advancing command cannot create a session");
      }
      this.db.exec("COMMIT");
      return { response: reduction.response, duplicate: false, resultingRevision: reduction.advanceRevision ? nextState!.revision : null };
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }

  private persistState(state: RuntimeState): void {
    const snapshot = canonicalJson(state as unknown as JsonValue);
    const stateHash = hashJson(state as unknown as JsonValue);
    this.db.prepare(`INSERT INTO work_sessions(session_id, work_definition_id, definition_revision, definition_hash, state, revision, runtime_snapshot_json, state_hash)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id) DO UPDATE SET work_definition_id=excluded.work_definition_id, definition_revision=excluded.definition_revision,
      definition_hash=excluded.definition_hash, state=excluded.state, revision=excluded.revision, runtime_snapshot_json=excluded.runtime_snapshot_json, state_hash=excluded.state_hash`).run(
      state.session.sessionId, state.session.workDefinitionId, state.session.definitionRevision, state.session.definitionHash,
      state.session.state, state.revision, snapshot, stateHash,
    );
    for (const scope of Object.values(state.scopes)) {
      this.db.prepare(`INSERT INTO scope_instances(scope_id, session_id, step_id, kind, state, result_json, child_ids_json, cursor, runtime_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(scope_id) DO UPDATE SET state=excluded.state, result_json=excluded.result_json,
        child_ids_json=excluded.child_ids_json, cursor=excluded.cursor, runtime_json=excluded.runtime_json`).run(
        scope.scopeId, state.session.sessionId, scope.stepId, scope.kind, scope.state, scope.result === undefined ? null : canonicalJson(scope.result),
        canonicalJson(scope.childIds as unknown as JsonValue), scope.cursor, canonicalJson(scope as unknown as JsonValue),
      );
    }
    for (const task of Object.values(state.tasks)) {
      this.db.prepare(`INSERT INTO tasks(task_id, session_id, scope_id, step_id, worker_kind, goal, contract_json, inputs_json, input_artifact_ids_json, state, current_execution_id,
        claimant_actor_id, outcome, result_json, attention, intervention_for_task_id, generated_ordinal, accepted_artifact_ids_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(task_id) DO UPDATE SET state=excluded.state,
        current_execution_id=excluded.current_execution_id, claimant_actor_id=excluded.claimant_actor_id, outcome=excluded.outcome,
        result_json=excluded.result_json, attention=excluded.attention, intervention_for_task_id=excluded.intervention_for_task_id,
        generated_ordinal=excluded.generated_ordinal, accepted_artifact_ids_json=excluded.accepted_artifact_ids_json,
        input_artifact_ids_json=excluded.input_artifact_ids_json`).run(
        task.taskId, task.sessionId, task.scopeId, task.stepId, task.workerKind, task.goal, canonicalJson(task.contract as unknown as JsonValue),
        canonicalJson(task.inputs as unknown as JsonValue), canonicalJson(task.inputArtifactVersionIds as unknown as JsonValue), task.state, task.currentExecutionId ?? null, task.claimantActorId ?? null, task.outcome ?? null,
        task.result === undefined ? null : canonicalJson(task.result), task.attention ?? null, task.interventionForTaskId ?? null,
        task.generatedOrdinal ?? null, canonicalJson(task.acceptedOutputArtifactVersionIds as unknown as JsonValue),
      );
      this.db.prepare("DELETE FROM task_inputs WHERE task_id = ?").run(task.taskId);
      for (const [name, value] of Object.entries(task.inputs)) {
        this.db.prepare("INSERT INTO task_inputs(task_id, input_name, value_json) VALUES (?, ?, ?)").run(task.taskId, name, canonicalJson(value));
      }
      task.inputArtifactVersionIds.forEach((artifactId, index) => {
        this.db.prepare("INSERT INTO task_inputs(task_id, input_name, artifact_version_id) VALUES (?, ?, ?)").run(task.taskId, `@artifact:${index}`, artifactId);
      });
    }
    for (const execution of Object.values(state.executions)) {
      this.db.prepare(`INSERT INTO executions(execution_id, session_id, task_id, attempt, worker_id, worker_revision, grant_json, state,
        cancellation_requested, failure_json, result_json, produced_artifact_ids_json, started_at_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(execution_id) DO UPDATE SET state=excluded.state,
        cancellation_requested=excluded.cancellation_requested, failure_json=excluded.failure_json, result_json=excluded.result_json,
        produced_artifact_ids_json=excluded.produced_artifact_ids_json`).run(
        execution.executionId, state.session.sessionId, execution.taskId, execution.attempt, execution.workerId ?? null, execution.workerRevision ?? null,
        execution.grant ? canonicalJson(execution.grant as unknown as JsonValue) : null, execution.state, execution.cancellationRequested ? 1 : 0,
        execution.failure === undefined ? null : canonicalJson(execution.failure), execution.result === undefined ? null : canonicalJson(execution.result),
        canonicalJson(execution.producedArtifactVersionIds as unknown as JsonValue), execution.startedAtOrder,
      );
    }
    for (const wait of Object.values(state.waits)) {
      this.db.prepare(`INSERT INTO waits(wait_id, session_id, scope_id, kind, state, event_type, correlation_key, delay_ms, created_at_order, consumed_event_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(wait_id) DO UPDATE SET state=excluded.state, consumed_event_id=excluded.consumed_event_id`).run(
        wait.waitId, state.session.sessionId, wait.scopeId, wait.kind, wait.state, wait.eventType ?? null, wait.correlationKey ?? null,
        wait.delayMs ?? null, wait.createdAtOrder, wait.consumedEventId ?? null,
      );
    }
    for (const event of state.events) {
      this.db.prepare(`INSERT INTO external_events(session_id, event_id, event_type, correlation_key, payload_json, occurred_at, accepted_order, consumed_by_wait_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(session_id, event_id) DO UPDATE SET consumed_by_wait_id=excluded.consumed_by_wait_id`).run(
        state.session.sessionId, event.eventId, event.eventType, event.correlationKey, canonicalJson(event.payload), event.occurredAt ?? null,
        event.acceptedOrder, event.consumedByWaitId ?? null,
      );
    }
    for (const artifact of Object.values(state.artifacts)) {
      const artifactId = `artifact:${artifact.artifactVersionId}`;
      this.db.prepare("INSERT OR IGNORE INTO artifacts(artifact_id, session_id, created_at_order) VALUES (?, ?, ?)").run(artifactId, state.session.sessionId, state.order);
      this.db.prepare(`INSERT INTO artifact_versions(artifact_version_id, artifact_id, session_id, blob_hash, size, media_type, origin_kind, origin_ref)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(artifact_version_id) DO NOTHING`).run(
        artifact.artifactVersionId, artifactId, state.session.sessionId, artifact.blobHash, artifact.size, artifact.mediaType, artifact.origin.kind,
        artifact.origin.kind === "execution" ? artifact.origin.executionId : artifact.origin.sourceRef,
      );
    }
    for (const execution of Object.values(state.executions)) {
      this.db.prepare("DELETE FROM execution_outputs WHERE execution_id = ?").run(execution.executionId);
      for (const artifactId of execution.producedArtifactVersionIds) this.db.prepare("INSERT INTO execution_outputs(execution_id, artifact_version_id) VALUES (?, ?)").run(execution.executionId, artifactId);
    }
    for (const task of Object.values(state.tasks)) {
      const produced = Object.values(state.executions).filter((execution) => execution.taskId === task.taskId).flatMap((execution) => execution.producedArtifactVersionIds);
      for (const derived of produced) for (const source of task.inputArtifactVersionIds) {
        // 外部入力 ArtifactVersion は別の Session/Registry 投影から来る可能性がある。
        // この Registry に実体がある場合だけ、FK 付きの来歴辺を作る。
        if (state.artifacts[derived] && state.artifacts[source]) this.db.prepare("INSERT OR IGNORE INTO artifact_derivations(derived_artifact_version_id, source_artifact_version_id) VALUES (?, ?)").run(derived, source);
      }
    }
    this.db.prepare("DELETE FROM task_outputs WHERE task_id IN (SELECT task_id FROM tasks WHERE session_id = ?)").run(state.session.sessionId);
    for (const task of Object.values(state.tasks)) {
      for (const artifactId of task.acceptedOutputArtifactVersionIds) this.db.prepare("INSERT INTO task_outputs(task_id, artifact_version_id) VALUES (?, ?)").run(task.taskId, artifactId);
    }
  }

  listTables(): string[] {
    return (this.db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name").all() as Array<{ name: string }>).map((row) => row.name);
  }

  query<T extends Record<string, unknown> = Record<string, unknown>>(sql: string, ...params: unknown[]): T[] {
    return this.db.prepare(sql).all(...params as any[]) as T[];
  }
}
