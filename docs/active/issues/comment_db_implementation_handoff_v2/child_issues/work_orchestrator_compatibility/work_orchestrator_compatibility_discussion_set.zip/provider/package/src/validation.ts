import { canonicalJson, hashJson, isValidJsonPointer } from "./canonical.js";
import {
  DomainError,
  type DynamicExpandStep,
  type InputBinding,
  type JsonValue,
  type Step,
  type TaskContract,
  type TaskStep,
  type WorkDefinition,
} from "./contracts.js";

const STEP_KINDS = new Set(["task", "sequence", "choice", "parallelAll", "waitEvent", "waitTimer", "dynamicExpand"]);

export interface ValidatedDefinition extends WorkDefinition {
  definitionHash: string;
}

export function validateAndHashDefinition(input: WorkDefinition): ValidatedDefinition {
  const errors: string[] = [];
  if (!input || typeof input !== "object") errors.push("definition must be an object");
  if (!input.workDefinitionId) errors.push("workDefinitionId is required");
  if (!Number.isInteger(input.revision) || input.revision < 0) errors.push("revision must be a non-negative integer");
  if (!Number.isInteger(input.schemaVersion) || input.schemaVersion < 1) errors.push("schemaVersion must be positive");
  for (const [name, value] of Object.entries(input.limits ?? {})) {
    if (!Number.isInteger(value) || value <= 0) errors.push(`limits.${name} must be a positive integer`);
  }

  const ids = new Set<string>();
  if (input.root) visit(input.root, ids, errors, new Set<string>(), "root");
  else errors.push("root is required");
  if (errors.length) throw new DomainError("DEFINITION_INVALID", errors.join("; "), errors as unknown as JsonValue);

  const withoutHash = { ...input } as WorkDefinition;
  delete withoutHash.definitionHash;
  let definitionHash: string;
  try {
    definitionHash = hashJson(withoutHash as unknown as JsonValue);
  } catch (error) {
    throw new DomainError("DEFINITION_INVALID", error instanceof Error ? error.message : "definition is not valid JSON");
  }
  if (input.definitionHash && input.definitionHash !== definitionHash) {
    throw new DomainError("DEFINITION_INVALID", "definitionHash does not match canonical definition");
  }
  return { ...withoutHash, definitionHash };
}

function visit(step: Step, ids: Set<string>, errors: string[], visible: Set<string>, path: string): void {
  if (!step || typeof step !== "object" || !STEP_KINDS.has((step as Step).kind)) {
    errors.push(`${path}: unsupported step kind`);
    return;
  }
  if (!step.id || ids.has(step.id)) {
    errors.push(`${path}: duplicate or empty step id ${step.id ?? ""}`);
    return;
  }
  ids.add(step.id);
  if (step.kind === "task") {
    validateTask(step, errors, visible, path);
    return;
  }
  if (step.kind === "sequence") {
    if (!Array.isArray(step.children) || step.children.length === 0) errors.push(`${path}: Sequence must not be empty`);
    let sequenceVisible = new Set(visible);
    for (const child of step.children ?? []) {
      visit(child, ids, errors, sequenceVisible, `${path}/${step.id}/${child.id ?? "?"}`);
      sequenceVisible.add(child.id);
    }
    return;
  }
  if (step.kind === "parallelAll") {
    const branches = Object.entries(step.branches ?? {});
    if (branches.length === 0) errors.push(`${path}: ParallelAll must not be empty`);
    for (const [branch, child] of branches) visit(child, ids, errors, new Set(visible), `${path}/${step.id}/${branch}`);
    return;
  }
  if (step.kind === "choice") {
    if (!step.decision || step.decision.kind !== "task") errors.push(`${path}: Choice decision must be a Task`);
    else {
      if (!step.decision.id || ids.has(step.decision.id)) errors.push(`${path}: duplicate or empty decision id`);
      else ids.add(step.decision.id);
      validateTask(step.decision, errors, visible, `${path}/${step.id}/decision`);
    }
    const branches = Object.entries(step.branches ?? {});
    const allowed = new Set(step.decision?.contract.allowedOutcomes ?? []);
    if (branches.length === 0 || allowed.size !== branches.length || branches.some(([key]) => !allowed.has(key))) {
      errors.push(`${path}: Choice outcomes must exactly equal branch keys`);
    }
    for (const [branch, child] of branches) visit(child, ids, errors, new Set(visible), `${path}/${step.id}/${branch}`);
    return;
  }
  if (step.kind === "waitEvent") {
    if (!step.eventType || typeof step.correlationKey !== "string") errors.push(`${path}: invalid WaitEvent matcher`);
    return;
  }
  if (step.kind === "waitTimer") {
    if (!Number.isFinite(step.delayMs) || step.delayMs < 0) errors.push(`${path}: delayMs must be finite and non-negative`);
    return;
  }
  validateDynamic(step, ids, errors, visible, path);
}

function validateTask(task: TaskStep, errors: string[], visible: Set<string>, path: string): void {
  validateContract(task.contract, errors, path);
  if (task.contract?.resultSchema !== undefined) validateSchemaDefinition(task.contract.resultSchema, errors, `${path}/resultSchema`);
  if (task.contract?.outputSchema !== undefined) validateSchemaDefinition(task.contract.outputSchema, errors, `${path}/outputSchema`);
  if (typeof task.goal !== "string") errors.push(`${path}: goal must be a string`);
  for (const [name, binding] of Object.entries(task.inputBindings ?? {})) {
    validateBinding(name, binding, errors, visible, path);
  }
}

function validateSchemaDefinition(schema: JsonValue, errors: string[], path: string): void {
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) {
    errors.push(`${path}: runtime schema must be an object`);
    return;
  }
  const object = schema as Record<string, JsonValue>;
  if (object.type !== undefined && (typeof object.type !== "string" || !["object", "array", "string", "number", "integer", "boolean", "null"].includes(object.type))) {
    errors.push(`${path}: unsupported schema type`);
  }
  if (object.required !== undefined && (!Array.isArray(object.required) || !object.required.every((item) => typeof item === "string"))) errors.push(`${path}: required must be a string array`);
  if (object.properties !== undefined) {
    if (!object.properties || typeof object.properties !== "object" || Array.isArray(object.properties)) errors.push(`${path}: properties must be an object`);
    else for (const [key, child] of Object.entries(object.properties)) validateSchemaDefinition(child, errors, `${path}/properties/${key}`);
  }
  if (object.items !== undefined) validateSchemaDefinition(object.items, errors, `${path}/items`);
  if (object.enum !== undefined && (!Array.isArray(object.enum) || object.enum.length === 0)) errors.push(`${path}: enum must be a non-empty array`);
}

function validateContract(contract: TaskContract | undefined, errors: string[], path: string): void {
  if (!contract || (contract.workerKind !== "human" && contract.workerKind !== "agent")) {
    errors.push(`${path}: invalid workerKind`);
    return;
  }
  if (!Array.isArray(contract.requiredCapabilities) || !Array.isArray(contract.requestedPermissions)) {
    errors.push(`${path}: capabilities and permissions must be arrays`);
  }
  if (!contract.retryPolicy || !Number.isInteger(contract.retryPolicy.maxAttempts) || contract.retryPolicy.maxAttempts < 1) {
    errors.push(`${path}: maxAttempts must be a positive integer`);
  }
  if (!contract.budgets || !Number.isFinite(contract.budgets.maxWallTimeMs) || contract.budgets.maxWallTimeMs <= 0) {
    errors.push(`${path}: maxWallTimeMs must be finite and positive`);
  }
  for (const [name, value] of Object.entries(contract.budgets ?? {})) {
    if (value !== undefined && (!Number.isFinite(value) || value < 0)) errors.push(`${path}: budget ${name} is invalid`);
  }
  if (contract.allowedOutcomes && new Set(contract.allowedOutcomes).size !== contract.allowedOutcomes.length) {
    errors.push(`${path}: allowedOutcomes must be unique`);
  }
}

function validateBinding(name: string, binding: InputBinding, errors: string[], visible: Set<string>, path: string): void {
  if (!binding || (binding.source !== "session" && binding.source !== "step")) {
    errors.push(`${path}: input ${name} has invalid source`);
    return;
  }
  if (!isValidJsonPointer(binding.path)) errors.push(`${path}: input ${name} has invalid JSON Pointer`);
  if (binding.source === "step" && (!binding.stepId || !visible.has(binding.stepId))) {
    errors.push(`${path}: input ${name} references a lexically invisible step`);
  }
}

function validateDynamic(step: DynamicExpandStep, ids: Set<string>, errors: string[], visible: Set<string>, path: string): void {
  if (step.planner?.kind !== "task" || step.planner.contract.workerKind !== "agent") {
    errors.push(`${path}: DynamicExpand planner must be an Agent Task`);
  } else {
    validateTask(step.planner, errors, visible, `${path}/${step.id}/planner`);
  }
  if (step.strategy !== "sequence" && step.strategy !== "parallelAll") errors.push(`${path}: invalid expansion strategy`);
  if (!Number.isInteger(step.maxTasks) || step.maxTasks < 1) errors.push(`${path}: maxTasks must be positive`);
  const policy = step.proposalPolicy;
  if (!policy || (policy.workerKind !== "human" && policy.workerKind !== "agent")) errors.push(`${path}: invalid proposal policy`);
  if (policy) {
    validateContract({
      workerKind: policy.workerKind,
      requiredCapabilities: policy.requiredCapabilities,
      requestedPermissions: policy.requestedPermissions,
      retryPolicy: policy.retryPolicy,
      budgets: policy.budgets,
      allowedOutcomes: policy.allowedOutcomes,
    }, errors, `${path}/proposalPolicy`);
  }
  // The policy creates only a leaf Task; a nested Step is intentionally not accepted.
  if (step.planner?.id && ids.has(step.planner.id)) errors.push(`${path}: planner id collides with a static step id`);
  if (step.planner?.id) ids.add(step.planner.id);
}

export function findStep(root: Step, id: string): Step | undefined {
  if (root.id === id) return root;
  if (root.kind === "sequence") {
    for (const child of root.children) {
      const found = findStep(child, id);
      if (found) return found;
    }
  } else if (root.kind === "parallelAll") {
    for (const child of Object.values(root.branches)) {
      const found = findStep(child, id);
      if (found) return found;
    }
  } else if (root.kind === "choice") {
    const foundDecision = findStep(root.decision, id);
    if (foundDecision) return foundDecision;
    for (const child of Object.values(root.branches)) {
      const found = findStep(child, id);
      if (found) return found;
    }
  } else if (root.kind === "dynamicExpand") {
    return root.planner.id === id ? root.planner : undefined;
  }
  return undefined;
}

export function definitionWithoutHash(definition: WorkDefinition): JsonValue {
  const copy = { ...definition };
  delete copy.definitionHash;
  return copy as unknown as JsonValue;
}

export function definitionCanonicalJson(definition: WorkDefinition): string {
  return canonicalJson(definitionWithoutHash(definition));
}
