import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  ArtifactStore,
  CodexAdapter,
  DomainError,
  FakeAgentAdapter,
  Registry,
  TemporalSessionRuntime,
  WorkOrchestrator,
  canonicalJson,
  createInitialRuntimeState,
  hashJson,
  validateAndHashDefinition,
} from "../dist/index.js";

const worker = (overrides = {}) => ({
  workerId: "worker-1",
  revision: 1,
  enabled: true,
  capabilities: [],
  enforceablePermissions: [],
  enforceableBudgets: [],
  routingPriority: 1,
  physicalAvailable: true,
  ...overrides,
});

const agentContract = (overrides = {}) => ({
  workerKind: "agent",
  requiredCapabilities: [],
  requestedPermissions: [],
  retryPolicy: { maxAttempts: 1 },
  budgets: { maxWallTimeMs: 1000 },
  ...overrides,
});

const humanContract = (allowedOutcomes) => ({
  workerKind: "human",
  requiredCapabilities: [],
  requestedPermissions: [],
  retryPolicy: { maxAttempts: 1 },
  budgets: { maxWallTimeMs: 1000 },
  ...(allowedOutcomes ? { allowedOutcomes } : {}),
});

function task(id, contract = agentContract(), goal = id, inputBindings) {
  return { kind: "task", id, goal, contract, ...(inputBindings ? { inputBindings } : {}) };
}

function orchestrator(adapter = new FakeAgentAdapter(), options = {}) {
  return new WorkOrchestrator({ agentAdapter: adapter, workers: [worker(), ...(options.workers ?? [])], ...options });
}

test("契約、JCS hash、静的検証は v1 の禁止構造を拒否する", () => {
  const definition = { workDefinitionId: "d", revision: 0, schemaVersion: 1, root: task("a") };
  const validated = validateAndHashDefinition(definition);
  assert.equal(validated.definitionHash, hashJson({ ...definition }));
  assert.equal(canonicalJson({ b: 1, a: 2 }), '{"a":2,"b":1}');
  assert.throws(() => validateAndHashDefinition({
    workDefinitionId: "bad",
    revision: 0,
    schemaVersion: 1,
    root: task("a", agentContract(), "a", { x: { source: "step", stepId: "future", path: "/x" } }),
  }), (error) => error instanceof DomainError && error.code === "DEFINITION_INVALID");
});

test("S01: Agent 単体成功は Task/Execution/Session と Registry を完了させる", async () => {
  const adapter = new FakeAgentAdapter();
  const orchestration = orchestrator(adapter);
  orchestration.registerDefinition({ workDefinitionId: "s01", revision: 0, schemaVersion: 1, root: task("agent") });
  const response = await orchestration.startSession({ sessionId: "s01-session", workDefinitionId: "s01" });
  const state = orchestration.state("s01-session");
  assert.equal(response.sessionId, "s01-session");
  assert.equal(state.session.state, "completed");
  assert.equal(Object.values(state.tasks)[0].state, "completed");
  assert.equal(Object.values(state.executions)[0].state, "succeeded");
  assert.equal(orchestration.reconcile("s01-session").status, "consistent");
  assert.equal(orchestration.sessionRuntimeInfo("s01-session").hasChildWorkflow, false);
});

test("S02: Sequence は明示入力と Artifact provenance を後続 Task に渡す", async () => {
  const adapter = new FakeAgentAdapter();
  const orchestration = orchestrator(adapter);
  orchestration.registerDefinition({
    workDefinitionId: "s02", revision: 0, schemaVersion: 1,
    root: { kind: "sequence", id: "root", children: [
      task("first", agentContract(), "first"),
      task("second", agentContract(), "second", { prior: { source: "step", stepId: "first", path: "/value" } }),
    ] },
  });
  const firstId = "s02-session:task:s02-session:scope:root:child:0:first";
  adapter.plan(firstId, { result: { status: "succeeded", result: { value: 42 }, artifacts: [{ content: "derived", mediaType: "text/plain" }] } });
  await orchestration.startSession({ sessionId: "s02-session", workDefinitionId: "s02" });
  const state = orchestration.state("s02-session");
  const second = Object.values(state.tasks).find((candidate) => candidate.stepId === "second");
  assert.deepEqual(second.inputs, { prior: 42 });
  assert.equal(second.inputArtifactVersionIds.length, 1);
  assert.equal(state.executions[firstId.replace(":task:", ":task:") + ":execution:1"]?.producedArtifactVersionIds.length, 1);
});

test("S03: Human claim/release/reclaim/complete は Execution を再利用しない", async () => {
  const orchestration = orchestrator();
  orchestration.registerDefinition({ workDefinitionId: "s03", revision: 0, schemaVersion: 1, root: task("human", humanContract()) });
  await orchestration.startSession({ sessionId: "s03-session", workDefinitionId: "s03" });
  const human = Object.values(orchestration.state("s03-session").tasks)[0];
  await orchestration.claimTask("s03-session", human.taskId, { actorId: "alice" });
  await orchestration.releaseTask("s03-session", human.taskId, { actorId: "alice" });
  await orchestration.claimTask("s03-session", human.taskId, { actorId: "bob" });
  await orchestration.completeHumanTask("s03-session", human.taskId, { actorId: "bob" }, undefined, { approved: true });
  const state = orchestration.state("s03-session");
  assert.equal(state.session.state, "completed");
  assert.deepEqual(Object.values(state.executions).map((execution) => execution.state), ["cancelled", "succeeded"]);
});

test("S04/S05: Choice は選択枝だけを実行し、rework を構成できる", async () => {
  const orchestration = orchestrator();
  orchestration.registerDefinition({
    workDefinitionId: "s04", revision: 0, schemaVersion: 1,
    root: { kind: "choice", id: "choice", decision: task("decision", humanContract(["approve", "reject"])), branches: {
      approve: task("approve", agentContract()),
      reject: { kind: "sequence", id: "rework", children: [task("rework-task", agentContract())] },
    } },
  });
  await orchestration.startSession({ sessionId: "s04-session", workDefinitionId: "s04" });
  const decision = Object.values(orchestration.state("s04-session").tasks)[0];
  await orchestration.claimTask("s04-session", decision.taskId, { actorId: "reviewer" });
  await orchestration.completeHumanTask("s04-session", decision.taskId, { actorId: "reviewer" }, "reject");
  const state = orchestration.state("s04-session");
  assert.equal(state.session.state, "completed");
  assert.equal(Object.values(state.tasks).some((candidate) => candidate.stepId === "approve"), false);
  assert.equal(Object.values(state.tasks).some((candidate) => candidate.stepId === "rework-task"), true);
});

test("S06: ParallelAll は全枝を活性化し、branch key 順の結果を返す", async () => {
  const orchestration = orchestrator();
  orchestration.registerDefinition({ workDefinitionId: "s06", revision: 0, schemaVersion: 1, root: {
    kind: "parallelAll", id: "parallel", branches: { human: task("human", humanContract()), agent: task("agent", agentContract()) },
  } });
  await orchestration.startSession({ sessionId: "s06-session", workDefinitionId: "s06" });
  const human = Object.values(orchestration.state("s06-session").tasks).find((candidate) => candidate.stepId === "human");
  await orchestration.claimTask("s06-session", human.taskId, { actorId: "h" });
  assert.equal(orchestration.state("s06-session").session.state, "running");
  await orchestration.completeHumanTask("s06-session", human.taskId, { actorId: "h" });
  const state = orchestration.state("s06-session");
  assert.equal(state.session.state, "completed");
  assert.deepEqual(Object.keys(state.scopes[state.session.rootScopeId].result).sort(), ["agent", "human"]);
});

test("S07/S08/S28: 自動 retry は Task を active に保ち、枯渇時だけ介入する", async () => {
  const adapter = new FakeAgentAdapter();
  const orchestration = orchestrator(adapter);
  orchestration.registerDefinition({ workDefinitionId: "s07", revision: 0, schemaVersion: 1, root: task("retry", agentContract({ retryPolicy: { maxAttempts: 2 } })) });
  const taskId = "s07-session:task:s07-session:scope:root";
  adapter.plan(taskId, { result: { status: "failed", failure: "temporary" } }, { result: { status: "succeeded", result: { ok: true } } });
  await orchestration.startSession({ sessionId: "s07-session", workDefinitionId: "s07" });
  assert.equal(orchestration.state("s07-session").tasks[taskId].state, "completed");
  assert.deepEqual(Object.values(orchestration.state("s07-session").executions).map((execution) => execution.attempt), [1, 2]);

  const exhaustedAdapter = new FakeAgentAdapter();
  const exhausted = orchestrator(exhaustedAdapter);
  exhausted.registerDefinition({ workDefinitionId: "s08", revision: 0, schemaVersion: 1, root: task("retry", agentContract({ retryPolicy: { maxAttempts: 1, manualRetryAllowed: true } })) });
  const exhaustedTaskId = "s08-session:task:s08-session:scope:root";
  exhaustedAdapter.plan(exhaustedTaskId, { result: { status: "failed", failure: "permanent" } }, { result: { status: "succeeded", result: { recovered: true } } });
  await exhausted.startSession({ sessionId: "s08-session", workDefinitionId: "s08" });
  const intervention = Object.values(exhausted.state("s08-session").tasks).find((candidate) => candidate.interventionForTaskId);
  assert.equal(exhausted.state("s08-session").tasks[exhaustedTaskId].state, "waiting");
  await exhausted.claimTask("s08-session", intervention.taskId, { actorId: "operator" });
  await exhausted.completeHumanTask("s08-session", intervention.taskId, { actorId: "operator" }, "manual_retry");
  assert.equal(exhausted.state("s08-session").session.state, "completed");
});

test("S09/S15/S23/S24/S29: cancellation は intent と confirmed/abandoned を区別する", async () => {
  const adapter = new FakeAgentAdapter();
  const orchestration = orchestrator(adapter);
  orchestration.registerDefinition({ workDefinitionId: "s15", revision: 0, schemaVersion: 1, root: task("agent", agentContract()) });
  const taskId = "s15-session:task:s15-session:scope:root";
  adapter.plan(taskId, { defer: true, result: { status: "succeeded", result: { late: true } } });
  await orchestration.startSession({ sessionId: "s15-session", workDefinitionId: "s15" });
  assert.equal(orchestration.state("s15-session").session.state, "running");
  await orchestration.cancelSession("s15-session");
  assert.equal(orchestration.state("s15-session").session.state, "cancelled");
  assert.equal(Object.values(orchestration.state("s15-session").tasks)[0].state, "cancelled");
});

test("S29: cancellation 後の遅着成功結果は Execution/Task output を復活させない", async () => {
  class LateAgentAdapter extends FakeAgentAdapter {
    async cancel() {
      return { confirmed: false };
    }

    async forceKill() {
      // 強制終了でも解決しない実行主体を模擬し、遅着結果を後から送る。
    }
  }
  const adapter = new LateAgentAdapter();
  const orchestration = orchestrator(adapter);
  orchestration.registerDefinition({ workDefinitionId: "s29", revision: 0, schemaVersion: 1, root: task("agent", agentContract({ retryPolicy: { maxAttempts: 1 } })) });
  const taskId = "s29-session:task:s29-session:scope:root";
  adapter.plan(taskId, { defer: true, result: { status: "succeeded", result: { late: true } } });
  await orchestration.startSession({ sessionId: "s29-session", workDefinitionId: "s29" });
  const running = Object.values(orchestration.state("s29-session").executions)[0];
  await orchestration.cancelSession("s29-session");
  const cancelled = orchestration.state("s29-session");
  assert.equal(cancelled.session.state, "cancelled");
  assert.equal(cancelled.executions[running.executionId].state, "abandoned");
  assert.equal(cancelled.tasks[taskId].acceptedOutputArtifactVersionIds.length, 0);
  assert.equal(adapter.resolve(running.executionId, { status: "succeeded", result: { late: true } }), true);
  await new Promise((resolve) => setTimeout(resolve, 10));
  const afterLateResult = orchestration.state("s29-session");
  assert.equal(afterLateResult.session.state, "cancelled");
  assert.equal(afterLateResult.tasks[taskId].state, "cancelled");
  assert.equal(afterLateResult.tasks[taskId].acceptedOutputArtifactVersionIds.length, 0);
  assert.equal(afterLateResult.tasks[taskId].result, undefined);
});

test("S10/S11/S12: Event は早着/FIFO/重複排除し、Timer は Task を作らない", async () => {
  const orchestration = orchestrator();
  orchestration.registerDefinition({ workDefinitionId: "s10", revision: 0, schemaVersion: 1, root: { kind: "sequence", id: "root", children: [
    { kind: "waitEvent", id: "event", eventType: "ready", correlationKey: "job-1" },
    { kind: "waitTimer", id: "timer", delayMs: 5 },
  ] } });
  await orchestration.startSession({ sessionId: "s10-session", workDefinitionId: "s10" });
  await orchestration.receiveExternalEvent("s10-session", { eventId: "e1", eventType: "ready", correlationKey: "job-1", payload: { ok: 1 } });
  const duplicateRevision = orchestration.state("s10-session").revision;
  await orchestration.receiveExternalEvent("s10-session", { eventId: "e1", eventType: "ready", correlationKey: "job-1", payload: { ok: 1 } });
  assert.equal(orchestration.state("s10-session").revision, duplicateRevision);
  const timer = orchestration.pendingTimers("s10-session")[0];
  assert.ok(timer);
  assert.equal(Object.values(orchestration.state("s10-session").tasks).length, 0);
  await orchestration.fireTimer("s10-session", timer.waitId);
  assert.equal(orchestration.state("s10-session").session.state, "completed");
});

test("S13/S14: DynamicExpand は planner 権限を越えず、proposal ordinal で結果を並べる", async () => {
  const adapter = new FakeAgentAdapter();
  const orchestration = orchestrator(adapter);
  const definition = { workDefinitionId: "s13", revision: 0, schemaVersion: 1, root: {
    kind: "dynamicExpand", id: "dynamic", planner: task("planner", agentContract()), strategy: "parallelAll", maxTasks: 2,
    proposalPolicy: { workerKind: "agent", requiredCapabilities: [], requestedPermissions: [], retryPolicy: { maxAttempts: 1 }, budgets: { maxWallTimeMs: 1000 } },
  } };
  orchestration.registerDefinition(definition);
  const plannerId = "s13-session:task:s13-session:scope:root:child:0:planner";
  adapter.plan(plannerId, { result: { status: "succeeded", result: [
    { type: "one", goal: "one", inputArtifactVersionIds: [], parameters: { ordinal: 0 } },
    { type: "two", goal: "two", inputArtifactVersionIds: [], parameters: { ordinal: 1 } },
  ] } });
  adapter.plan("s13-session:task:s13-session:scope:root:child:1:dynamic:generated:0", { result: { status: "succeeded", result: { proposalParameters: { parameters: { ordinal: 0 } } } } });
  adapter.plan("s13-session:task:s13-session:scope:root:child:2:dynamic:generated:1", { result: { status: "succeeded", result: { proposalParameters: { parameters: { ordinal: 1 } } } } });
  await orchestration.startSession({ sessionId: "s13-session", workDefinitionId: "s13" });
  const state = orchestration.state("s13-session");
  assert.equal(state.session.state, "completed");
  const result = state.scopes[state.session.rootScopeId].result;
  assert.equal(result[0].proposalParameters.parameters.ordinal, 0);
  assert.equal(result[1].proposalParameters.parameters.ordinal, 1);
});

test("S16/S17/S26: Receipt は同一要求を再実行せず、payload conflict は revision を変えない", async () => {
  const orchestration = orchestrator();
  orchestration.registerDefinition({ workDefinitionId: "s16", revision: 0, schemaVersion: 1, root: task("human", humanContract()) });
  await orchestration.startSession({ sessionId: "s16-session", workDefinitionId: "s16" });
  const human = Object.values(orchestration.state("s16-session").tasks)[0];
  await orchestration.claimTask("s16-session", human.taskId, { actorId: "h" }, "claim-fixed");
  const first = await orchestration.completeHumanTask("s16-session", human.taskId, { actorId: "h" }, undefined, { ok: true }, "complete-fixed");
  const revision = orchestration.state("s16-session").revision;
  const duplicate = await orchestration.completeHumanTask("s16-session", human.taskId, { actorId: "h" }, undefined, { ok: true }, "complete-fixed");
  assert.deepEqual(duplicate, first);
  assert.equal(orchestration.state("s16-session").revision, revision);
  const conflict = await orchestration.dispatch("s16-session", { type: "advance" }, { actorId: "runtime" }, "complete-fixed");
  assert.equal(conflict.error.code, "IDEMPOTENCY_KEY_CONFLICT");
  assert.equal(orchestration.reconcile("s16-session").status, "consistent");
});

test("S19/S25: failed output は Execution provenance を残し、staged orphan は grace period 後に回収できる", async () => {
  const adapter = new FakeAgentAdapter();
  const store = new ArtifactStore();
  const orchestration = orchestrator(adapter, { artifactStore: store });
  orchestration.registerDefinition({ workDefinitionId: "s19", revision: 0, schemaVersion: 1, root: task("agent") });
  const taskId = "s19-session:task:s19-session:scope:root";
  adapter.plan(taskId, { result: { status: "failed", failure: "report", artifacts: [{ content: "kept" }] } });
  await orchestration.startSession({ sessionId: "s19-session", workDefinitionId: "s19" });
  const state = orchestration.state("s19-session");
  assert.equal(Object.keys(state.artifacts).length, 1);
  assert.equal(Object.values(state.tasks)[0].acceptedOutputArtifactVersionIds.length, 0);
  const staged = store.stage("orphan");
  assert.equal(store.gcOrphans(0).includes(staged.temporaryPath), true);
});

test("S20/S21/S22: no logical worker は Execution を作らず、再開後に dispatch する", async () => {
  const orchestration = new WorkOrchestrator({ workers: [] });
  orchestration.registerDefinition({ workDefinitionId: "s21", revision: 0, schemaVersion: 1, root: task("agent", agentContract({ requiredCapabilities: ["special"] })) });
  await orchestration.startSession({ sessionId: "s21-session", workDefinitionId: "s21" });
  const state = orchestration.state("s21-session");
  const agent = Object.values(state.tasks)[0];
  assert.equal(agent.state, "ready");
  assert.equal(Object.keys(state.executions).length, 0);
  orchestration.addWorker(worker({ workerId: "specialist", capabilities: ["special"], routingPriority: 0 }));
  await orchestration.resumeAgentTask("s21-session", agent.taskId);
  assert.equal(orchestration.state("s21-session").session.state, "completed");
});

test("S27: migration checksum mismatch は unsafe startup を拒否する", () => {
  const directory = mkdtempSync(join(tmpdir(), "work-orchestrator-test-"));
  const path = join(directory, "registry.sqlite");
  const registry = new Registry(path);
  registry.db.prepare("UPDATE schema_migrations SET checksum = 'bad' WHERE version = 1").run();
  assert.throws(() => registry.migrate(), /migration checksum mismatch/);
  registry.close();
  rmSync(directory, { recursive: true, force: true });
});

test("CodexAdapter: grant を契約へ変換し、AbortSignal を実行主体へ伝播する", async () => {
  let observedSignal;
  const adapter = new CodexAdapter(async (_request, signal) => {
    observedSignal = signal;
    return new Promise((resolve) => signal.addEventListener("abort", () => resolve({ status: "cancelled" })));
  });
  const task = { taskId: "t", goal: "g", inputs: {}, contract: agentContract(), inputArtifactVersionIds: [] };
  const grant = { workerId: "w", workerRevision: 1, capabilities: [], permissions: [], budgets: { maxWallTimeMs: 1000 } };
  assert.deepEqual(adapter.translateContract(task, grant), { goal: "g", inputs: {}, permissions: [], capabilities: [], budgets: { maxWallTimeMs: 1000 } });
  const run = adapter.run({ task, execution: { executionId: "e", taskId: "t" }, grant });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal((await adapter.cancel("e")).confirmed, true);
  assert.equal(observedSignal.aborted, true);
  assert.equal((await run).status, "cancelled");
});

test("TemporalSessionRuntime: Continue-As-New は safe point だけで Workflow ID を維持する", () => {
  const definition = validateAndHashDefinition({ workDefinitionId: "continue-as-new", revision: 0, schemaVersion: 1, root: task("human", humanContract()) });
  const state = createInitialRuntimeState(definition, "continue-session", null);
  const runtime = new TemporalSessionRuntime("continue-session", state);
  const continuation = runtime.continueAsNew({
    commandQueueEmpty: true,
    registryCommitInFlight: false,
    agentActivityInFlight: false,
    mutationHandlerInProgress: false,
    timerTransitionInProgress: false,
  });
  assert.equal(continuation.workflowId, "continue-session");
  assert.equal(continuation.previousRunId, "continue-session:run:0");
  assert.equal(continuation.runId, "continue-session:run:1");
  assert.throws(() => runtime.continueAsNew({
    commandQueueEmpty: false,
    registryCommitInFlight: false,
    agentActivityInFlight: false,
    mutationHandlerInProgress: false,
    timerTransitionInProgress: false,
  }), (error) => error instanceof DomainError && error.code === "INVALID_STATE");
});
