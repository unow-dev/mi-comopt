export * from "./contracts.js";
export * from "./canonical.js";
export * from "./validation.js";
export * from "./machines.js";
export * from "./artifact-store.js";
export * from "./registry.js";
export * from "./domain.js";
export * from "./runtime.js";
export * from "./temporal-contracts.js";
export * from "./temporal-workflow.js";
export * from "./temporal-activities.js";
export * from "./temporal-worker.js";
export * from "./temporal-client.js";

/** 旧スケルトン API の後方互換。 */
export function hello(name: string): string {
  return `hello, ${name}`;
}
