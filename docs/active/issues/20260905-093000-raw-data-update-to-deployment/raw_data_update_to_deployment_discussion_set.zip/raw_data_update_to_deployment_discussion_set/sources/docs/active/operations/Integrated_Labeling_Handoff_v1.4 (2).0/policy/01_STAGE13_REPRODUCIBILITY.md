# 再現性ルール

## 1. 前回確定結果を回帰基準にする

前回の確定出力 `reference/merged_array_stage13_labeled_REFERENCE.json` は21,433件の回帰基準である。更新版に既存レコードが残っている場合、以下5フィールドが完全一致すれば前回の`label`を固定継承する。

- `username`
- `handle`
- `comment`
- `postedAt`
- `postedDate`

完全一致レコードを再推論してラベル変更してはいけない。これが次回以降のラベル揺れを最小化する最も強い手段である。

## 2. 完全一致しない類似レコード

`handle + comment` が同じでも日付等が違う場合は、前回ラベルを**強い参照ヒント**として使うが自動固定はしない。同一本文でも反復履歴や周辺状況の違いでラベル差が許容されるためである。

`comment`のみ一致はさらに弱い参照とする。実際、前回データには「誰か言ってやってくれ」という同一本文が、handle履歴の違いにより`normal` / `nuisance`に分かれた確定例がある。

## 3. 新規コメントの判定

新規コメントはStage 13仕様に従う。キーワード一致ではなく、コメントが「誰に対して何をしているか」を判定する。

- 通常批評・質問・好意・雑談 → 原則`normal`
- 人格攻撃・嘲笑・羞恥・性的対象化・有害な決めつけ・排除・他者攻撃・スパム → `nuisance`
- 短い嫌悪は対象と機能を確認し、反復handleなら`nuisance`側へ強める

## 4. 反復handle

バッチ化の前に全入力を`handle`完全一致で索引化する。更新版が差分データのみの場合、過去参照データの同一handle履歴も補助的に参照する。

反復否定handleでも、肯定・質問・雑談・中立発言を一括で`nuisance`にしない。

## 5. Stageを変えない

次回も「Stage 13の再現」が目的なら、基準を勝手に厳格化・緩和しない。新しい方針を導入したい場合はStage 14等として明示的に仕様改訂する。

## 6. v1.1 workspace lineage

`prepare-stage13` 後のworkspaceを別入力へ流用してはならない。実装は次を自動検証する。

- prepare時input SHA-256とfinalize時input SHA-256の一致
- 各source indexの5-field SHA-256一致
- reuse/pendingの完全coverageと非重複
- prepare時reference SHA-256とfinalize時reference SHA-256の一致
- exact reuse labelのreference再照合

これらの不一致はレビュー対象へ落とすのではなく、run自体を停止する。理由は意味上の曖昧性ではなくlineage破損だからである。
